package interfaces;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/SetSettings")
public class SetSettings extends HttpServlet {
	private static final long serialVersionUID = 1L;
      ServletContext context; 
      public static String path = null;
      
   // @see HttpServlet#HttpServlet()
     
    public SetSettings() {
        super();       
    }
    
    public void init(ServletConfig config) throws ServletException {
    	System.out.println("Inside init of SetSettings servlet");   			
    	context = config.getServletContext();
    	path = config.getServletContext().getRealPath("/");
		
		System.out.println("folderpath : "+path);
		
    
    }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw = response.getWriter();
		System.out.println("==================Inside doGET=============== ");	
		
		response.setContentType("text/html");
		pw.println("<html><head><title>DCG Settings</title></head>");
		pw.println("<body><h1 align=\"center\">DCG Setting</h1>");
		pw.println("<form method=\"POST\" action=\"./SetSettings\">");
		pw.println("<table align=\"center\" width=\"75%\" cellspacing=\"10\" cellpadding=\"5\" border=\"1\">");		
		
		pw.println("<tr bgcolor=\"#00CED1\"><td colspan=\"4\" align=\"center\">DCG Config Setting</td></tr>");
		pw.println("<tr><td>BACKEND DATABASES IP</td><td><input type=\"text\" name=\"backendIp\" value=\""+Settings.BACKEND_DATABASES_IP+"\"></td>" );
		pw.println("<tr><td>BACKEND DATABASES PORT</td><td><input type=\"text\" name=\"backendPort\" value=\""+Settings.BACKEND_DATABASES_PORT+"\"></td>" );
		pw.println("<tr><td>CLOUD GATEWAY IP</td><td><input type=\"text\" name=\"cloudgwIp\" value=\""+Settings.CLOUD_GATEWAY_IP+"\"></td>" );
		pw.println("<tr><td>CLOUD GATEWAY PORT</td><td><input type=\"text\" name=\"cloudgwPort\" value=\""+Settings.CLOUD_GATEWAY_PORT+"\"></td>" );		
		pw.println("<tr><td>ACTIVATION SERVER IP</td><td><input type=\"text\" name=\"activationsIp\" value=\""+Settings.ACTIVATION_SERVER_IP+"\"></td>" );
		pw.println("<tr><td>ACTIVATION SERVER PORT</td><td><input type=\"text\" name=\"activationsPort\" value=\""+Settings.ACTIVATION_SERVER_PORT+"\"></td>" );
		pw.println("<tr><td>NOTIFICATION GATEWAY IP</td><td><input type=\"text\" name=\"notificationgIp\" value=\""+Settings.NOTIFICATION_GATEWAY_IP+"\"></td>" );
		pw.println("<tr><td>NOTIFICATION GATEWAY PORT</td><td><input type=\"text\" name=\"notificationgPort\" value=\""+Settings.NOTIFICATION_GATEWAY_PORT+"\"></td>" );
		pw.println("<tr bgcolor=\"#00CED1\"><td colspan=\"4\" align=\"center\">Enable Domain</td></tr>");		
		pw.println("<tr><td>DCG IP</td><td><input type=\"text\" name=\"dcgIp\" value=\""+Settings.DCGIP+"\"></td>" );
		pw.println("<tr><td>DCG PORT</td><td><input type=\"text\" name=\"dcgPort\" value=\""+Settings.DCGPORT+"\"></td>" );
		pw.println("<tr><td>CCG IP</td><td><input type=\"text\" name=\"ccgIp\" value=\""+Settings.CCGIP+"\"></td>" );
		pw.println("<tr><td>CCG PORT</td><td><input type=\"text\" name=\"ccgPort\" value=\""+Settings.CCGPORT+"\"></td>" );
		pw.println("<tr><td>ECG IP</td><td><input type=\"text\" name=\"ecgIp\" value=\""+Settings.ECGIP+"\"></td>" );
		pw.println("<tr><td>ECG PORT</td><td><input type=\"text\" name=\"ecgPort\" value=\""+Settings.ECGPORT+"\"></td>" );
		pw.println("<tr><td>ICG IP</td><td><input type=\"text\" name=\"icgIp\" value=\""+Settings.ICGIP+"\"></td>" );
		pw.println("<tr><td>ICG PORT</td><td><input type=\"text\" name=\"icgPort\" value=\""+Settings.ICGPORT+"\"></td>" );
		
		pw.println("<tr><td colspan=\"4\" align=\"center\"><input type=\"submit\" value=\"Apply Changes\"></td></tr>");
		pw.println("</table></form></body></html>");
		pw.close();
		
	}

	// @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("==================Inside doPOST================");
	
		
		response.setContentType("text/html");
		PrintWriter pw = response.getWriter();
		
		String BACKEND_DATABASES_IP	  = request.getParameter("backendIp");
		String BACKEND_DATABASES_PORT = request.getParameter("backendPort");	
		
		String  CLOUD_GATEWAY_IP	  = request.getParameter("cloudgwIp");
		String  CLOUD_GATEWAY_PORT    = request.getParameter("cloudgwPort");
		
		
		String  ACTIVATION_SERVER_IP	= request.getParameter("activationsIp");
		String  ACTIVATION_SERVER_PORT  = request.getParameter("activationsPort");
		
		String  NOTIFICATION_GATEWAY_IP	  = request.getParameter("notificationgIp");
		String  NOTIFICATION_GATEWAY_PORT = request.getParameter("notificationgPort");
		
		String  DCGIP	 			  = request.getParameter("dcgIp");
		String  DCGPORT               = request.getParameter("dcgPort");
		
		String  CCGIP	              = request.getParameter("ccgIp");
		String  CCGPORT               = request.getParameter("ccgPort");
		
		String  ECGIP	  			  = request.getParameter("ecgIp");
		String  ECGPORT    			  = request.getParameter("ecgPort");
		
		String  ICGIP	  			  = request.getParameter("icgIp");
		String  ICGPORT   			  = request.getParameter("icgPort");
				
	if(BACKEND_DATABASES_PORT.equalsIgnoreCase("")||BACKEND_DATABASES_PORT.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter BACKEND DATABASES PORT!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}	
		else if(BACKEND_DATABASES_IP.equalsIgnoreCase("")||BACKEND_DATABASES_IP.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter BACKEND DATABASES IP!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
	
	
		else if(CLOUD_GATEWAY_IP.equalsIgnoreCase("")||CLOUD_GATEWAY_IP.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter CLOUD GATEWAY IP !!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}else if(CLOUD_GATEWAY_PORT.equalsIgnoreCase("")||CLOUD_GATEWAY_PORT.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter CLOUD GATEWAY PORT!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
	
		else if(ACTIVATION_SERVER_IP.equalsIgnoreCase("")||ACTIVATION_SERVER_IP.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter ACTIVATION SERVER IP !!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}else if(ACTIVATION_SERVER_PORT.equalsIgnoreCase("")||ACTIVATION_SERVER_PORT.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter ACTIVATION SERVER PORT!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
	
		else if(NOTIFICATION_GATEWAY_IP.equalsIgnoreCase("")||NOTIFICATION_GATEWAY_IP.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter NOTIFICATION GATEWAY IP !!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}else if(NOTIFICATION_GATEWAY_PORT.equalsIgnoreCase("")||NOTIFICATION_GATEWAY_PORT.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter NOTIFICATION GATEWAY PORT!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}	
	
		else if(DCGIP.equalsIgnoreCase("")||DCGIP.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter DCG IP!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
	
		else if(DCGPORT.equalsIgnoreCase("")||DCGPORT.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter DCG PORT!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
	
		else if(CCGIP.equalsIgnoreCase("")||CCGIP.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter CCG IP!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
	
		else if(CCGPORT.equalsIgnoreCase("")||CCGPORT.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter CCG PORT!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
	
		else if(ECGIP.equalsIgnoreCase("")||ECGIP.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter ECG IP!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
		else if(ECGPORT.equalsIgnoreCase("")||ECGPORT.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter ECG PORT!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
		else if(ICGIP.equalsIgnoreCase("")||ICGIP.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter ICG IP!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
		else if(ICGPORT.equalsIgnoreCase("")||ICGPORT.equalsIgnoreCase(null))
		{
			pw.println("<html><head><title>DCG Settings</title></head>");		
			pw.println("<body>");
			pw.println("<h1 align=\"center\">Please Enter ICG PORT!!</h1>");
			pw.println("</body></html>");
			doGet(request, response);
			pw.close();
		}
		
		else
		{
			Properties prop = new Properties();		   			  
     		prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("config.properties"));     		   
     		   
     		prop.setProperty("BACKEND_DATABASES_IP", BACKEND_DATABASES_IP);
     	    prop.setProperty("BACKEND_DATABASES_PORT", BACKEND_DATABASES_PORT);
     	    
     	    
     	    prop.setProperty("CLOUD_GATEWAY_IP",  CLOUD_GATEWAY_IP);
    	    prop.setProperty("CLOUD_GATEWAY_PORT",CLOUD_GATEWAY_PORT);  
    	    
    	    
    	    prop.setProperty("ACTIVATION_SERVER_IP",  ACTIVATION_SERVER_IP);
    	    prop.setProperty("ACTIVATION_SERVER_PORT",ACTIVATION_SERVER_PORT);
    	    
    	    
    	    prop.setProperty("NOTIFICATION_GATEWAY_IP",  NOTIFICATION_GATEWAY_IP);
    	    prop.setProperty("NOTIFICATION_GATEWAY_PORT",NOTIFICATION_GATEWAY_PORT);
    	    
     	    prop.setProperty("DCGIP",  DCGIP);
    	    prop.setProperty("DCGPORT",DCGPORT);  	    
    	    
     	    prop.setProperty("CCGIP",  CCGIP);
    	    prop.setProperty("CCGPORT",CCGPORT);   	    
    	    
     	    prop.setProperty("ECGIP",  ECGIP);
    	    prop.setProperty("ECGPORT",ECGPORT);    
    	    
     	    prop.setProperty("ICGIP",  ICGIP);
    	    prop.setProperty("ICGPORT",ICGPORT);   	    
    	        		
    	    prop.store(new FileOutputStream(context.getRealPath("/WEB-INF/classes/config.properties")), null);
    		System.out.println("==2nd time read readproperties file==");
    		
    		prop.load(new FileInputStream(context.getRealPath("/WEB-INF/classes/config.properties")));
    		Settings.BACKEND_DATABASES_IP		= prop.getProperty("BACKEND_DATABASES_IP");
	 		Settings.BACKEND_DATABASES_PORT		= prop.getProperty("BACKEND_DATABASES_PORT");	 	 		
	 		Settings.BACKEND_DATABASES			= Settings.BACKEND_DATABASES_IP+":"+Settings.BACKEND_DATABASES_PORT;
	 		
	 		Settings.CLOUD_GATEWAY_IP			= prop.getProperty("CLOUD_GATEWAY_IP");		  		
	 		Settings.CLOUD_GATEWAY_PORT			= prop.getProperty("CLOUD_GATEWAY_PORT");			 				 		
	 		Settings.CLOUD_GATEWAY		    	= Settings.CLOUD_GATEWAY_IP+":"+Settings.CLOUD_GATEWAY_PORT;
	 		
	 		
	 		Settings.ACTIVATION_SERVER_IP		= prop.getProperty("ACTIVATION_SERVER_IP");		  		
			Settings.ACTIVATION_SERVER_PORT		= prop.getProperty("ACTIVATION_SERVER_PORT");	 		 				 		
			Settings.ACTIVATION_SERVER		    = Settings.ACTIVATION_SERVER_IP+":"+Settings.ACTIVATION_SERVER_PORT;		
			

			Settings.NOTIFICATION_GATEWAY_IP	= prop.getProperty("NOTIFICATION_GATEWAY_IP");		  		
			Settings.NOTIFICATION_GATEWAY_PORT	= prop.getProperty("NOTIFICATION_GATEWAY_PORT");	 		 				 		
			Settings.NOTIFICATION_GATEWAY		= Settings.NOTIFICATION_GATEWAY_IP+":"+Settings.NOTIFICATION_GATEWAY_PORT; 		
	 		
	 		Settings.DCGIP						= prop.getProperty("DCGIP");		  		
	 		Settings.DCGPORT					= prop.getProperty("DCGPORT");
	 		
	 		Settings.CCGIP						= prop.getProperty("CCGIP");		  		
	 		Settings.CCGPORT					= prop.getProperty("CCGPORT");
	 		
	 		Settings.ECGIP						= prop.getProperty("ECGIP");		  		
	 		Settings.ECGPORT					= prop.getProperty("ECGPORT");
	 		
	 		Settings.ICGIP						= prop.getProperty("ICGIP");		  		
	 		Settings.ICGPORT					= prop.getProperty("ICGPORT");
	 		
		
			System.out.println("----After Reset 2nd time values----");
			System.out.println("Backend GW::"+Settings.BACKEND_DATABASES);	
			System.out.println("CLOUD GW::"+Settings.CLOUD_GATEWAY);
			System.out.println("ACTIVATION SERVER::"+Settings.ACTIVATION_SERVER);
			System.out.println("NOTIFICATION GATEWAY ::"+Settings.NOTIFICATION_GATEWAY);
			
			System.out.println("DCG IP and  PORT::"+Settings.DCGIP +":"+Settings.DCGPORT);	
			System.out.println("CCG IP and  PORT::"+Settings.CCGIP +":"+Settings.CCGPORT);
			System.out.println("ECG IP and  PORT::"+Settings.ECGIP +":"+Settings.ECGPORT);	
			System.out.println("ICG IP and  PORT::"+Settings.ICGIP +":"+Settings.ICGPORT);
			
			pw.println("<html><head><title>DCG Settings</title></head>");
			pw.println("<body><h1 align=\"center\">DCG Setting</h1>");
			pw.println("<h1 align=\"center\">Settings Sucessfully Updated</h1>");
			pw.println("<form method=\"POST\" action=\"./SetSettings\">");
			pw.println("<table align=\"center\" width=\"75%\" cellspacing=\"10\" cellpadding=\"5\" border=\"1\">");
			
			pw.println("<tr bgcolor=\"#00CED1\"><td colspan=\"4\" align=\"center\">DCG Config Setting</td></tr>");		
			pw.println("<tr><td>BACKEND DATABASES IP</td><td><input type=\"text\" name=\"backendIp\" value=\""+Settings.BACKEND_DATABASES_IP+"\"></td>" );
			pw.println("<tr><td>BACKEND DATABASES PORT</td><td><input type=\"text\" name=\"backendPort\" value=\""+Settings.BACKEND_DATABASES_PORT+"\"></td>" );
			pw.println("<tr><td>CLOUD GATEWAY IP</td><td><input type=\"text\" name=\"cloudgwIp\" value=\""+Settings.CLOUD_GATEWAY_IP+"\"></td>" );
			pw.println("<tr><td>CLOUD GATEWAY PORT</td><td><input type=\"text\" name=\"cloudgwPort\" value=\""+Settings.CLOUD_GATEWAY_PORT+"\"></td>" );
			pw.println("<tr><td>ACTIVATION SERVER IP</td><td><input type=\"text\" name=\"activationsIp\" value=\""+Settings.ACTIVATION_SERVER_IP+"\"></td>" );
			pw.println("<tr><td>ACTIVATION SERVER PORT</td><td><input type=\"text\" name=\"activationsPort\" value=\""+Settings.ACTIVATION_SERVER_PORT+"\"></td>" );
			pw.println("<tr><td>NOTIFICATION GATEWAY IP</td><td><input type=\"text\" name=\"notificationgIp\" value=\""+Settings.NOTIFICATION_GATEWAY_IP+"\"></td>" );
			pw.println("<tr><td>NOTIFICATION GATEWAY PORT</td><td><input type=\"text\" name=\"notificationgPort\" value=\""+Settings.NOTIFICATION_GATEWAY_PORT+"\"></td>" );
			pw.println("<tr bgcolor=\"#00CED1\"><td colspan=\"4\" align=\"center\">Enable Domain</td></tr>");
			pw.println("<tr><td>DCG IP</td><td><input type=\"text\" name=\"dcgIp\" value=\""+Settings.DCGIP+"\"></td>" );
			pw.println("<tr><td>DCG PORT</td><td><input type=\"text\" name=\"dcgPort\" value=\""+Settings.DCGPORT+"\"></td>" );
			pw.println("<tr><td>CCG IP</td><td><input type=\"text\" name=\"ccgIp\" value=\""+Settings.CCGIP+"\"></td>" );
			pw.println("<tr><td>CCG PORT</td><td><input type=\"text\" name=\"ccgPort\" value=\""+Settings.CCGPORT+"\"></td>" );
			pw.println("<tr><td>ECG IP</td><td><input type=\"text\" name=\"ecgIp\" value=\""+Settings.ECGIP+"\"></td>" );
			pw.println("<tr><td>ECG PORT</td><td><input type=\"text\" name=\"ecgPort\" value=\""+Settings.ECGPORT+"\"></td>" );
			pw.println("<tr><td>ICG IP</td><td><input type=\"text\" name=\"icgIp\" value=\""+Settings.ICGIP+"\"></td>" );
			pw.println("<tr><td>ICG PORT</td><td><input type=\"text\" name=\"icgPort\" value=\""+Settings.ICGPORT+"\"></td>" );			
			pw.println("<tr><td colspan=\"4\" align=\"center\"><input type=\"submit\" value=\"Apply Changes\"></td></tr>");
			pw.println("</table></form></body></html>");
			pw.close();
     	    
					
		}
		//end else			
		
     }
}
