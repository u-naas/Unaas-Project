package interfaces;
import java.util.Properties;





public class Settings {	

	public static final boolean cloudserver_agent_thread= false;

	public static String BACKEND_DATABASES_IP			= null;
	public static String BACKEND_DATABASES_PORT			= null;			
	public static String BACKEND_DATABASES				= null;	

	public static String CLOUD_GATEWAY_IP				= null;
	public static String CLOUD_GATEWAY_PORT				= null;
	public static String CLOUD_GATEWAY					= null;	
	
	
	public static String ACTIVATION_SERVER_IP			= null;
	public static String ACTIVATION_SERVER_PORT			= null;
	public static String ACTIVATION_SERVER				= null;	
	
	public static String NOTIFICATION_GATEWAY_IP		= null;
	public static String NOTIFICATION_GATEWAY_PORT		= null;
	public static String NOTIFICATION_GATEWAY			= null;

	public static String DCGIP 							= null;
	public static String DCGPORT						= null;

	public static String CCGIP							= null;
	public static String CCGPORT						= null;

	public static String ECGIP							= null;
	public static String ECGPORT						= null;

	public static String ICGIP							= null;
	public static String ICGPORT						= null;

	public static int CONNECTION_TIMEOUT				= 360000;
	public static int READ_TIMEOUT						= 360000;

	public 	static String 	web_content_path			= null;









	static{			
		System.out.println("==1st time readproperties file==");    	
		try{
			Properties prop = new Properties();		   			  
			prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("config.properties"));	


			Settings.BACKEND_DATABASES_IP		= prop.getProperty("BACKEND_DATABASES_IP");		  		
			Settings.BACKEND_DATABASES_PORT		= prop.getProperty("BACKEND_DATABASES_PORT");	 		 				 		
			Settings.BACKEND_DATABASES		    = Settings.BACKEND_DATABASES_IP+":"+Settings.BACKEND_DATABASES_PORT;	



			Settings.CLOUD_GATEWAY_IP			= prop.getProperty("CLOUD_GATEWAY_IP");		  		
			Settings.CLOUD_GATEWAY_PORT			= prop.getProperty("CLOUD_GATEWAY_PORT");			 				 		
			Settings.CLOUD_GATEWAY		    	= Settings.CLOUD_GATEWAY_IP+":"+Settings.CLOUD_GATEWAY_PORT;
			
			
			Settings.ACTIVATION_SERVER_IP		= prop.getProperty("ACTIVATION_SERVER_IP");		  		
			Settings.ACTIVATION_SERVER_PORT		= prop.getProperty("ACTIVATION_SERVER_PORT");	 		 				 		
			Settings.ACTIVATION_SERVER		    = Settings.ACTIVATION_SERVER_IP+":"+Settings.ACTIVATION_SERVER_PORT;		
			

			Settings.NOTIFICATION_GATEWAY_IP	= prop.getProperty("NOTIFICATION_GATEWAY_IP");		  		
			Settings.NOTIFICATION_GATEWAY_PORT	= prop.getProperty("NOTIFICATION_GATEWAY_PORT");	 		 				 		
			Settings.NOTIFICATION_GATEWAY		= Settings.NOTIFICATION_GATEWAY_IP+":"+Settings.NOTIFICATION_GATEWAY_PORT;


			Settings.DCGIP						= prop.getProperty("DCGIP");		  		
			Settings.DCGPORT					= prop.getProperty("DCGPORT");

			Settings.CCGIP						= prop.getProperty("CCGIP");		  		
			Settings.CCGPORT					= prop.getProperty("CCGPORT");

			Settings.ECGIP						= prop.getProperty("ECGIP");		  		
			Settings.ECGPORT					= prop.getProperty("ECGPORT");		 		

			Settings.ICGIP						= prop.getProperty("ICGIP");		  		
			Settings.ICGPORT					= prop.getProperty("ICGPORT");

					System.out.println("----After Reset values----");
			System.out.println("DCG DOMAIN::"+Settings.BACKEND_DATABASES);
			System.out.println("CLOUD GATEWAY::"+Settings.CLOUD_GATEWAY);
			System.out.println("ACTIVATION SERVER::"+Settings.ACTIVATION_SERVER);
			System.out.println("NOTIFICATION GATEWAY ::"+Settings.NOTIFICATION_GATEWAY);
			System.out.println("DCG IP and  PORT::"+Settings.DCGIP +":"+Settings.DCGPORT);	
			System.out.println("CCG IP and  PORT::"+Settings.CCGIP +":"+Settings.CCGPORT);
			System.out.println("ECG IP and  PORT::"+Settings.ECGIP +":"+Settings.ECGPORT);	
			System.out.println("ICG IP and  PORT::"+Settings.ICGIP +":"+Settings.ICGPORT);
			



		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Fatal Error :Unabled to Read properties  file is present=="+e.getMessage());				   
		}finally
		{

		}

	}	

	static {						


	}


}
