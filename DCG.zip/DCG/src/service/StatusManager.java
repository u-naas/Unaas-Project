package service;

//import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
//import java.util.Properties;
import com.pojo.*;


public class StatusManager {

	private static Map<String,String> map1 = new Hashtable<String,String>();
	public synchronized boolean setDeviceStatus(String solutionId , String udn, String status)
	{
		try {
			map1.put(solutionId, udn);
			map1.put(udn, status);		

			String   Udn 		= map1.get(solutionId);
			String  Status     = map1.get(udn);

			System.out.println("soultionId=>"+solutionId+" And UDN=>"+Udn);
			System.out.println("Udn=>"+Udn+" And Status=>"+Status);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}


	public synchronized String getDeviceStatus(String solutionId,String udn)
	{
		try {
			//String Udn ;
			map1.get(solutionId);
			String status =  map1.get(udn);			
			return  status ;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return "0";
		}
	}	

	//Added on 19.10.16	
	//private static Map<String,String> map1 = new Hashtable<String,String>();
	public synchronized boolean registrationSoultion(String soultionId , String udn, String status)
	{
		try {

			map1.put(soultionId, udn);
			map1.put(udn, status);


			String   Udn 		= map1.get(soultionId);
			String  Status     = map1.get(udn);

			System.out.println("soultionId=>"+soultionId+" And UDN=>"+Udn);
			System.out.println("Udn=>"+Udn+" And Status=>"+Status);

			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}



	public synchronized boolean registerSol(String solutionId,String status)
	{
		try {

			map1.put(solutionId, status);
			String st = map1.get(solutionId);
			System.out.println("Solution=> "+solutionId+" && Status=>"+st);

			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}


	public synchronized boolean deRegistrationSoultion(String soultionId ,String udn)
	{
		try {			
			map1.remove(soultionId);
			map1.remove(udn);

			String   Udn 	   = map1.get(soultionId);
			String  Status     = map1.get(udn);

			//System.out.println("soultionId=>"+soultionId+" And UDN=>"+Udn);
			//System.out.println("Udn=>"+Udn+" And Status=>"+Status);

			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}


	public synchronized boolean getSolMapStatus(String solutionId)
	{
		try {				
			String   Udn 		= map1.get(solutionId);
			if(Udn!=null){
				String  Status     = map1.get(Udn);				
				return true;
			}				
			return false;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}



	public synchronized boolean deleteMap(String soultionId ,String udn)
	{
		try {			
			//map1.remove(soultionId);
			map1.remove(udn);
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return false;
		}
	}

	/*public static void main (String arg[]){

		StatusManager st =  new StatusManager();
		st.registrationSoultion("avikesh", "567", "1");
		st.registrationSoultion("sonu", "123", "0");		
		st.deRegistrationSoultion("sonu", "123");
		String  mapStatus1 = map.get("avikesh");
		String mapStatus2 = map.get("567");
		System.out.println("Avikesh == >"+mapStatus1);
		System.out.println("Avikesh udn == >"+mapStatus2);	

		String  mapStatus3 = map.get("sonu");
		String mapStatus4 = map.get("123");
		System.out.println("sonu == >"+mapStatus3);
		System.out.println("sonu udn == >"+mapStatus4);		


	}*/

}


