package service;

import java.util.ArrayList;
import java.util.List;

import interfaces.Settings;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.pojo.ChannelBean;
import com.pojo.FbBean;
import com.pojo.InventoryDevices;
import com.pojo.InventoryDeviceInfo;
import com.pojo.SmsBean;
import com.pojo.TwBean;
import com.pojo.EmailBean;
import com.unaas.xmlparse.ChannelParse;
import com.unaas.xmlparse.InventoryDeviceListParser;
import com.unaas.xmlparse.InventoryDeviceParser;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;




@Path("/")
public class DevAcmgmt {		

	StatusManager sm = new StatusManager();





	/*-------------------------------------------------For Camera---------------------------------------------------------*/


	/*@POST
	@Path("{custid}/{siteid}/{udn}/ras-service-camera/getViewUrl")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response getCameraViewUrl(@PathParam("siteid") String siteid , @PathParam("udn") String udn){
		System.out.println("Udn no. :: "+udn);
		try {

			int getRes 	= sm.getDeviceStatus(udn);			
			String xml = "<?xml version=\"1.0\"?>"+
					"<u:getViewUrl xmlns:u=\"urn:schemas-u-nass-com:service:ras-service-camera:1\">"+				
					"<argViewUrl>"+getRes+"</argViewUrl>"+
					"</u:getViewUrl>";
			System.out.println("Current Status Status :: "+getRes);
			return Response.ok(xml).build();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}*/




	/*------------------------------------------------ For Light ---------------------------------------------------------*/



	@GET
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-lighting/getStatus")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response getLightStatus(@PathParam("activationcode") String activationcode , @PathParam("solutionid") String solutionid , @PathParam("udn") String udn){

		System.out.println("Udn Light :: "+udn);
		System.out.println("activationcode =====>"+activationcode);
		try {

			//Get  Solution Id from #map table
			boolean r = sm.getSolMapStatus(activationcode);
			if(r==true){
				//Get the Light Status from HashTable			
				String getRes 	= sm.getDeviceStatus(activationcode,udn);
				String xml = "<?xml version=\"1.0\"?>"+
						"<deviceStatus>"+				
						"<status>"+getRes+"</status>"+					
						"</deviceStatus>";
				System.out.println("Response :: \n"+xml);
				System.out.println("Current Light Status :: "+getRes);
				return Response.ok(xml).build();
			}
			else{
				String xml1 = "<?xml version=\"1.0\"?>"+
						"<deviceStatus>"+				
						"<status>404</status>"+					
						"</deviceStatus>";
				System.out.println("SolutionId Not Found For Light ####  "+xml1);				
				return Response.ok(xml1).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}	


	@POST
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-lighting/actLampDimLevel")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response actLampDimLevel(@PathParam("activationcode") String activationcode,@PathParam("solutionid") String solutionid,@PathParam("udn") String udn,String xml){	

		System.out.println("actLampDimLevel Requet XMl ::::"+xml);
		System.out.println("actLampDimLevel Requet udn ::::"+udn);
		System.out.println("activationcode =====>"+activationcode);

		//Parse xml  
		String lampStatus = xml.substring(xml.indexOf("<argNewDimLevel>")+16, xml.lastIndexOf("</argNewDimLevel>"));		

		// Call for Cloud Gateway
		Client c=Client.create();
		String message = "nId="+udn+"=nT=BINARY-SWITCH=set="+lampStatus;
		WebResource resource=c.resource("http://"+Settings.CLOUD_GATEWAY+"/?c=getRelayStatus&s="+message);
		ClientResponse response=resource.get(ClientResponse.class);
		System.out.println("light ######### res for cloud Gateway  Side ="+response);		
		return Response.ok().build();		
	}



	@POST
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-lighting/putLampDimLevel")	
	public Response PutLampDimLevel(@PathParam("activationcode") String activationcode,@PathParam("solutionid") String solutionid,@PathParam("udn") String udn,String xml){	

		System.out.println("PutLampDimLevel Requet XMl ::::"+xml);
		System.out.println("PutLampDimLevel Requet udn ::::"+udn);
		System.out.println("activationcode =====>"+activationcode);

		//Get  Solution Id from #map table
		boolean r = sm.getSolMapStatus(activationcode);
		if(r==true){
			//Set the Light Status in HashTable  
			String lampStatus = xml.substring(xml.indexOf("<argNewDimLevel>")+16, xml.lastIndexOf("</argNewDimLevel>"));
			sm.setDeviceStatus(activationcode,udn, lampStatus);
			boolean ress = sm.setDeviceStatus(activationcode,udn,lampStatus);
			System.out.println("MapTable Updted "+ress);

			String resp = "";
			String channelId="";		
			String Accountsid="";
			String token="";

			//Get ChannelList
			Client c=Client.create();		
			WebResource resource=c.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannellist/"+activationcode);		
			ClientResponse response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
			System.out.println("res for NotificationServer Side ="+response.getStatus());
			resp= response.getEntity(String.class);		

			//Parse (PatnerId,ChannelId)
			ChannelParse cp = new ChannelParse();
			ArrayList<ChannelBean> resparser = cp.parseChannelList(resp);		
			if(resparser!=null && resparser.size()>0){
				for(int index=0; index<resparser.size(); index++){
					ChannelBean clistBean = resparser.get(index);
					if(clistBean.channelBeans.size()>0){                
						for(int i=0; i<clistBean.channelBeans.size(); i++){
							ChannelBean sBean = clistBean.channelBeans.get(i);							
							String partnerId = sBean.getPartnerid();
							System.out.println("partnerId ############# "+partnerId);
							channelId = sBean.getChannelid();
							System.out.println("channelId ############# "+channelId);

							if(channelId.equalsIgnoreCase("FACEBOOK")){
								String resp1 = "";							
								String accesstoken="";
								String appid="";
								String appSecret="";

								Client c1=Client.create();		
								WebResource resource1=c1.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigFb/"+partnerId+"/"+channelId);		
								ClientResponse response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response1.getStatus());
								resp1= response1.getEntity(String.class);							

								//parser ConfigFb Details							
								ArrayList<FbBean> resparserConfigFb = cp.parseConfigFb(resp1);
								if(resparserConfigFb!=null && resparserConfigFb.size()>0){
									for(int index1=0; index1<resparserConfigFb.size(); index1++){
										FbBean fblistBean = resparserConfigFb.get(index1);
										if(fblistBean.fbBeans.size()>0){                
											for(int j=0; j<fblistBean.fbBeans.size(); j++){
												FbBean fbBean = fblistBean.fbBeans.get(j);							
												accesstoken = fbBean.getAccesstoken();											
												appid = fbBean.getAppid();											
												appSecret = fbBean.getAppsecret();										
											}

											c1=Client.create();		
											resource1=c1.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendPostToFB/me/true/"+accesstoken);		
											response1=resource1.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String facebookBody = response1.getEntity(String.class);
											System.out.println("Response body for sendPostToFB ===== >"+facebookBody);											
										}
										else{
											System.out.println("FbBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigFb object Null ----------------");
								}
							}

							else if(channelId.equalsIgnoreCase("TWITTER")){
								String resp2 = "";							
								String accesstokenTw="";
								String accesstokensecret="";
								String consumerkey="";
								String consumerkeysecret="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigTw/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp2= response2.getEntity(String.class);							

								//parser ConfigTw Details							
								ArrayList<TwBean> resparserConfigTw = cp.parseConfigTw(resp2);
								if(resparserConfigTw!=null && resparserConfigTw.size()>0){
									for(int index2=0; index2<resparserConfigTw.size(); index2++){
										TwBean twlistBean = resparserConfigTw.get(index2);
										if(twlistBean.twBeans.size()>0){                
											for(int k=0; k<twlistBean.twBeans.size(); k++){
												TwBean twBean = twlistBean.twBeans.get(k);							
												accesstokenTw = twBean.getAccesstoken();											
												accesstokensecret = twBean.getAccesstokensecret();											
												consumerkey = twBean.getConsumerkey();											
												consumerkeysecret = twBean.getConsumerkeysecret();											
											}							

											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendTwitTotwitter/"+partnerId+"/"+accesstokenTw+"/"+accesstokensecret+"/"+consumerkey+"/"+consumerkeysecret);		
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String twitterBody = response.getEntity(String.class);
											System.out.println("Response body for sendTwitTotwitter ===== >"+twitterBody);
										}
										else{
											System.out.println("TwBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigTw object Null ----------------");
								}
							}						

							else if(channelId.equalsIgnoreCase("SMS")){
								String resp3 = "";					
								String to="";
								String from="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigSms/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp3= response2.getEntity(String.class);							

								//parser ConfigSms Details							
								ArrayList<SmsBean> resparserConfigSms = cp.parseConfigSms(resp3);
								System.out.println("DevAcmgmt.PutLampDimLevel()"+resp3);
								if(resparserConfigSms!=null && resparserConfigSms.size()>0){
									for(int index2=0; index2<resparserConfigSms.size(); index2++){
										SmsBean smslistBean = resparserConfigSms.get(index2);
										if(smslistBean.smsBeans.size()>0){                
											for(int k=0; k<smslistBean.smsBeans.size(); k++){
												SmsBean smsBean = smslistBean.smsBeans.get(k);							
												Accountsid = smsBean.getAccountsid();											
												token = smsBean.getToken();											
												to = smsBean.getTos();											
												from = smsBean.getFroms();											
											}									
											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendSMS/"+Accountsid+"/"+token+"/"+to+"/"+from);
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String SMSBody = response.getEntity(String.class);
											System.out.println("Response body for SMS Send ===== >"+SMSBody);
										}
										else{
											System.out.println("SmsBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigSms object Null ----------------");
								}
							}
							else if(channelId.equalsIgnoreCase("EMAIL")){
								//Get Email Config 
								String defaultmail="";
								String outgoingmailserverhost="";
								String resp3 = "";					
								String outgoingmailport="";
								String userid="";
								String userpwd="";
								String emailxml="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigEmail/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp3= response2.getEntity(String.class);

								//parser ConfigSms Details							
								ArrayList<EmailBean> resparserConfigEmail = cp.parseEmailInfo(resp3);
								System.out.println("DevAcmgmt.PutLampDimLevel()"+resp3);
								if(resparserConfigEmail!=null && resparserConfigEmail.size()>0){
									for(int index2=0; index2<resparserConfigEmail.size(); index2++){
										EmailBean emaillistBean = resparserConfigEmail.get(index2);
										if(emaillistBean.emailBeans.size()>0){                
											for(int k=0; k<emaillistBean.emailBeans.size(); k++){
												EmailBean emailBean = emaillistBean.emailBeans.get(k);							
												defaultmail = emailBean.getDefaultmail();											
												outgoingmailserverhost = emailBean.getOutgoingmailserverhost();											
												outgoingmailport = emailBean.getOutgoingmailport();											
												userid = emailBean.getUserid();	
												userpwd = emailBean.getUserpasswd();	
											}					

											emailxml ="<email>"+												
													"<defaultmail>"+defaultmail+"</defaultmail>"+
													"<outgoingmailserverhost>"+outgoingmailserverhost+"</outgoingmailserverhost>"+	
													"<outgoingmailport>"+outgoingmailport+"</outgoingmailport>"+	
													"<userid>"+userid+"</userid>"+	
													"<userpwd>"+userpwd+"</userpwd>"+	
													"</email>";
											System.out.println("EMAIL  XML  =========>"+emailxml);

											//Send Email
											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendEMail/testmail/premanand216@gmail.com");		
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String emailBody = response.getEntity(String.class);
											System.out.println("Response body for Email Send ===== >"+emailBody);
										}
										else{
											System.out.println("EmailBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigEmail object Null ----------------");
								}

							}
							else{
								System.out.println("No Configuration Found For Channels --------------------");
							}	

						}

					}
					else{
						System.out.println("NO CHANNEL ID FOUND --------------------");
					}
				}

			}
			return Response.ok().build();

		}
		else{
			System.out.println("Solution Not Registered (Light)###");

		}
		return Response.serverError().build();

	}






	/*-------------------------------------------------- For Fan ---------------------------------------------------------*/



	@GET
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-fan/getStatus")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response getFanStatus(@PathParam("activationcode") String activationcode ,@PathParam("solutionid") String solutionid , @PathParam("udn") String udn){

		System.out.println("Udn Fan :: "+udn);
		System.out.println("activationcode =====>"+activationcode);
		try {
			boolean r = sm.getSolMapStatus(activationcode);
			if(r==true){
				// Get the Fan Status from HashTable
				String getRes 	= sm.getDeviceStatus(activationcode,udn);
				String xml = "<?xml version=\"1.0\"?>"+
						"<deviceStatus>"+				
						"<fanStatus>"+getRes+"</fanStatus>"+					
						"</deviceStatus>";
				System.out.println("Response :: \n"+xml);
				System.out.println("Current Fan Status :: "+getRes);
				return Response.ok(xml).build();
			}
			else{
				String xml1 = "<?xml version=\"1.0\"?>"+
						"<deviceStatus>"+				
						"<fanStatus>404</fanStatus>"+					
						"</deviceStatus>";
				System.out.println("SolutionId Not Found For Fan ####  "+xml1);
				return Response.ok(xml1).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}	




	@POST
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-fan/actSetFanSpeed")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response actSetFanSpeed(@PathParam("activationcode") String activationcode,@PathParam("solutionid") String solutionid,@PathParam("udn") String udn,String reqxml){

		System.out.println(" Inside actSetFanSpeed Requet XMl For Fan ::::"+reqxml);
		System.out.println("Udn =====>"+udn);
		System.out.println("activationcode =====>"+activationcode);

		// parse xml
		String FanStatus = reqxml.substring(reqxml.indexOf("<argNewFanSpeed>")+16, reqxml.lastIndexOf("</argNewFanSpeed>"));		

		// Call for Cloud Gateway  
		Client c=Client.create();
		String message = "nId="+udn+"=nT=Fan=set="+FanStatus;
		WebResource resource=c.resource("http://"+Settings.CLOUD_GATEWAY+"/?c=getRelayStatus&s="+message);
		ClientResponse response=resource.get(ClientResponse.class);
		System.out.println("Fan response from Cloud Gateway  Side ="+response);
		return Response.ok().build();
	}



	@POST
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-fan/putSetFanSpeed")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response putSetFanSpeed(@PathParam("activationcode") String activationcode,@PathParam("solutionid") String solutionid,@PathParam("udn") String udn,String xml){

		System.out.println(" Inside putSetFanSpeed Requet XMl For Fan ::::"+xml);
		System.out.println("Udn =====>"+udn);
		System.out.println("activationcode =====>"+activationcode);

		//Get  Solution Id from #map table
		boolean r = sm.getSolMapStatus(activationcode);
		if(r==true){
			// Set the Fan Status in HashTable  
			String FanStatus = xml.substring(xml.indexOf("<argNewFanSpeed>")+16, xml.lastIndexOf("</argNewFanSpeed>"));
			sm.setDeviceStatus(activationcode,udn, FanStatus);
			boolean ress = sm.setDeviceStatus(activationcode,udn,FanStatus);
			System.out.println("# MapTable Updted "+ress);

			String resp = "";
			String channelId="";		
			String Accountsid="";
			String token="";

			//Get ChannelList
			Client c=Client.create();		
			WebResource resource=c.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannellist/"+activationcode);		
			ClientResponse response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
			System.out.println("res for NotificationServer Side ="+response.getStatus());
			resp= response.getEntity(String.class);		

			//Parse (PatnerId,ChannelId)
			ChannelParse cp = new ChannelParse();
			ArrayList<ChannelBean> resparser = cp.parseChannelList(resp);		
			if(resparser!=null && resparser.size()>0){
				for(int index=0; index<resparser.size(); index++){
					ChannelBean clistBean = resparser.get(index);
					if(clistBean.channelBeans.size()>0){                
						for(int i=0; i<clistBean.channelBeans.size(); i++){
							ChannelBean sBean = clistBean.channelBeans.get(i);							
							String partnerId = sBean.getPartnerid();
							System.out.println("partnerId ############# "+partnerId);
							channelId = sBean.getChannelid();
							System.out.println("channelId ############# "+channelId);

							if(channelId.equalsIgnoreCase("FACEBOOK")){
								String resp1 = "";							
								String accesstoken="";
								String appid="";
								String appSecret="";

								Client c1=Client.create();		
								WebResource resource1=c1.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigFb/"+partnerId+"/"+channelId);		
								ClientResponse response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response1.getStatus());
								resp1= response1.getEntity(String.class);							

								//parser ConfigFb Details							
								ArrayList<FbBean> resparserConfigFb = cp.parseConfigFb(resp1);
								if(resparserConfigFb!=null && resparserConfigFb.size()>0){
									for(int index1=0; index1<resparserConfigFb.size(); index1++){
										FbBean fblistBean = resparserConfigFb.get(index1);
										if(fblistBean.fbBeans.size()>0){                
											for(int j=0; j<fblistBean.fbBeans.size(); j++){
												FbBean fbBean = fblistBean.fbBeans.get(j);							
												accesstoken = fbBean.getAccesstoken();											
												appid = fbBean.getAppid();											
												appSecret = fbBean.getAppsecret();										
											}

											c1=Client.create();		
											resource1=c1.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendPostToFB/me/true/"+accesstoken);		
											response1=resource1.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String facebookBody = response1.getEntity(String.class);
											System.out.println("Response body for sendPostToFB ===== >"+facebookBody);											
										}
										else{
											System.out.println("FbBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigFb object Null ----------------");
								}
							}

							else if(channelId.equalsIgnoreCase("TWITTER")){
								String resp2 = "";							
								String accesstokenTw="";
								String accesstokensecret="";
								String consumerkey="";
								String consumerkeysecret="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigTw/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp2= response2.getEntity(String.class);							

								//parser ConfigTw Details							
								ArrayList<TwBean> resparserConfigTw = cp.parseConfigTw(resp2);
								if(resparserConfigTw!=null && resparserConfigTw.size()>0){
									for(int index2=0; index2<resparserConfigTw.size(); index2++){
										TwBean twlistBean = resparserConfigTw.get(index2);
										if(twlistBean.twBeans.size()>0){                
											for(int k=0; k<twlistBean.twBeans.size(); k++){
												TwBean twBean = twlistBean.twBeans.get(k);							
												accesstokenTw = twBean.getAccesstoken();											
												accesstokensecret = twBean.getAccesstokensecret();											
												consumerkey = twBean.getConsumerkey();											
												consumerkeysecret = twBean.getConsumerkeysecret();											
											}							

											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendTwitTotwitter/"+partnerId+"/"+accesstokenTw+"/"+accesstokensecret+"/"+consumerkey+"/"+consumerkeysecret);		
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String twitterBody = response.getEntity(String.class);
											System.out.println("Response body for sendTwitTotwitter ===== >"+twitterBody);
										}
										else{
											System.out.println("TwBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigTw object Null ----------------");
								}
							}						

							else if(channelId.equalsIgnoreCase("SMS")){
								String resp3 = "";					
								String to="";
								String from="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigSms/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp3= response2.getEntity(String.class);							

								//parser ConfigSms Details							
								ArrayList<SmsBean> resparserConfigSms = cp.parseConfigSms(resp3);
								System.out.println("DevAcmgmt.PutLampDimLevel()"+resp3);
								if(resparserConfigSms!=null && resparserConfigSms.size()>0){
									for(int index2=0; index2<resparserConfigSms.size(); index2++){
										SmsBean smslistBean = resparserConfigSms.get(index2);
										if(smslistBean.smsBeans.size()>0){                
											for(int k=0; k<smslistBean.smsBeans.size(); k++){
												SmsBean smsBean = smslistBean.smsBeans.get(k);							
												Accountsid = smsBean.getAccountsid();											
												token = smsBean.getToken();											
												to = smsBean.getTos();											
												from = smsBean.getFroms();											
											}									
											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendSMS/"+Accountsid+"/"+token+"/"+to+"/"+from);
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String SMSBody = response.getEntity(String.class);
											System.out.println("Response body for SMS Send ===== >"+SMSBody);
										}
										else{
											System.out.println("SmsBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigSms object Null ----------------");
								}
							}
							else if(channelId.equalsIgnoreCase("EMAIL")){
								//Get Email Config 
								String defaultmail="";
								String outgoingmailserverhost="";
								String resp3 = "";					
								String outgoingmailport="";
								String userid="";
								String userpwd="";
								String emailxml="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigEmail/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp3= response2.getEntity(String.class);

								//parser ConfigSms Details							
								ArrayList<EmailBean> resparserConfigEmail = cp.parseEmailInfo(resp3);
								System.out.println("DevAcmgmt.PutLampDimLevel()"+resp3);
								if(resparserConfigEmail!=null && resparserConfigEmail.size()>0){
									for(int index2=0; index2<resparserConfigEmail.size(); index2++){
										EmailBean emaillistBean = resparserConfigEmail.get(index2);
										if(emaillistBean.emailBeans.size()>0){                
											for(int k=0; k<emaillistBean.emailBeans.size(); k++){
												EmailBean emailBean = emaillistBean.emailBeans.get(k);							
												defaultmail = emailBean.getDefaultmail();											
												outgoingmailserverhost = emailBean.getOutgoingmailserverhost();											
												outgoingmailport = emailBean.getOutgoingmailport();											
												userid = emailBean.getUserid();	
												userpwd = emailBean.getUserpasswd();	
											}					

											emailxml ="<email>"+												
													"<defaultmail>"+defaultmail+"</defaultmail>"+
													"<outgoingmailserverhost>"+outgoingmailserverhost+"</outgoingmailserverhost>"+	
													"<outgoingmailport>"+outgoingmailport+"</outgoingmailport>"+	
													"<userid>"+userid+"</userid>"+	
													"<userpwd>"+userpwd+"</userpwd>"+	
													"</email>";
											System.out.println("EMAIL  XML  =========>"+emailxml);

											//Send Email
											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendEMail/testmail/premanand216@gmail.com");		
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String emailBody = response.getEntity(String.class);
											System.out.println("Response body for Email Send ===== >"+emailBody);
										}
										else{
											System.out.println("EmailBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigEmail object Null ----------------");
								}

							}
							else{
								System.out.println("No Configuration Found For Channels --------------------");
							}	

						}

					}
					else{
						System.out.println("NO CHANNEL ID FOUND --------------------");
					}
				}

			}
		}
		else{
			System.out.println("Solution Not Registered (Fan)###");

		}
		return Response.serverError().build();

	}		







	/*------------------------------------------------- For Drapes ---------------------------------------------------------------*/

	@GET
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-drapes/getStatus")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response getDrapesStatus(@PathParam("activationcode") String activationcode ,@PathParam("solutionid") String solutionid , @PathParam("udn") String udn){

		System.out.println("Udn Drapes :: "+udn);
		System.out.println("activationcode =====>"+activationcode);
		try {
			boolean r = sm.getSolMapStatus(activationcode);
			if(r==true){
				// Get the Drapes Status from HashTable
				String getRes 	= sm.getDeviceStatus(activationcode,udn);
				String xml = "<?xml version=\"1.0\"?>"+
						"<deviceStatus>"+				
						"<drapesStatus>"+getRes+"</drapesStatus>"+					
						"</deviceStatus>";
				System.out.println("Response :: \n"+xml);
				System.out.println("Current Drapes Status :: "+getRes);
				return Response.ok(xml).build();
			}
			else{
				String xml1 = "<?xml version=\"1.0\"?>"+
						"<deviceStatus>"+				
						"<drapesStatus>404</drapesStatus>"+					
						"</deviceStatus>";
				System.out.println("SolutionId not found for Drapes #### "+xml1);
				return Response.ok(xml1).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}



	@POST
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-drapes/actDrapes")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response actDrapes(@PathParam("activationcode") String activationcode,@PathParam("solutionid") String solutionid,@PathParam("udn") String udn,String reqxml){

		System.out.println("Inside the actDrapes =====>"+reqxml);
		System.out.println("Udn =====>"+udn);
		System.out.println("activationcode =====>"+activationcode);

		//Parse Xml
		String DrapesStatus = reqxml.substring(reqxml.indexOf("<argNewDrapes>")+14, reqxml.lastIndexOf("</argNewDrapes>"));	

		// Call for cloud Gateway 
		Client c=Client.create();
		String message = "nId="+udn+"=nT=Drapes=set="+DrapesStatus;
		WebResource resource=c.resource("http://"+Settings.CLOUD_GATEWAY+"/?c=getRelayStatus&s="+message);
		ClientResponse response=resource.get(ClientResponse.class);
		System.out.println("Drapes response for Cloud Gateway  Side ="+response);
		return Response.ok().build();
	}


	@POST
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-drapes/putStatusDrapes")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response putStausDrapes(@PathParam("activationcode") String activationcode,@PathParam("solutionid") String solutionid,@PathParam("udn") String udn,String xml){

		System.out.println("Inside the putStausDrapes =====>"+xml);
		System.out.println("Udn =====>"+udn);
		System.out.println("activationcode =====>"+activationcode);

		//Get  Solution Id from #map table
		boolean r = sm.getSolMapStatus(activationcode);
		if(r==true){
			// Set the Drapes Status in Hash Table  
			String DrapesStatus = xml.substring(xml.indexOf("<argNewDrapes>")+14,xml.lastIndexOf("</argNewDrapes>"));
			sm.setDeviceStatus(activationcode,udn, DrapesStatus);
			boolean ress = sm.setDeviceStatus(activationcode,udn,DrapesStatus);
			System.out.println("# MapTable Updted "+ress);

			String resp = "";
			String channelId="";		
			String Accountsid="";
			String token="";

			//Get ChannelList
			Client c=Client.create();		
			WebResource resource=c.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannellist/"+activationcode);		
			ClientResponse response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
			System.out.println("res for NotificationServer Side ="+response.getStatus());
			resp= response.getEntity(String.class);		

			//Parse (PatnerId,ChannelId)
			ChannelParse cp = new ChannelParse();
			ArrayList<ChannelBean> resparser = cp.parseChannelList(resp);		
			if(resparser!=null && resparser.size()>0){
				for(int index=0; index<resparser.size(); index++){
					ChannelBean clistBean = resparser.get(index);
					if(clistBean.channelBeans.size()>0){                
						for(int i=0; i<clistBean.channelBeans.size(); i++){
							ChannelBean sBean = clistBean.channelBeans.get(i);							
							String partnerId = sBean.getPartnerid();
							System.out.println("partnerId ############# "+partnerId);
							channelId = sBean.getChannelid();
							System.out.println("channelId ############# "+channelId);

							if(channelId.equalsIgnoreCase("FACEBOOK")){
								String resp1 = "";							
								String accesstoken="";
								String appid="";
								String appSecret="";

								Client c1=Client.create();		
								WebResource resource1=c1.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigFb/"+partnerId+"/"+channelId);		
								ClientResponse response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response1.getStatus());
								resp1= response1.getEntity(String.class);							

								//parser ConfigFb Details							
								ArrayList<FbBean> resparserConfigFb = cp.parseConfigFb(resp1);
								if(resparserConfigFb!=null && resparserConfigFb.size()>0){
									for(int index1=0; index1<resparserConfigFb.size(); index1++){
										FbBean fblistBean = resparserConfigFb.get(index1);
										if(fblistBean.fbBeans.size()>0){                
											for(int j=0; j<fblistBean.fbBeans.size(); j++){
												FbBean fbBean = fblistBean.fbBeans.get(j);							
												accesstoken = fbBean.getAccesstoken();											
												appid = fbBean.getAppid();											
												appSecret = fbBean.getAppsecret();										
											}

											c1=Client.create();		
											resource1=c1.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendPostToFB/me/true/"+accesstoken);		
											response1=resource1.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String facebookBody = response1.getEntity(String.class);
											System.out.println("Response body for sendPostToFB ===== >"+facebookBody);											
										}
										else{
											System.out.println("FbBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigFb object Null ----------------");
								}
							}

							else if(channelId.equalsIgnoreCase("TWITTER")){
								String resp2 = "";							
								String accesstokenTw="";
								String accesstokensecret="";
								String consumerkey="";
								String consumerkeysecret="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigTw/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp2= response2.getEntity(String.class);							

								//parser ConfigTw Details							
								ArrayList<TwBean> resparserConfigTw = cp.parseConfigTw(resp2);
								if(resparserConfigTw!=null && resparserConfigTw.size()>0){
									for(int index2=0; index2<resparserConfigTw.size(); index2++){
										TwBean twlistBean = resparserConfigTw.get(index2);
										if(twlistBean.twBeans.size()>0){                
											for(int k=0; k<twlistBean.twBeans.size(); k++){
												TwBean twBean = twlistBean.twBeans.get(k);							
												accesstokenTw = twBean.getAccesstoken();											
												accesstokensecret = twBean.getAccesstokensecret();											
												consumerkey = twBean.getConsumerkey();											
												consumerkeysecret = twBean.getConsumerkeysecret();											
											}							

											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendTwitTotwitter/"+partnerId+"/"+accesstokenTw+"/"+accesstokensecret+"/"+consumerkey+"/"+consumerkeysecret);		
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String twitterBody = response.getEntity(String.class);
											System.out.println("Response body for sendTwitTotwitter ===== >"+twitterBody);
										}
										else{
											System.out.println("TwBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigTw object Null ----------------");
								}
							}						

							else if(channelId.equalsIgnoreCase("SMS")){
								String resp3 = "";					
								String to="";
								String from="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigSms/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp3= response2.getEntity(String.class);							

								//parser ConfigSms Details							
								ArrayList<SmsBean> resparserConfigSms = cp.parseConfigSms(resp3);
								System.out.println("DevAcmgmt.PutLampDimLevel()"+resp3);
								if(resparserConfigSms!=null && resparserConfigSms.size()>0){
									for(int index2=0; index2<resparserConfigSms.size(); index2++){
										SmsBean smslistBean = resparserConfigSms.get(index2);
										if(smslistBean.smsBeans.size()>0){                
											for(int k=0; k<smslistBean.smsBeans.size(); k++){
												SmsBean smsBean = smslistBean.smsBeans.get(k);							
												Accountsid = smsBean.getAccountsid();											
												token = smsBean.getToken();											
												to = smsBean.getTos();											
												from = smsBean.getFroms();											
											}									
											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendSMS/"+Accountsid+"/"+token+"/"+to+"/"+from);
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String SMSBody = response.getEntity(String.class);
											System.out.println("Response body for SMS Send ===== >"+SMSBody);
										}
										else{
											System.out.println("SmsBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigSms object Null ----------------");
								}
							}
							else if(channelId.equalsIgnoreCase("EMAIL")){
								//Get Email Config 
								String defaultmail="";
								String outgoingmailserverhost="";
								String resp3 = "";					
								String outgoingmailport="";
								String userid="";
								String userpwd="";
								String emailxml="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigEmail/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp3= response2.getEntity(String.class);

								//parser ConfigSms Details							
								ArrayList<EmailBean> resparserConfigEmail = cp.parseEmailInfo(resp3);
								System.out.println("DevAcmgmt.PutLampDimLevel()"+resp3);
								if(resparserConfigEmail!=null && resparserConfigEmail.size()>0){
									for(int index2=0; index2<resparserConfigEmail.size(); index2++){
										EmailBean emaillistBean = resparserConfigEmail.get(index2);
										if(emaillistBean.emailBeans.size()>0){                
											for(int k=0; k<emaillistBean.emailBeans.size(); k++){
												EmailBean emailBean = emaillistBean.emailBeans.get(k);							
												defaultmail = emailBean.getDefaultmail();											
												outgoingmailserverhost = emailBean.getOutgoingmailserverhost();											
												outgoingmailport = emailBean.getOutgoingmailport();											
												userid = emailBean.getUserid();	
												userpwd = emailBean.getUserpasswd();	
											}					

											emailxml ="<email>"+												
													"<defaultmail>"+defaultmail+"</defaultmail>"+
													"<outgoingmailserverhost>"+outgoingmailserverhost+"</outgoingmailserverhost>"+	
													"<outgoingmailport>"+outgoingmailport+"</outgoingmailport>"+	
													"<userid>"+userid+"</userid>"+	
													"<userpwd>"+userpwd+"</userpwd>"+	
													"</email>";
											System.out.println("EMAIL  XML  =========>"+emailxml);

											//Send Email
											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendEMail/testmail/premanand216@gmail.com");		
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String emailBody = response.getEntity(String.class);
											System.out.println("Response body for Email Send ===== >"+emailBody);
										}
										else{
											System.out.println("EmailBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigEmail object Null ----------------");
								}

							}
							else{
								System.out.println("No Configuration Found For Channels --------------------");
							}	

						}

					}
					else{
						System.out.println("NO CHANNEL ID FOUND --------------------");
					}
				}

			}
		}
		else{
			System.out.println("Solution Not Registered (Drapes)###");

		}
		return Response.serverError().build();

	}	


	/*-------------------------------------------------- For Parking Space ---------------------------------------------------------*/

	@GET
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-parkingspace/getStatus")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response getParkingStatus(@PathParam("activationcode") String activationcode ,@PathParam("solutionid") String solutionid , @PathParam("udn") String udn){

		System.out.println("Udn Parking :: "+udn);
		System.out.println("activationcode =====>"+activationcode);
		try {
			boolean r = sm.getSolMapStatus(activationcode);
			if(r==true){
				// Get the Parking Status from HashTable
				String getRes 	= sm.getDeviceStatus(activationcode,udn);
				String xml = "<?xml version=\"1.0\"?>"+
						"<deviceStatus>"+				
						"<parkingStatus>"+getRes+"</parkingStatus>"+					
						"</deviceStatus>";
				System.out.println("Response :: \n"+xml);
				System.out.println("Current Parking  Status :: "+getRes);
				return Response.ok(xml).build();
			}
			else{
				String xml1 = "<?xml version=\"1.0\"?>"+
						"<deviceStatus>"+				
						"<parkingStatus>404</parkingStatus>"+					
						"</deviceStatus>";
				System.out.println("SolutionId Not Found For Parking ####  "+xml1);
				return Response.ok(xml1).build();
			}
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}	



	@POST
	@Path("{activationcode}/{solutionid}/{udn}/ras-service-parkingspace/actparkingspace")
	@Produces(MediaType.TEXT_XML)	
	@Consumes(MediaType.TEXT_XML)
	public Response actparkingspace(@PathParam("activationcode") String activationcode,@PathParam("solutionid") String solutionid,@PathParam("udn") String udn,String xml){

		System.out.println(" Inside actparkingspace Requet XMl For Parking ::::"+xml);
		System.out.println("Udn =====>"+udn);
		System.out.println("activationcode =====>"+activationcode);

		//Get  Solution Id from #map table
		boolean r = sm.getSolMapStatus(activationcode);
		if(r==true){

			// Set the Parking Status in HashTable  
			String ParkingStatus = xml.substring(xml.indexOf("<argNewParkingSpace>")+20, xml.lastIndexOf("</argNewParkingSpace>"));
			sm.setDeviceStatus(activationcode,udn, ParkingStatus);
			boolean res = sm.setDeviceStatus(activationcode,udn,ParkingStatus);
			System.out.println("# MapTable Updted "+res);	

			String resp = "";
			String channelId="";		
			String Accountsid="";
			String token="";

			//Get ChannelList
			Client c=Client.create();		
			WebResource resource=c.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannellist/"+activationcode);		
			ClientResponse response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
			System.out.println("res for NotificationServer Side ="+response.getStatus());
			resp= response.getEntity(String.class);		

			//Parse (PatnerId,ChannelId)
			ChannelParse cp = new ChannelParse();
			ArrayList<ChannelBean> resparser = cp.parseChannelList(resp);		
			if(resparser!=null && resparser.size()>0){
				for(int index=0; index<resparser.size(); index++){
					ChannelBean clistBean = resparser.get(index);
					if(clistBean.channelBeans.size()>0){                
						for(int i=0; i<clistBean.channelBeans.size(); i++){
							ChannelBean sBean = clistBean.channelBeans.get(i);							
							String partnerId = sBean.getPartnerid();
							System.out.println("partnerId ############# "+partnerId);
							channelId = sBean.getChannelid();
							System.out.println("channelId ############# "+channelId);

							if(channelId.equalsIgnoreCase("FACEBOOK")){
								String resp1 = "";							
								String accesstoken="";
								String appid="";
								String appSecret="";

								Client c1=Client.create();		
								WebResource resource1=c1.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigFb/"+partnerId+"/"+channelId);		
								ClientResponse response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response1.getStatus());
								resp1= response1.getEntity(String.class);							

								//parser ConfigFb Details							
								ArrayList<FbBean> resparserConfigFb = cp.parseConfigFb(resp1);
								if(resparserConfigFb!=null && resparserConfigFb.size()>0){
									for(int index1=0; index1<resparserConfigFb.size(); index1++){
										FbBean fblistBean = resparserConfigFb.get(index1);
										if(fblistBean.fbBeans.size()>0){                
											for(int j=0; j<fblistBean.fbBeans.size(); j++){
												FbBean fbBean = fblistBean.fbBeans.get(j);							
												accesstoken = fbBean.getAccesstoken();											
												appid = fbBean.getAppid();											
												appSecret = fbBean.getAppsecret();										
											}

											c1=Client.create();		
											resource1=c1.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendPostToFB/me/true/"+accesstoken);		
											response1=resource1.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String facebookBody = response1.getEntity(String.class);
											System.out.println("Response body for sendPostToFB ===== >"+facebookBody);											
										}
										else{
											System.out.println("FbBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigFb object Null ----------------");
								}
							}

							else if(channelId.equalsIgnoreCase("TWITTER")){
								String resp2 = "";							
								String accesstokenTw="";
								String accesstokensecret="";
								String consumerkey="";
								String consumerkeysecret="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigTw/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp2= response2.getEntity(String.class);							

								//parser ConfigTw Details							
								ArrayList<TwBean> resparserConfigTw = cp.parseConfigTw(resp2);
								if(resparserConfigTw!=null && resparserConfigTw.size()>0){
									for(int index2=0; index2<resparserConfigTw.size(); index2++){
										TwBean twlistBean = resparserConfigTw.get(index2);
										if(twlistBean.twBeans.size()>0){                
											for(int k=0; k<twlistBean.twBeans.size(); k++){
												TwBean twBean = twlistBean.twBeans.get(k);							
												accesstokenTw = twBean.getAccesstoken();											
												accesstokensecret = twBean.getAccesstokensecret();											
												consumerkey = twBean.getConsumerkey();											
												consumerkeysecret = twBean.getConsumerkeysecret();											
											}							

											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendTwitTotwitter/"+partnerId+"/"+accesstokenTw+"/"+accesstokensecret+"/"+consumerkey+"/"+consumerkeysecret);		
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String twitterBody = response.getEntity(String.class);
											System.out.println("Response body for sendTwitTotwitter ===== >"+twitterBody);
										}
										else{
											System.out.println("TwBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigTw object Null ----------------");
								}
							}						

							else if(channelId.equalsIgnoreCase("SMS")){
								String resp3 = "";					
								String to="";
								String from="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigSms/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp3= response2.getEntity(String.class);							

								//parser ConfigSms Details							
								ArrayList<SmsBean> resparserConfigSms = cp.parseConfigSms(resp3);
								System.out.println("DevAcmgmt.PutLampDimLevel()"+resp3);
								if(resparserConfigSms!=null && resparserConfigSms.size()>0){
									for(int index2=0; index2<resparserConfigSms.size(); index2++){
										SmsBean smslistBean = resparserConfigSms.get(index2);
										if(smslistBean.smsBeans.size()>0){                
											for(int k=0; k<smslistBean.smsBeans.size(); k++){
												SmsBean smsBean = smslistBean.smsBeans.get(k);							
												Accountsid = smsBean.getAccountsid();											
												token = smsBean.getToken();											
												to = smsBean.getTos();											
												from = smsBean.getFroms();											
											}									
											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendSMS/"+Accountsid+"/"+token+"/"+to+"/"+from);
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String SMSBody = response.getEntity(String.class);
											System.out.println("Response body for SMS Send ===== >"+SMSBody);
										}
										else{
											System.out.println("SmsBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigSms object Null ----------------");
								}
							}
							else if(channelId.equalsIgnoreCase("EMAIL")){
								//Get Email Config 
								String defaultmail="";
								String outgoingmailserverhost="";
								String resp3 = "";					
								String outgoingmailport="";
								String userid="";
								String userpwd="";
								String emailxml="";

								Client c2=Client.create();		
								WebResource resource2=c2.resource("http://"+Settings.ACTIVATION_SERVER+"/ActivationServer/service/getChannelConfigEmail/"+partnerId+"/"+channelId);		
								ClientResponse response2=resource2.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
								System.out.println("res for NotificationServer Side ="+response2.getStatus());
								resp3= response2.getEntity(String.class);

								//parser ConfigSms Details							
								ArrayList<EmailBean> resparserConfigEmail = cp.parseEmailInfo(resp3);
								System.out.println("DevAcmgmt.PutLampDimLevel()"+resp3);
								if(resparserConfigEmail!=null && resparserConfigEmail.size()>0){
									for(int index2=0; index2<resparserConfigEmail.size(); index2++){
										EmailBean emaillistBean = resparserConfigEmail.get(index2);
										if(emaillistBean.emailBeans.size()>0){                
											for(int k=0; k<emaillistBean.emailBeans.size(); k++){
												EmailBean emailBean = emaillistBean.emailBeans.get(k);							
												defaultmail = emailBean.getDefaultmail();											
												outgoingmailserverhost = emailBean.getOutgoingmailserverhost();											
												outgoingmailport = emailBean.getOutgoingmailport();											
												userid = emailBean.getUserid();	
												userpwd = emailBean.getUserpasswd();	
											}					

											emailxml ="<email>"+												
													"<defaultmail>"+defaultmail+"</defaultmail>"+
													"<outgoingmailserverhost>"+outgoingmailserverhost+"</outgoingmailserverhost>"+	
													"<outgoingmailport>"+outgoingmailport+"</outgoingmailport>"+	
													"<userid>"+userid+"</userid>"+	
													"<userpwd>"+userpwd+"</userpwd>"+	
													"</email>";
											System.out.println("EMAIL  XML  =========>"+emailxml);

											//Send Email
											c=Client.create();		
											resource=c.resource("http://"+Settings.NOTIFICATION_GATEWAY+"/NotificationGateway/notificationGateway/sendEMail/testmail/premanand216@gmail.com");		
											response=resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,xml);
											String emailBody = response.getEntity(String.class);
											System.out.println("Response body for Email Send ===== >"+emailBody);
										}
										else{
											System.out.println("EmailBean Size is Zero ---------------------");
										}
									}
								}
								else{
									System.out.println("parserConfigEmail object Null ----------------");
								}

							}
							else{
								System.out.println("No Configuration Found For Channels --------------------");
							}	

						}

					}
					else{
						System.out.println("NO CHANNEL ID FOUND --------------------");
					}
				}

			}
		}
		else{
			System.out.println("Solution Not Registered (Parking Space )###");

		}
		return Response.serverError().build();

	}




	/*------------------------------------------------- Register/DeRegister --------------------------------------------------------*/


	// RM Registration
	@POST
	@Path("{stgwid}/{solutionId}/registration")	
	public Response registration(@PathParam("stgwid") String stgw, @PathParam("solutionId") String solutionId){
		System.out.println("DevAcmgmt.registration()");		
		StatusManager sm			= new StatusManager();
		InventoryDeviceListParser dlp        = new InventoryDeviceListParser();
		InventoryDeviceParser dp 			= new InventoryDeviceParser();
		InventoryDevices dBean1 =null;
		InventoryDevices dBean2 =null;
		InventoryDevices dBean3 =null;
		InventoryDevices dBean4 =null;
		String deviceUdn =null;		

		Client c=Client.create();		
		WebResource resource=c.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMDevice/"+solutionId+"/smartdevicesenterprise");		
		ClientResponse response=resource.get(ClientResponse.class);
		String gdevlistsxml = response.getEntity(String.class);
		//System.out.println("SMART DEVICE XML "+gdevlistsxml);

		if(gdevlistsxml!=null){
			ArrayList<InventoryDevices> devlists = dlp.parseGlobalDeviceListsNew(gdevlistsxml);
			if(devlists!=null && devlists.size()>0){
				for(int index=0; index<devlists.size(); index++){
					InventoryDevices dListBean = devlists.get(index);
					if(dListBean.deviceBeans.size()>0){                
						for(int i=0; i<dListBean.deviceBeans.size(); i++){
							dBean1 = dListBean.deviceBeans.get(i);
							String deviceid = dBean1.getDeviceid();							
							System.out.println("SMART Device Id ====>"+deviceid);	
							Client client=Client.create();	
							WebResource resources = client.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMGateway/site/"+solutionId+"/devices/"+deviceid+"/Device_ProfileInfo");
							ClientResponse responses=resources.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
							String dinfoxml = responses.getEntity(String.class);		
							//System.out.println("SMART DEVICE INFO RESPONSE ... "+dinfoxml);

							InventoryDeviceInfo devInfo = dp.parseDeviceInfo(dinfoxml);							
							deviceUdn = devInfo.getUdn();
							System.out.println("SMART deviceUdn ##### "+deviceUdn);						
							boolean update = sm.registrationSoultion(solutionId, deviceUdn,"null");						
							System.out.println("<==REGISTERED==> "+update);	
						}
					}  
				}
			}
		}
		Client c1 = Client.create();
		WebResource resource1 = c1.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMDevice/"+solutionId+"/legacydevicesenterprise");
		ClientResponse response1 = resource1.get(ClientResponse.class);		
		String gdevlistsxml1 = response1.getEntity(String.class);
		//System.out.println("LEGACY DEVICE XML "+gdevlistsxml1);
		if(gdevlistsxml1!=null){
			ArrayList<InventoryDevices> devlists = dlp.parseGlobalDeviceListsNew(gdevlistsxml1);
			if(devlists!=null && devlists.size()>0){
				for(int index=0; index<devlists.size(); index++){
					InventoryDevices dListBean = devlists.get(index);
					if(dListBean.deviceBeans.size()>0){                
						for(int i=0; i<dListBean.deviceBeans.size(); i++){
							dBean2 = dListBean.deviceBeans.get(i);
							String deviceid = dBean2.getDeviceid();							
							System.out.println("LEGACY DEVICE Id ====>"+deviceid);	
							Client client=Client.create();	
							WebResource resources = client.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMGateway/site/"+solutionId+"/devices/"+deviceid+"/Device_ProfileInfo");
							ClientResponse responses=resources.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
							String dinfoxml = responses.getEntity(String.class);		
							//System.out.println("LEGACY DEVICE INFO RESPONSE ... "+dinfoxml);

							InventoryDeviceInfo devInfo = dp.parseDeviceInfo(dinfoxml);							
							deviceUdn = devInfo.getUdn();						
							System.out.println("LEGACY deviceUdn ##### "+deviceUdn);
							boolean update = sm.registrationSoultion(solutionId, deviceUdn,"null");						
							System.out.println("<==REGISTERED==> "+update);	
						}
					}  
				}
			}
		}

		Client c2 = Client.create();
		WebResource resource2 = c2.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMDevice/"+solutionId+"/ltndevicesenterprise");
		ClientResponse response2 = resource2.get(ClientResponse.class);		
		String gdevlistsxml2 = response2.getEntity(String.class);
		//System.out.println("LTN DEVICE XML "+gdevlistsxml2);
		if(gdevlistsxml2!=null){
			ArrayList<InventoryDevices> devlists = dlp.parseGlobalDeviceListsNew(gdevlistsxml2);
			if(devlists!=null && devlists.size()>0){
				for(int index=0; index<devlists.size(); index++){
					InventoryDevices dListBean = devlists.get(index);
					if(dListBean.deviceBeans.size()>0){                
						for(int i=0; i<dListBean.deviceBeans.size(); i++){
							dBean3 = dListBean.deviceBeans.get(i);
							String deviceid = dBean3.getDeviceid();							
							System.out.println("LTN DEVICE Id ====>"+deviceid);	
							Client client=Client.create();	
							WebResource resources = client.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMGateway/site/"+solutionId+"/devices/"+deviceid+"/Device_ProfileInfo");
							ClientResponse responses=resources.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
							String dinfoxml = responses.getEntity(String.class);		
							//System.out.println("LTN DEVICE INFO RESPONSE ... "+dinfoxml);

							InventoryDeviceInfo devInfo = dp.parseDeviceInfo(dinfoxml);							
							deviceUdn = devInfo.getUdn();									
							System.out.println("LTN deviceUdn ##### "+deviceUdn);
							boolean update = sm.registrationSoultion(solutionId, deviceUdn,"null");						
							System.out.println("<==REGISTERED==> "+update);	
						}
					}  
				}
			}
		}
		Client c3 = Client.create();
		WebResource resource3 = c3.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMDevice/"+solutionId+"/gatrewaydevicesenterprise");
		ClientResponse response3 = resource3.get(ClientResponse.class);		
		String gdevlistsxml3 = response3.getEntity(String.class);
		//System.out.println("GATEWAY DEVICE XML "+gdevlistsxml);	
		if(gdevlistsxml3!=null){
			ArrayList<InventoryDevices> devlists = dlp.parseGlobalDeviceListsNew(gdevlistsxml3);
			if(devlists!=null && devlists.size()>0){
				for(int index=0; index<devlists.size(); index++){
					InventoryDevices dListBean = devlists.get(index);
					if(dListBean.deviceBeans.size()>0){                
						for(int i=0; i<dListBean.deviceBeans.size(); i++){
							dBean4 = dListBean.deviceBeans.get(i);
							String deviceid = dBean4.getDeviceid();							
							System.out.println("GATEWAY DEVICE Id ====>"+deviceid);	
							Client client=Client.create();	
							WebResource resources = client.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMGateway/site/"+solutionId+"/devices/"+deviceid+"/Device_ProfileInfo");
							ClientResponse responses=resources.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
							String dinfoxml = responses.getEntity(String.class);		
							//System.out.println("GATEWAY DEVICE INFO RESPONSE ... "+dinfoxml);

							InventoryDeviceInfo devInfo = dp.parseDeviceInfo(dinfoxml);							
							deviceUdn = devInfo.getUdn();									
							System.out.println("GATEWAY deviceUdn ##### "+deviceUdn);
							boolean update = sm.registrationSoultion(solutionId, deviceUdn,"null");						
							System.out.println("<==REGISTERED==> "+update);	
						}
					}  
				}
			}
		}	
		if(dBean1==null&&dBean2==null&&dBean3==null&&dBean4==null){
			sm.registerSol(solutionId, "null");			
		}
		//Backend Registration
		String xml = "<?xml version=\"1.0\"?>"+
				"<register>"+
				"<address type=\"terminal/service\" name=\"dcg-ctrl\">"+
				"<publicIP>"+Settings.DCGIP+"</publicIP>"+
				"<privateIP>"+Settings.DCGIP+"</privateIP>"+
				"<publicPort>"+Settings.DCGPORT+"</publicPort>"+
				"<privatePort>"+Settings.DCGPORT+"</privatePort>"+
				"</address>"+
				"<address type=\"terminal/service\" name=\"ccg-reg\">"+
				"<publicIP>"+Settings.CCGIP+"</publicIP>"+
				"<privateIP>"+Settings.CCGIP+"</privateIP>"+
				"<publicPort>"+Settings.CCGPORT+"</publicPort>"+
				"<privatePort>"+Settings.CCGPORT+"</privatePort>"+
				"</address>"+
				"<address type=\"terminal/service\" name=\"ecg-ctrl\">"+
				"<publicIP>"+Settings.ECGIP+"</publicIP>"+
				"<privateIP>"+Settings.ECGIP+"</privateIP>"+
				"<publicPort>"+Settings.ECGPORT+"</publicPort>"+
				"<privatePort>"+Settings.ECGPORT+"</privatePort>"+
				"</address>"+
				"<address type=\"terminal/service\" name=\"icg-ctrl\">"+
				"<publicIP>"+Settings.ICGIP+"</publicIP>"+
				"<privateIP>"+Settings.ICGIP+"</privateIP>"+
				"<publicPort>"+Settings.ICGPORT+"</publicPort>"+
				"<privatePort>"+Settings.ICGPORT+"</privatePort>"+
				"</address>"+						
				"<customerID>sip:"+solutionId+"@unaas.com</customerID>"+
				"</register>";

		Client c4 = Client.create();
		WebResource resource4=c4.resource("http://"+Settings.BACKEND_DATABASES+"/BackEndGateway/register/"+stgw+"/"+solutionId+"/"+solutionId+"@unaas.com");		
		ClientResponse response4=resource4.type(MediaType.TEXT_PLAIN).put(ClientResponse.class,xml);
		//System.out.println("res for BackEndGateway Side ="+response.getStatus());		
		int status = response4.getStatus();		
		System.out.println("resp :"+status);
		return Response.ok().build();



	}



	// RM DeRegistration
	@POST
	@Path("{stgwid}/{solutionId}/deregistration")	
	public Response deRegistration(@PathParam("stgwid") String stgw ,@PathParam("solutionId") String solutionId){

		System.out.println("DevAcmgmt.deregistration()");
		StatusManager sm			= new StatusManager();
		InventoryDeviceListParser dlp        = new InventoryDeviceListParser();
		InventoryDeviceParser dp 			= new InventoryDeviceParser();
		String deviceUdn =null;

		Client c=Client.create();		
		WebResource resource=c.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMDevice/"+solutionId+"/smartdevicesenterprise");		
		ClientResponse response=resource.get(ClientResponse.class);
		String gdevlistsxml = response.getEntity(String.class);
		//System.out.println("SMART DEVICE XML "+gdevlistsxml);

		if(gdevlistsxml!=null){
			ArrayList<InventoryDevices> devlists = dlp.parseGlobalDeviceListsNew(gdevlistsxml);
			if(devlists!=null && devlists.size()>0){
				for(int index=0; index<devlists.size(); index++){
					InventoryDevices dListBean = devlists.get(index);
					if(dListBean.deviceBeans.size()>0){                
						for(int i=0; i<dListBean.deviceBeans.size(); i++){
							InventoryDevices dBean = dListBean.deviceBeans.get(i);
							String deviceid = dBean.getDeviceid();							
							System.out.println("SMART Device Id ====>"+deviceid);	
							Client client=Client.create();	
							WebResource resources = client.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMGateway/site/"+solutionId+"/devices/"+deviceid+"/Device_ProfileInfo");
							ClientResponse responses=resources.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
							String dinfoxml = responses.getEntity(String.class);		
							//System.out.println("SMART DEVICE INFO RESPONSE ... "+dinfoxml);

							InventoryDeviceInfo devInfo = dp.parseDeviceInfo(dinfoxml);							
							deviceUdn = devInfo.getUdn();
							System.out.println("SMART deviceUdn ##### "+deviceUdn);						
							boolean update = sm.deRegistrationSoultion(solutionId, deviceUdn);						
							System.out.println("<==DEREGISTERED==> "+update);	
						}
					}  
				}
			}
		}
		Client c1 = Client.create();
		WebResource resource1 = c1.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMDevice/"+solutionId+"/legacydevicesenterprise");
		ClientResponse response1 = resource1.get(ClientResponse.class);		
		String gdevlistsxml1 = response1.getEntity(String.class);
		//System.out.println("LEGACY DEVICE XML "+gdevlistsxml1);
		if(gdevlistsxml1!=null){
			ArrayList<InventoryDevices> devlists = dlp.parseGlobalDeviceListsNew(gdevlistsxml1);
			if(devlists!=null && devlists.size()>0){
				for(int index=0; index<devlists.size(); index++){
					InventoryDevices dListBean = devlists.get(index);
					if(dListBean.deviceBeans.size()>0){                
						for(int i=0; i<dListBean.deviceBeans.size(); i++){
							InventoryDevices dBean = dListBean.deviceBeans.get(i);
							String deviceid = dBean.getDeviceid();							
							System.out.println("LEGACY DEVICE Id ====>"+deviceid);	
							Client client=Client.create();	
							WebResource resources = client.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMGateway/site/"+solutionId+"/devices/"+deviceid+"/Device_ProfileInfo");
							ClientResponse responses=resources.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
							String dinfoxml = responses.getEntity(String.class);		
							//System.out.println("LEGACY DEVICE INFO RESPONSE ... "+dinfoxml);

							InventoryDeviceInfo devInfo = dp.parseDeviceInfo(dinfoxml);							
							deviceUdn = devInfo.getUdn();						
							System.out.println("LEGACY deviceUdn ##### "+deviceUdn);
							boolean update = sm.deRegistrationSoultion(solutionId, deviceUdn);						
							System.out.println("<==DEREGISTERED==> "+update);	
						}
					}  
				}
			}
		}

		Client c2 = Client.create();
		WebResource resource2 = c2.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMDevice/"+solutionId+"/ltndevicesenterprise");
		ClientResponse response2 = resource2.get(ClientResponse.class);		
		String gdevlistsxml2 = response2.getEntity(String.class);
		//System.out.println("LTN DEVICE XML "+gdevlistsxml2);
		if(gdevlistsxml2!=null){
			ArrayList<InventoryDevices> devlists = dlp.parseGlobalDeviceListsNew(gdevlistsxml2);
			if(devlists!=null && devlists.size()>0){
				for(int index=0; index<devlists.size(); index++){
					InventoryDevices dListBean = devlists.get(index);
					if(dListBean.deviceBeans.size()>0){                
						for(int i=0; i<dListBean.deviceBeans.size(); i++){
							InventoryDevices dBean = dListBean.deviceBeans.get(i);
							String deviceid = dBean.getDeviceid();							
							System.out.println("LTN DEVICE Id ====>"+deviceid);	
							Client client=Client.create();	
							WebResource resources = client.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMGateway/site/"+solutionId+"/devices/"+deviceid+"/Device_ProfileInfo");
							ClientResponse responses=resources.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
							String dinfoxml = responses.getEntity(String.class);		
							//System.out.println("LTN DEVICE INFO RESPONSE ... "+dinfoxml);

							InventoryDeviceInfo devInfo = dp.parseDeviceInfo(dinfoxml);							
							deviceUdn = devInfo.getUdn();									
							System.out.println("LTN deviceUdn ##### "+deviceUdn);
							boolean update = sm.deRegistrationSoultion(solutionId, deviceUdn);						
							System.out.println("<==DEREGISTERED==> "+update);	
						}
					}  
				}
			}
		}
		Client c3 = Client.create();
		WebResource resource3 = c3.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMDevice/"+solutionId+"/gatrewaydevicesenterprise");
		ClientResponse response3 = resource3.get(ClientResponse.class);		
		String gdevlistsxml3 = response3.getEntity(String.class);
		//System.out.println("GATEWAY DEVICE XML "+gdevlistsxml);	
		if(gdevlistsxml3!=null){
			ArrayList<InventoryDevices> devlists = dlp.parseGlobalDeviceListsNew(gdevlistsxml3);
			if(devlists!=null && devlists.size()>0){
				for(int index=0; index<devlists.size(); index++){
					InventoryDevices dListBean = devlists.get(index);
					if(dListBean.deviceBeans.size()>0){                
						for(int i=0; i<dListBean.deviceBeans.size(); i++){
							InventoryDevices dBean = dListBean.deviceBeans.get(i);
							String deviceid = dBean.getDeviceid();							
							System.out.println("GATEWAY DEVICE Id ====>"+deviceid);	
							Client client=Client.create();	
							WebResource resources = client.resource("http://"+Settings.BACKEND_DATABASES+"/DMBackEndGw/DMGateway/site/"+solutionId+"/devices/"+deviceid+"/Device_ProfileInfo");
							ClientResponse responses=resources.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
							String dinfoxml = responses.getEntity(String.class);		
							//System.out.println("GATEWAY DEVICE INFO RESPONSE ... "+dinfoxml);

							InventoryDeviceInfo devInfo = dp.parseDeviceInfo(dinfoxml);							
							deviceUdn = devInfo.getUdn();									
							System.out.println("GATEWAY deviceUdn ##### "+deviceUdn);
							boolean update = sm.deRegistrationSoultion(solutionId, deviceUdn);						
							System.out.println("<==DEREGISTERED==> "+update);	
						}
					}  
				}
			}
		}	

		resource=c.resource("http://"+Settings.BACKEND_DATABASES+"/BackEndGateway/deregister/"+stgw+"/"+solutionId+"/sip:"+solutionId+"@unaas.com");		
		response=resource.type(MediaType.TEXT_PLAIN).delete(ClientResponse.class);
		//System.out.println("res for BackEndGateway Deregister Side ="+response.getStatus());		
		int status = response.getStatus();				
		System.out.println("resp :"+status);
		return Response.ok().build();
	}


	//Added on 09.01.17 (Partner Portal Api's)
	@POST
	@Path("{solutionid}/{udn}/updatemap")
	@Produces(MediaType.TEXT_PLAIN)	
	@Consumes(MediaType.TEXT_PLAIN)
	public Response updateMap(@PathParam("solutionid") String solutionid,@PathParam("udn") String udn){	
		System.out.println("DevAcmgmt.updateMap()");
		System.out.println("solutionid ::::"+solutionid);
		System.out.println("udn ::::"+udn);
		boolean res = sm.setDeviceStatus(solutionid,udn,"null");
		System.out.println("# MapTable Updted "+res);

		return Response.ok().build();		
	}


	//Added on 10.01.17 (Partner Portal Api's)
	@GET
	@Path("{solutionid}/checkMap")
	public String checkMap(@PathParam("solutionid") String solutionid){
		System.out.println("DevAcmgmt.checkMap()");
		System.out.println("solutionid ::::"+solutionid);		
		boolean res = sm.getSolMapStatus(solutionid);		
		if(res==true){
			System.out.println("## Solution Id Found ##"+solutionid);
			return "201";	
		}
		else{
			System.out.println("## Solution Id Not Found ## "+solutionid);
			return "404";
		}			
	}




	//Added on 10.01.17 (Partner Portal Api's)
	@DELETE
	@Path("{solutionid}/{udn}/deletemap")
	@Produces(MediaType.TEXT_PLAIN)	
	@Consumes(MediaType.TEXT_PLAIN)
	public String deleteMap(@PathParam("solutionid") String solutionid,@PathParam("udn") String udn){	
		System.out.println("DevAcmgmt.deleteMap()");
		System.out.println("solutionid ::::"+solutionid);
		System.out.println("udn ::::"+udn);
		boolean res = sm.deleteMap(solutionid,udn);
		if(res==true){
			System.out.println("# Map Deleted "+res);
			return "200";
		}
		else{
			return "500";
		}				
	}



	//refreshTimOut(Gloud Gateway)
	@POST
	@Path("{stgwid}/{solutionId}/{id}/refreshTimeOut")	
	public Response refreshTimOut(@PathParam("stgwid") final String stgw, @PathParam("solutionId") final String solutionId,@PathParam("id") int timeset ){
		System.out.println("DevAcmgmt.refresh()");

		for(int i=0; i<timeset; timeset++){
			//--timeset;
			System.out.println("timeset===>"+timeset);
		}		

		new java.util.Timer().schedule( 
				new java.util.TimerTask() {
					@Override
					public void run() {			            	
						System.out.println("DevAcmgmt.refreshTimOut(...).new TimerTask() {...}.run()");		            	
						Client clients = Client.create();
						WebResource re=clients.resource("http://localhost:8090/DCG/"+stgw+"/"+solutionId+"/deregistration");
						ClientResponse authresponse=re.type(MediaType.TEXT_PLAIN).post(ClientResponse.class);    	

					}
				}, 
				timeset 
				);


		return null;		
	}

}
