package com.pojo;

import java.util.ArrayList;

public class FbBean  {

	private int serialno;
	String  partnerid;	
	String  accesstoken;
	String  appid;	
	String  appsecret;
	String  category;
	
	
	public ArrayList<FbBean> fbBeans = new ArrayList<FbBean>();
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	
	public ArrayList<FbBean> getFbBeans() {
		return fbBeans;
	}
	public void setFbBeans(ArrayList<FbBean> fbBeans) {
		this.fbBeans = fbBeans;
	}
	public String getAccesstoken() {
		return accesstoken;
	}
	public void setAccesstoken(String accesstoken) {
		this.accesstoken = accesstoken;
	}
	public String getAppid() {
		return appid;
	}
	public void setAppid(String appid) {
		this.appid = appid;
	}
	public String getAppsecret() {
		return appsecret;
	}
	public void setAppsecret(String appsecret) {
		this.appsecret = appsecret;
	}
	
	public String getPartnerid() {
		return partnerid;
	}
	public void setPartnerid(String partnerid) {
		this.partnerid = partnerid;
	}	
	
	public int getSerialno() {
		return serialno;
	}
	public void setSerialno(int serialno) {
		this.serialno = serialno;
	}	

}
