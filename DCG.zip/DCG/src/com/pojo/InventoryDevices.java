package com.pojo;

import java.util.ArrayList;

public class InventoryDevices {
	
	
	String deviceid;
	String devfname;
	String devType;
	String siteId;;
	String enterpriseId;;
	String catagory;
	String catname;	
	String spid;
	String protocol;		
	String modelId;
	String modelType;	
	String modelFrindlyName;
	String udn;
	

	public ArrayList<InventoryDevices> deviceBeans = new ArrayList<InventoryDevices>();
	public String getDeviceid() {
		return deviceid;
	}
	
	public String getSpid() {
		return spid;
	}
	public String getSiteId() {
		return siteId;
	}
	public String getEnterpriseId() {
		return enterpriseId;
	}

	public void setEnterpriseId(String enterpriseId) {
		this.enterpriseId = enterpriseId;
	}
	public void setSiteId(String siteId) {
		this.siteId = siteId;
	}
	public void setSpid(String spid) {
		this.spid = spid;
	}	
	
	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}
	public String getDevfname() {
		return devfname;
	}
	public void setDevfname(String devfname) {
		this.devfname = devfname;
	}
	public String getDevType() {
		return devType;
	}
	public void setDevType(String devType) {
		this.devType = devType;
	}
	
	public String getCatname() {
		return catname;
	}

	public void setCatname(String catname) {
		this.catname = catname;
	}
	
	public String getModelId() {
		return modelId;
	}

	public void setModelId(String modelId) {
		this.modelId = modelId;
	}

	public String getModelType() {
		return modelType;
	}

	public void setModelType(String modelType) {
		this.modelType = modelType;
	}

	public String getModelFrindlyName() {
		return modelFrindlyName;
	}

	public void setModelFrindlyName(String modelFrindlyName) {
		this.modelFrindlyName = modelFrindlyName;
	}
	
	public String getCatagory() {
		return catagory;
	}
	public void setCatagory(String catagory) {
		this.catagory = catagory;
	}
	public ArrayList<InventoryDevices> getDevices() {
		return deviceBeans;
	}
	public void setDevices(ArrayList<InventoryDevices> deviceBeans) {
		this.deviceBeans = deviceBeans;
	}
	
	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}
	public String getUdn() {
		return udn;
	}

	public void setUdn(String udn) {
		this.udn = udn;
	}

}
