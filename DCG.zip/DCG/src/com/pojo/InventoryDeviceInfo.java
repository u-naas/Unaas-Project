package com.pojo;

public class InventoryDeviceInfo {

	
	
	String category;
	String layoutGroup;
	String deviceId;	
	String deviceType;
	String friendlyName;	
	String l1;	
	String l2;	
	String spid;	
	String dmu;	
	String operatorId;	
	String cost;	
	String latitude;
	String longitude;	
	
	String altitude;
	String spotOwnerName;
	String spotFriendlyName;
	String lot;	
	String violations;
	String usetime;
	String usagetime;

	String switchid;
	String ipaddress;
	
	String app;
	String network;
	String cert;
	
	String enterpriseid;	
	String manufacturer;
	String manufacturUrl;

	String modelid;	
	String modeltype;
	
	String modelName;	
	String modelUrl;
	String serialNo;
	String udn;
	String upc;	
	String mimeType;
	String width;
	String height;
	String depth;
	String url;
	byte[] imagedata;
	
	public String getEnterpriseid() {
		return enterpriseid;
	}

	public void setEnterpriseid(String enterpriseid) {
		this.enterpriseid = enterpriseid;
	}
		
	public String getDeviceId() {
		return deviceId;
	}
	
	public String getLayoutGroup(){
		return layoutGroup;
	}

	public void setLayoutGroup(String layoutGroup)
	{
		this.layoutGroup=layoutGroup;
	}
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}		
	
	public String getDeviceType() {
		return deviceType;
	}
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	public String getFriendlyName() {
		return friendlyName;
	}
	public void setFriendlyName(String friendlyName) {
		this.friendlyName = friendlyName;
	}
	
	
	
	public String getL1() {
		return l1;
	}

	public void setL1(String l1) {
		this.l1 = l1;
	}

	public String getL2() {
		return l2;
	}

	public void setL2(String l2) {
		this.l2 = l2;
	}
	
	public String getSpid() {
		return spid;
	}

	public void setSpid(String spid) {
		this.spid = spid;
	}

	public String getDmu() {
		return dmu;
	}

	public void setDmu(String dmu) {
		this.dmu = dmu;
	}
	
	
	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	
	public String getCost() {
		return cost;
	}

	public void setCost(String cost) {
		this.cost = cost;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
	
	
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getManufacturUrl() {
		return manufacturUrl;
	}
	public void setManufacturUrl(String manufacturUrl) {
		this.manufacturUrl = manufacturUrl;
	}
	
	public String getModelName() {
		return modelName;
	}
	public void setModelName(String modelName) {
		this.modelName = modelName;
	}
	
	public String getModelid() {
		return modelid;
	}

	public void setModelid(String modelid) {
		this.modelid = modelid;
	}

	public String getModeltype() {
		return modeltype;
	}

	public void setModeltype(String modeltype) {
		this.modeltype = modeltype;
	}
	public String getModelUrl() {
		return modelUrl;
	}
	public void setModelUrl(String modelUrl) {
		this.modelUrl = modelUrl;
	}
	public String getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(String serialNo) {
		this.serialNo = serialNo;
	}
	public String getUdn() {
		return udn;
	}
	public void setUdn(String udn) {
		this.udn = udn;
	}
	public String getUpc() {
		return upc;
	}
	public void setUpc(String upc) {
		this.upc = upc;
	}
	public String getMimeType() {
		return mimeType;
	}
	public void setMimeType(String mimeType) {
		this.mimeType = mimeType;
	}
	public String getWidth() {
		return width;
	}
	public void setWidth(String width) {
		this.width = width;
	}
	public String getHeight() {
		return height;
	}
	public void setHeight(String height) {
		this.height = height;
	}
	public String getDepth() {
		return depth;
	}
	public void setDepth(String depth) {
		this.depth = depth;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public byte[] getImagedata() {
		return imagedata;
	}
	public void setImagedata(byte[] imagedata) {
		this.imagedata = imagedata;
	}
	public String getAltitude() {
		return altitude;
	}

	public void setAltitude(String altitude) {
		this.altitude = altitude;
	}

	public String getSpotOwnerName() {
		return spotOwnerName;
	}

	public void setSpotOwnerName(String spotOwnerName) {
		this.spotOwnerName = spotOwnerName;
	}

	public String getSpotFriendlyName() {
		return spotFriendlyName;
	}

	public void setSpotFriendlyName(String spotFriendlyName) {
		this.spotFriendlyName = spotFriendlyName;
	}

	public String getLot() {
		return lot;
	}

	public void setLot(String lot) {
		this.lot = lot;
	}

	public String getViolations() {
		return violations;
	}

	public void setViolations(String violations) {
		this.violations = violations;
	}

	public String getUsetime() {
		return usetime;
	}

	public void setUsetime(String usetime) {
		this.usetime = usetime;
	}

	public String getUsagetime() {
		return usagetime;
	}

	public void setUsagetime(String usagetime) {
		this.usagetime = usagetime;
	}
	
	public String getSwitchid() {
		return switchid;
	}

	public void setSwitchid(String switchid) {
		this.switchid = switchid;
	}

	public String getIpaddress() {
		return ipaddress;
	}

	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	
	
	public String getApp() {
		return app;
	}

	public void setApp(String app) {
		this.app = app;
	}

	public String getNetwork() {
		return network;
	}

	public void setNetwork(String network) {
		this.network = network;
	}

	public String getCert() {
		return cert;
	}

	public void setCert(String cert) {
		this.cert = cert;
	}
}
