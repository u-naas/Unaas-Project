package com.pojo;

import java.util.ArrayList;

public class TwBean  {

	private int serialno;
	String  partnerid;	
	String  accesstoken;
	String  accesstokensecret;
	String  consumerkey;
	String  consumerkeysecret;
	String  category;
	
	public ArrayList<TwBean> twBeans = new ArrayList<TwBean>();
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}	
	
	public ArrayList<TwBean> getTwBeans() {
		return twBeans;
	}
	public void setTwBeans(ArrayList<TwBean> twBeans) {
		this.twBeans = twBeans;
	}
	
	public String getAccesstokensecret() {
		return accesstokensecret;
	}
	public void setAccesstokensecret(String accesstokensecret) {
		this.accesstokensecret = accesstokensecret;
	}
	public String getConsumerkey() {
		return consumerkey;
	}
	public void setConsumerkey(String consumerkey) {
		this.consumerkey = consumerkey;
	}
	public String getConsumerkeysecret() {
		return consumerkeysecret;
	}
	public void setConsumerkeysecret(String consumerkeysecret) {
		this.consumerkeysecret = consumerkeysecret;
	}
	
	
	public String getAccesstoken() {
		return accesstoken;
	}
	public void setAccesstoken(String accesstoken) {
		this.accesstoken = accesstoken;
	}	
	
	public String getPartnerid() {
		return partnerid;
	}
	public void setPartnerid(String partnerid) {
		this.partnerid = partnerid;
	}	
	
	public int getSerialno() {
		return serialno;
	}
	public void setSerialno(int serialno) {
		this.serialno = serialno;
	}
	
	
}