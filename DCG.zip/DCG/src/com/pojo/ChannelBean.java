package com.pojo;

import java.util.ArrayList;



public class ChannelBean {

	
	String partnerid;
	String solutionid;	
	String channelid;
	String category;

	
	
	public ArrayList<ChannelBean> channelBeans = new ArrayList<ChannelBean>();
	
	public ArrayList<ChannelBean> getChannelBeans() {
		return channelBeans;
	}
	public void setChannelBeans(ArrayList<ChannelBean> channelBeans) {
		this.channelBeans = channelBeans;
	}
	public String getPartnerid() {
		return partnerid;
	}
	public void setPartnerid(String partnerid) {
		this.partnerid = partnerid;
	}
	public String getSolutionid() {
		return solutionid;
	}
	public void setSolutionid(String solutionid) {
		this.solutionid = solutionid;
	}
	public String getChannelid() {
		return channelid;
	}
	public void setChannelid(String channelid) {
		this.channelid = channelid;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	

}