package com.pojo;

import java.util.ArrayList;

public class EmailBean  {

	private int serialno;
	String partnerid;		
	String defaultmail;
	String outgoingmailserverhost;	
	String outgoingmailport;
	String userid;
	String userpasswd;
	String category;
	
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public ArrayList<EmailBean> emailBeans = new ArrayList<EmailBean>();
	
	public ArrayList<EmailBean> getEmailBeans() {
		return emailBeans;
	}
	public void setEmailBeans(ArrayList<EmailBean> emailBeans) {
		this.emailBeans = emailBeans;
	}
	public String getPartnerid() {
		return partnerid;
	}
	public void setPartnerid(String partnerid) {
		this.partnerid = partnerid;
	}
	public String getDefaultmail() {
		return defaultmail;
	}
	public void setDefaultmail(String defaultmail) {
		this.defaultmail = defaultmail;
	}
	public String getOutgoingmailserverhost() {
		return outgoingmailserverhost;
	}
	public void setOutgoingmailserverhost(String outgoingmailserverhost) {
		this.outgoingmailserverhost = outgoingmailserverhost;
	}
	public String getOutgoingmailport() {
		return outgoingmailport;
	}
	public void setOutgoingmailport(String outgoingmailport) {
		this.outgoingmailport = outgoingmailport;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUserpasswd() {
		return userpasswd;
	}
	public void setUserpasswd(String userpasswd) {
		this.userpasswd = userpasswd;
	}		
	
	public int getSerialno() {
		return serialno;
	}
	public void setSerialno(int serialno) {
		this.serialno = serialno;
	}

}
