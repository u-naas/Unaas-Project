package com.pojo;

import java.io.Serializable;
import java.util.ArrayList;

public class SmsBean {


	private int serialno;
	String  partnerid;		
	String  tos;
	String  froms;
	String accountsid;
	String token;
	String  category;
	
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public ArrayList<SmsBean> smsBeans = new ArrayList<SmsBean>();
	
	public ArrayList<SmsBean> getSmsBeans() {
		return smsBeans;
	}
	public void setSmsBeans(ArrayList<SmsBean> smsBeans) {
		this.smsBeans = smsBeans;
	}
	public String getTos() {
		return tos;
	}
	public void setTos(String tos) {
		this.tos = tos;
	}
	public String getFroms() {
		return froms;
	}
	public void setFroms(String froms) {
		this.froms = froms;
	}
	
	
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getAccountsid() {
		return accountsid;
	}
	public void setAccountsid(String accountsid) {
		this.accountsid = accountsid;
	}	
	
	public String getPartnerid() {
		return partnerid;
	}
	public void setPartnerid(String partnerid) {
		this.partnerid = partnerid;
	}
	
	
	public int getSerialno() {
		return serialno;
	}
	public void setSerialno(int serialno) {
		this.serialno = serialno;
	}
}
