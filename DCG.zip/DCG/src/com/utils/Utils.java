package com.utils;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class Utils {
	
	public static Document getDocument(String xmlstr){
		DocumentBuilder db = null;
		InputSource is = null;
		 Document doc = null;		
		 try{		 
			 db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			 is = new InputSource();
			 is.setCharacterStream(new StringReader(xmlstr));
			 doc = db.parse(is);		    
			 doc.getDocumentElement().normalize();
		 }catch (Exception e) {
				e.printStackTrace();		
         }		 
		
		return doc;
	}

	public static String getTagValue(String sTag, Element element)
	 {
		 NodeList nodeList = element.getElementsByTagName(sTag);
		 if((null != nodeList) && (nodeList.getLength() > 0))
		 {
			 return nodeList.item(0).getTextContent();
		 }		 
		 
		 return null;
	 }
	
	 public static String getChildTagValue(String sTag, Element element) 
	 {		 
		NodeList dtypeList = element.getElementsByTagName(sTag);		
		if((null != dtypeList) && (dtypeList.getLength() > 0))
		{			
			Element dtElement = (Element)dtypeList.item(0);
			if(dtElement!=null){
				NodeList textFNList = dtElement.getChildNodes();
				if((null != textFNList) && (textFNList.getLength() > 0 ))
				{					
					return ((Node)textFNList.item(0)).getNodeValue();
				}
			}						
		}
			
		return null;		
	 }	
	 
	 public static Node[] getChildNodes(Node node)
	 {
		 ArrayList<Node> nodeList = new ArrayList<Node>();
		 
		 NodeList nodesList = node.getChildNodes();	
		 if(null != nodesList ){
			 for(int i = 0; i < nodesList.getLength(); i++)
			 {
				 if(Node.ELEMENT_NODE == nodesList.item(i).getNodeType())
				 {
					 nodeList.add( nodesList.item(i));
				 }
			 }
		 }
		 
		 return toArray(nodeList);
	 }
	 
	 public static <T> T[] toArray(ArrayList<T> arrayList){
		 
			if(null == arrayList)
				 return null;	 
			 
			int count = 0;
			 Iterator<T> iterator = (Iterator<T>)arrayList.iterator();		 
			 while((null != iterator) && (iterator.hasNext()))
			 {			 
				 count++;
				 iterator.next();
			 }	  
			 
			 if(count > 0)
			 {
				 T[] tempArray =  (T[])java.lang.reflect.Array.newInstance(arrayList.get(0).getClass(),count);
				  
				  for (int index = 0; index < count; index++) {		 
						 T obj = arrayList.get(index);
						 tempArray[index] =  obj;			 
				 	 }
				
				  return tempArray;
			 }
			 
			 return null;
		  }
	
}
