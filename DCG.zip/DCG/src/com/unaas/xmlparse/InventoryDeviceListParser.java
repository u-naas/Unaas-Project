package com.unaas.xmlparse;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.pojo.InventoryDevices;
import com.utils.Utils;

public class InventoryDeviceListParser {
	
	private static final String CONST_INDEX="edb-index";
	private static final String CONST_ENTRY="entry";
	private static final String CONST_ROOT="device-lists";
	private static final String CONST_DEVICE_LIST="device-list";
	private static final String CONST_DEVICEID="deviceid";	
	private static final String CONST_PROFILEURI="DeviceProfileUri";
	private static final String CONST_DeviceServiceActionURI="DeviceServiceActionUri";
	
	
	private static final String CONST_DEVICE="device";	
	private static final String CONST_UDN="UDN";
	
	
	
	public String[] parseDeviceList(String xml){
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_INDEX).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_ENTRY).item(0);
			    	
				deviceListNodeEntry=doc.getElementsByTagName(CONST_ROOT).item(0);
			    if(null!=deviceListNodeEntry && deviceListNodeEntry.getNodeType()==Node.ELEMENT_NODE){
			    	Element rootElement=(Element)deviceListNodeEntry;
			    	Node deviceListNode=rootElement.getElementsByTagName(CONST_DEVICE_LIST).item(0);			    	
			    	 if(deviceListNode!=null){
				    		Element deviceListElement=(Element)deviceListNode;
				    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEID);	
				    		
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){ // changed
				    		String[] uri=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;
				    			 //uri[i]=deviceIdElement.getAttribute("uri");	
				    			 //String dProfileUri = "";
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_PROFILEURI);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					uri[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }
				    			 
				    			//System.out.println(" DeviceProfileUri ##################"+uri[i]);
				    			
				    		}		    		
			    		return uri;
			    		}
			    		else 
			    		   return null;
			    	}
			    }}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	
	
	
	
	
	public String parseDeviceUdn(String xml){
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);
				String udn ="";
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_DEVICE).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_UDN).item(0);
					 if(null != deviceListNodeEntry)
	    				{
	    					NodeList textFNList = deviceListNodeEntry.getChildNodes();
	    					udn = textFNList.item(0).getNodeValue();
	    				}			   
			    	}
			   return udn;
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	
	
	
	public static final String CONST_GLOBALDEVICELIST="global-device-list";
	public static final String CONST_FRIENDLYNAME="friendlyName";
	public static final String CONST_DEVICETYPE2="deviceType";
	public static final String CONST_MODELTYPE="modelType";
	public static final String CONST_MODELID="modelId";
	public static final String CONST_PROTOCOL="protocol";
	public static final String CONST_MODELFRINAME="modelFriendlyName";
	public static final String CONST_CATEGORY="category";
	public static final String CONST_udn="udn";
	Element element = null;
	Document doc = null;



	public ArrayList<InventoryDevices> parseGlobalDeviceListsNew(String xml){
		//System.out.println("Inside the parseGlobalDeviceLists ---------1 -------- ");
		ArrayList<InventoryDevices> devicelists = new ArrayList<InventoryDevices>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_GLOBALDEVICELIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				InventoryDevices dlist = this.parseDeviceListnew(noofchild[i]);			
				devicelists.add(dlist);
			}
			//System.out.println("devicelists ============>"+devicelists);
			return devicelists;

		}
		return null;
	}

	public InventoryDevices parseDeviceListnew(Node dlistNode){
		//System.out.println("Inside the parseDeviceList ---------2-------- ");
		InventoryDevices deviceListBean = new InventoryDevices();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			deviceListBean.setCatagory(element.getAttribute("category"));

			Node[] noofdev = Utils.getChildNodes(dlistNode);

			if(noofdev!= null && noofdev.length>0){
				for(int i=0; i<noofdev.length; i++){				
					InventoryDevices dev = this.parseDevicenew(noofdev[i]);
					deviceListBean.deviceBeans.add(dev);
				}
				return deviceListBean;
			}
		}
		return deviceListBean;
	}

	public InventoryDevices parseDevicenew(Node dNode){
		//System.out.println("Inside the parseDevice ---------3-------- ");
		InventoryDevices deviceBean = new InventoryDevices();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element develement = (Element)dNode;
			deviceBean.setDeviceid(develement.getAttribute("id"));
			deviceBean.setDevfname(Utils.getTagValue(CONST_FRIENDLYNAME,develement));
			deviceBean.setDevType(Utils.getTagValue(CONST_DEVICETYPE2,develement));
			deviceBean.setCatname(Utils.getTagValue(CONST_CATEGORY,develement));
			deviceBean.setModelId(Utils.getTagValue(CONST_MODELID,develement));
			deviceBean.setModelType(Utils.getTagValue(CONST_MODELTYPE,develement));
			deviceBean.setModelFrindlyName(Utils.getTagValue(CONST_MODELFRINAME,develement));
			deviceBean.setProtocol(Utils.getTagValue(CONST_PROTOCOL,develement));
			deviceBean.setUdn(Utils.getTagValue(CONST_udn,develement));
		}
		return deviceBean;
	}


}
