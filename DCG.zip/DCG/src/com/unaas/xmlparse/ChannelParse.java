package com.unaas.xmlparse;

import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;

import com.pojo.ChannelBean;
import com.pojo.FbBean;
import com.pojo.SmsBean;
import com.pojo.TwBean;
import com.pojo.EmailBean;
import com.utils.*;



public class ChannelParse {

	public static final String CONST_CHANNELLIST="global-channel-list";
	public static final String CONST_CATEGORY="category";
	public static final String CONST_CHANNELID="channelid";
	public static final String CONST_PARTNERID="partnerid";
	Element element = null;
	Document doc = null;


	public ArrayList<ChannelBean> parseChannelList(String xml){

		System.out.println("Inside the parseChannelList ---------1 -------- ");
		ArrayList<ChannelBean> channellists = new ArrayList<ChannelBean>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_CHANNELLIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				ChannelBean dlist = this.parseChannelListnew(noofchild[i]);			
				channellists.add(dlist);
			}
			//System.out.println("ChannelList ============>"+channellists);
			return channellists;

		}
		return null;
	}

	public ChannelBean parseChannelListnew(Node dlistNode){

		System.out.println("Inside the parseChannelListnew ---------2-------- ");
		ChannelBean channelListBean = new ChannelBean();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			channelListBean.setCategory(element.getAttribute("category"));

			Node[] noofdev = Utils.getChildNodes(dlistNode);

			if(noofdev!= null && noofdev.length>0){
				for(int i=0; i<noofdev.length; i++){				
					ChannelBean dev = this.parseChannelnew(noofdev[i]);
					channelListBean.channelBeans.add(dev);
				}
				return channelListBean;
			}
		}
		return channelListBean;
	}

	public ChannelBean parseChannelnew(Node dNode){

		System.out.println("Inside the parseChannelnew ---------3-------- ");
		ChannelBean channelBean = new ChannelBean();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element channelelement = (Element)dNode;
			channelBean.setPartnerid(channelelement.getAttribute("id"));
			channelBean.setChannelid(Utils.getTagValue(CONST_CHANNELID,channelelement));			
			channelBean.setPartnerid(Utils.getTagValue(CONST_PARTNERID,channelelement));			
		}
		return channelBean;
	}



	public static final String CONST_ACCESSTOKEN="accessToken";
	public static final String CONST_APPID="appid";
	public static final String CONST_APPSECRET="appsecret";


	public ArrayList<FbBean> parseConfigFb(String xml){

		System.out.println("Inside the parseConfigFb ---------1 -------- ");
		System.out.println("Facebook xml======>"+xml);
		ArrayList<FbBean> channellists = new ArrayList<FbBean>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_CHANNELLIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				FbBean dlist = this.parseChannelListnewFb(noofchild[i]);			
				channellists.add(dlist);
			}
			//System.out.println("ChannelList ============>"+channellists);
			return channellists;

		}
		return null;
	}

	public FbBean parseChannelListnewFb(Node dlistNode){

		System.out.println("Inside the parseChannelListnewFb ---------2-------- ");
		FbBean channelListBean = new FbBean();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			channelListBean.setCategory(element.getAttribute("category"));

			Node[] noofdev = Utils.getChildNodes(dlistNode);

			if(noofdev!= null && noofdev.length>0){
				for(int i=0; i<noofdev.length; i++){				
					FbBean dev = this.parseChannelnewFb(noofdev[i]);
					channelListBean.fbBeans.add(dev);
				}
				return channelListBean;
			}
		}
		return channelListBean;
	}

	public FbBean parseChannelnewFb(Node dNode){

		System.out.println("Inside the parseChannelnewFb ---------3-------- ");
		FbBean channelBean = new FbBean();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element channelelement = (Element)dNode;
			channelBean.setPartnerid(channelelement.getAttribute("id"));
			channelBean.setAccesstoken(Utils.getTagValue(CONST_ACCESSTOKEN,channelelement));			
			channelBean.setAppid(Utils.getTagValue(CONST_APPID,channelelement));
			channelBean.setAppsecret(Utils.getTagValue(CONST_APPSECRET,channelelement));			
		}
		return channelBean;
	}



	public static final String CONST_ACCESSTOKENSECRET="accessTokenSecret";
	public static final String CONST_CONSUMERKEY="consumerkey";
	public static final String CONST_CONSUMERKEYSCRET="consumerkeySecret";		

	public ArrayList<TwBean> parseConfigTw(String xml){

		System.out.println("Inside the parseConfigTw ---------1 -------- ");
		ArrayList<TwBean> channellists = new ArrayList<TwBean>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_CHANNELLIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				TwBean dlist = this.parseChannelListnewTw(noofchild[i]);			
				channellists.add(dlist);
			}
			//System.out.println("ChannelList ============>"+channellists);
			return channellists;

		}
		return null;
	}

	public TwBean parseChannelListnewTw(Node dlistNode){

		System.out.println("Inside the parseChannelListnewTw ---------2-------- ");
		TwBean channelListBean = new TwBean();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			channelListBean.setCategory(element.getAttribute("category"));

			Node[] noofdev = Utils.getChildNodes(dlistNode);

			if(noofdev!= null && noofdev.length>0){
				for(int i=0; i<noofdev.length; i++){				
					TwBean dev = this.parseChannelnewTw(noofdev[i]);
					channelListBean.twBeans.add(dev);
				}
				return channelListBean;
			}
		}
		return channelListBean;
	}

	public TwBean parseChannelnewTw(Node dNode){
		System.out.println("Inside the parseChannelnewTw ---------3-------- ");
		TwBean channelBean = new TwBean();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element channelelement = (Element)dNode;
			channelBean.setPartnerid(channelelement.getAttribute("id"));
			channelBean.setAccesstoken(Utils.getTagValue(CONST_ACCESSTOKEN,channelelement));			
			channelBean.setAccesstokensecret(Utils.getTagValue(CONST_ACCESSTOKENSECRET,channelelement));
			channelBean.setConsumerkey(Utils.getTagValue(CONST_CONSUMERKEY,channelelement));
			channelBean.setConsumerkeysecret(Utils.getTagValue(CONST_CONSUMERKEYSCRET,channelelement));			
		}
		return channelBean;
	}
	
	
	public static final String CONST_ACCOUNTSID="accountsid";
	public static final String CONST_ACCESSTOKENSMS="accesstoken";
	public static final String CONST_TO="to";	
	public static final String CONST_FROM="from";


	public ArrayList<SmsBean> parseConfigSms(String xml){
		System.out.println("parseConfigSms ===== >"+xml);
		System.out.println("Inside the parseConfigSms ---------1 -------- ");
		ArrayList<SmsBean> channellists = new ArrayList<SmsBean>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_CHANNELLIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				SmsBean dlist = this.parseChannelListnewSms(noofchild[i]);			
				channellists.add(dlist);
			}
			//System.out.println("ChannelList ============>"+channellists);
			return channellists;

		}
		return null;
	}

	public SmsBean parseChannelListnewSms(Node dlistNode){

		System.out.println("Inside the parseChannelListnewSms ---------2-------- ");
		SmsBean channelListBean = new SmsBean();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			channelListBean.setCategory(element.getAttribute("category"));

			Node[] noofdev = Utils.getChildNodes(dlistNode);

			if(noofdev!= null && noofdev.length>0){
				for(int i=0; i<noofdev.length; i++){				
					SmsBean dev = this.parseChannelnewSms(noofdev[i]);
					channelListBean.smsBeans.add(dev);
				}
				return channelListBean;
			}
		}
		return channelListBean;
	}

	public SmsBean parseChannelnewSms(Node dNode){
		System.out.println("Inside the parseChannelnewTw ---------3-------- ");
		SmsBean channelBean = new SmsBean();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element channelelement = (Element)dNode;
			channelBean.setPartnerid(channelelement.getAttribute("id"));
			channelBean.setAccountsid(Utils.getTagValue(CONST_ACCOUNTSID,channelelement));			
			channelBean.setToken(Utils.getTagValue(CONST_ACCESSTOKENSMS,channelelement));
			channelBean.setTos(Utils.getTagValue(CONST_TO,channelelement));
			channelBean.setFroms(Utils.getTagValue(CONST_FROM,channelelement));			
		}
		return channelBean;
	}
	
	


	public static final String CONST_CONFIGUREEMAIL="configureEmail";
	//public static final String CONST_PARTNERID="partnerid";
	public static final String CONST_DEFAULTMAIL="defaultmail";
	public static final String CONST_SERVERHOST="serverhost";
	public static final String CONST_SERVERPORT="serverport";	
	public static final String CONST_USERID="userid";
	public static final String CONST_PWD="pwd";

	public ArrayList<EmailBean> parseEmailInfo(String xml){	
		System.out.println("parseConfigSms ===== >"+xml);
		System.out.println("Inside the parseConfigSms ---------1 -------- ");
		ArrayList<EmailBean> channellists = new ArrayList<EmailBean>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_CHANNELLIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				EmailBean dlist = this.parseChannelListnewEmail(noofchild[i]);			
				channellists.add(dlist);
			}
			//System.out.println("ChannelList ============>"+channellists);
			return channellists;

		}
		return null;
	}

	public EmailBean parseChannelListnewEmail(Node dlistNode){

		System.out.println("Inside the parseChannelListnewSms ---------2-------- ");
		EmailBean channelListBean = new EmailBean();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			channelListBean.setCategory(element.getAttribute("category"));

			Node[] noofdev = Utils.getChildNodes(dlistNode);

			if(noofdev!= null && noofdev.length>0){
				for(int i=0; i<noofdev.length; i++){				
					EmailBean dev = this.parseChannelnewEmail(noofdev[i]);
					channelListBean.emailBeans.add(dev);
				}
				return channelListBean;
			}
		}
		return channelListBean;
	}

	public EmailBean parseChannelnewEmail(Node dNode){
		System.out.println("Inside the parseChannelnewTw ---------3-------- ");
		EmailBean channelBean = new EmailBean();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element channelelement = (Element)dNode;
			channelBean.setPartnerid(channelelement.getAttribute("id"));
			channelBean.setDefaultmail(Utils.getTagValue(CONST_DEFAULTMAIL,channelelement));			
			channelBean.setOutgoingmailserverhost(Utils.getTagValue(CONST_SERVERHOST,channelelement));
			channelBean.setOutgoingmailport(Utils.getTagValue(CONST_SERVERPORT,channelelement));
			channelBean.setUserid(Utils.getTagValue(CONST_USERID,channelelement));
			channelBean.setUserpasswd(Utils.getTagValue(CONST_PWD,channelelement));	
		}
		return channelBean;
	}



}