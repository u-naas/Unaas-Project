package com.unaas.xmlparse;

import com.pojo.InventoryDeviceInfo;
import com.utils.Utils;
import org.apache.commons.codec.binary.Base64;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

public class InventoryDeviceParser {

	public static final String CONST_CATEGORY="category";
	public static final String CONST_DEVICEID="deviceid";
	public static final String CONST_OPERATORID="operatorid";
	public static final String CONST_ROOTDEVICEBOOK="devicebook";
	public static final String CONST_SPEC_VERSION = "specVersion";
	public static final String CONST_MAJOR="major";
	public static final String CONST_MINOR="minor";
	public static final String CONST_DEVICE="device";
	public static final String CONST_DEVICETYPE="deviceType";
	public static final String CONST_FRIENDLYNAME="friendlyName";
	public static final String CONST_MANUFACTURER="manufacturer";
	public static final String CONST_MANUFACTURERURL="manufacturerURL";
	public static final String CONST_MODEL_ID="modelId";
	public static final String CONST_MODELNAME="modelName";
	public static final String CONST_MODEL_TYPE="modelType";
	public static final String CONST_MODELURL="modelURL";
	public static final String CONST_SERIAL_NO="serialNumber";
	public static final String CONST_UDN="UDN";
	public static final String CONST_UPC="UPC";    
	public static final String CONST_COST="cost"; 
	public static final String CONST_SPOTID="spotId";
	public static final String CONST_PROTOCOL="protocol";    
	public static final String CONST_ICONLIST="iconList";
	public static final String CONST_ICON="icon";

	public static final String CONST_SERVICELIST="serviceList";
	public static final String CONST_MIMETYPE="mimetype";
	public static final String CONST_WIDTH="width";
	public static final String CONST_HEIGHT="height";
	public static final String CONST_DEPTH="depth";
	public static final String CONST_URL="url";
	public static final String CONST_LATITUDE="latitude"; 
	public static final String CONST_LONGITUDE="longitude";
	public static final String CONST_IMAGEDATA="imagedata"; 
	public static final String CONST_ALTITUDE="altitude";	 
	public static final String CONST_USAGETIME="usagetime"; 
	public static final String CONST_USETIME="usetime";
	public static final String CONST_VIOLATIONS="violations";	 
	public static final String CONST_LOT="lot"; 
	public static final String CONST_SPOTOWNERNAME="spotOwnerName";
	public static final String CONST_SPOTFRIENDLY="spotFriendlyName";





	public InventoryDeviceInfo parseDeviceInfo(String xml){

		//System.out.println("SmartDeviceInfo.parseDeviceInfo()");
		Element deviceElement = null;	
		InventoryDeviceInfo dInfoBean = new InventoryDeviceInfo();		
		Document doc = Utils.getDocument(xml);			 
		Node deviceNode = doc.getElementsByTagName(CONST_DEVICE).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;	

			dInfoBean.setCategory(Utils.getChildTagValue(CONST_CATEGORY,deviceElement));
			dInfoBean.setOperatorId(Utils.getChildTagValue(CONST_OPERATORID,deviceElement));	
			dInfoBean.setDeviceId(Utils.getChildTagValue(CONST_DEVICEID,deviceElement));			  
			dInfoBean.setDeviceType(Utils.getChildTagValue(CONST_DEVICETYPE,deviceElement)) ;
			dInfoBean.setFriendlyName(Utils.getChildTagValue(CONST_FRIENDLYNAME, deviceElement));
			dInfoBean.setSpid(Utils.getChildTagValue(CONST_SPOTID,deviceElement));
			dInfoBean.setDmu(Utils.getChildTagValue(CONST_PROTOCOL,deviceElement));
			dInfoBean.setManufacturer(Utils.getChildTagValue(CONST_MANUFACTURER, deviceElement));
			dInfoBean.setManufacturUrl(Utils.getChildTagValue(CONST_MANUFACTURERURL, deviceElement));
			dInfoBean.setModelid(Utils.getChildTagValue(CONST_MODEL_ID, deviceElement));
			dInfoBean.setModelName(Utils.getChildTagValue(CONST_MODELNAME, deviceElement));
			dInfoBean.setModeltype(Utils.getChildTagValue(CONST_MODEL_TYPE, deviceElement));
			dInfoBean.setModelUrl(Utils.getChildTagValue(CONST_MODELURL, deviceElement));
			dInfoBean.setSerialNo(Utils.getChildTagValue(CONST_SERIAL_NO, deviceElement));
			dInfoBean.setUdn(Utils.getChildTagValue(CONST_UDN, deviceElement));
			dInfoBean.setUpc(Utils.getChildTagValue(CONST_UPC, deviceElement));
			dInfoBean.setCost(Utils.getChildTagValue(CONST_COST, deviceElement));

			dInfoBean.setMimeType(Utils.getChildTagValue(CONST_MIMETYPE,deviceElement));
			dInfoBean.setWidth(Utils.getChildTagValue(CONST_WIDTH,deviceElement));
			dInfoBean.setHeight(Utils.getChildTagValue(CONST_HEIGHT,deviceElement));
			dInfoBean.setDepth(Utils.getChildTagValue(CONST_DEPTH,deviceElement));
			dInfoBean.setUrl(Utils.getChildTagValue(CONST_URL,deviceElement));
			dInfoBean.setLatitude(Utils.getChildTagValue(CONST_LATITUDE, deviceElement));
			dInfoBean.setLongitude(Utils.getChildTagValue(CONST_LONGITUDE, deviceElement));

			dInfoBean.setAltitude(Utils.getChildTagValue(CONST_ALTITUDE, deviceElement));			   
			dInfoBean.setUsagetime(Utils.getChildTagValue(CONST_USAGETIME, deviceElement));
			dInfoBean.setUsetime(Utils.getChildTagValue(CONST_USETIME, deviceElement));
			dInfoBean.setViolations(Utils.getChildTagValue(CONST_VIOLATIONS, deviceElement));			   
			dInfoBean.setLot(Utils.getChildTagValue(CONST_LOT, deviceElement));
			dInfoBean.setSpotFriendlyName(Utils.getChildTagValue(CONST_SPOTFRIENDLY, deviceElement));
			dInfoBean.setSpotOwnerName(Utils.getChildTagValue(CONST_SPOTOWNERNAME, deviceElement)); 	
			dInfoBean.setImagedata(Base64.decodeBase64(Utils.getChildTagValue(CONST_IMAGEDATA, deviceElement)));

		}			 

		return dInfoBean;



	}	
	
}
