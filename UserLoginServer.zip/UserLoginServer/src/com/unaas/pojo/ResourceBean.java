package com.unaas.pojo;

import java.util.ArrayList;

public class ResourceBean {


	String link;
	String category;
	String entid;
	String opid;
	String rolename;
	String resourceid;
	String solution;



	public ArrayList<ResourceBean> resourceBeans = new ArrayList<ResourceBean>();
	
	public String getResourceid() {
		return resourceid;
	}

	public void setResourceid(String resourceid) {
		this.resourceid = resourceid;
	}

	public String getRolename() {
		return rolename;
	}

	public void setRolename(String rolename) {
		this.rolename = rolename;
	}


	public String getOpid() {
		return opid;
	}

	public void setOpid(String opid) {
		this.opid = opid;
	}
	
	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}
	public String getEntid() {
		return entid;
	}

	public void setEntid(String entid) {
		this.entid = entid;
	}
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}
	public String getSolution() {
		return solution;
	}

	public void setSolution(String solution) {
		this.solution = solution;
	}
	public ArrayList<ResourceBean> getResources() {
		return resourceBeans;
	}
	public void setResources(ArrayList<ResourceBean> resourceBeans) {
		this.resourceBeans = resourceBeans;
	}
}
