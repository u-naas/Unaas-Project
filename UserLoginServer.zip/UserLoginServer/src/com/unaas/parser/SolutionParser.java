package com.unaas.parser;

import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import com.unaas.utils.Utils;
import com.unaas.pojo.ResourceBean;


public class SolutionParser {


	public static final String CONST_RESOURCELIST="global-solution-list";
	public static final String CONST_CATEGORY="category";
	Element element = null;
	Document doc = null;


	public ArrayList<ResourceBean> parseSolutionList(String xml){
		System.out.println("Inside the SolutionList ---------1 -------- ");
		ArrayList<ResourceBean> resourcelists = new ArrayList<ResourceBean>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_RESOURCELIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				ResourceBean rlist = this.parseSolutionListnew(noofchild[i]);			
				resourcelists.add(rlist);
			}
			System.out.println("SolutionList ============>"+resourcelists);
			return resourcelists;

		}
		return null;
	}

	public ResourceBean parseSolutionListnew(Node dlistNode){
		System.out.println("Inside the SolutionList ---------2-------- ");
		ResourceBean resourceParseBean = new ResourceBean();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			resourceParseBean.setCategory(element.getAttribute("category"));

			Node[] noofres = Utils.getChildNodes(dlistNode);

			if(noofres!= null && noofres.length>0){
				for(int i=0; i<noofres.length; i++){				
					ResourceBean dev = this.parseSolutionnew(noofres[i]);
					resourceParseBean.resourceBeans.add(dev);
				}
				return resourceParseBean;
			}
		}
		return resourceParseBean;
	}

	public ResourceBean parseSolutionnew(Node dNode){
		System.out.println("Inside the SolutionList ---------3-------- ");
		ResourceBean resourceBean = new ResourceBean();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element develement = (Element)dNode;
			resourceBean.setSolution(develement.getAttribute("id"));
			System.out.println("Solution Id ======>"+resourceBean.getSolution());
		}
		return resourceBean;
	}	

}