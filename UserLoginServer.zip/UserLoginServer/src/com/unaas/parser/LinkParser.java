package com.unaas.parser;

import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.InputSource;
import com.unaas.utils.Utils;
import com.unaas.pojo.ResourceBean;


public class LinkParser {


	public static final String CONST_ENTLIST="global-link-list";
	public static final String CONST_CATEGORY="category";
	public static final String CONST_ENTID="entid";
	Element element = null;
	Document doc = null;


	public ArrayList<ResourceBean> parseLinkList(String xml){
		System.out.println("Inside the LinkList ---------1 -------- ");
		ArrayList<ResourceBean> devicelists = new ArrayList<ResourceBean>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_ENTLIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				ResourceBean dlist = this.parseLinkListnew(noofchild[i]);			
				devicelists.add(dlist);
			}
			System.out.println("LinkList ============>"+devicelists);
			return devicelists;

		}
		return null;
	}

	public ResourceBean parseLinkListnew(Node dlistNode){
		System.out.println("Inside the LinkList ---------2-------- ");
		ResourceBean deviceListBean = new ResourceBean();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			deviceListBean.setCategory(element.getAttribute("category"));

			Node[] noofdev = Utils.getChildNodes(dlistNode);

			if(noofdev!= null && noofdev.length>0){
				for(int i=0; i<noofdev.length; i++){				
					ResourceBean dev = this.parseLinknew(noofdev[i]);
					deviceListBean.resourceBeans.add(dev);
				}
				return deviceListBean;
			}
		}
		return deviceListBean;
	}

	public ResourceBean parseLinknew(Node dNode){
		System.out.println("Inside the LinkList ---------3-------- ");
		ResourceBean deviceBean = new ResourceBean();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element develement = (Element)dNode;
			deviceBean.setLink(develement.getAttribute("id"));
			deviceBean.setEntid(Utils.getTagValue(CONST_ENTID,develement));	
			System.out.println("Link ======>"+deviceBean.getLink());
			System.out.println("Ent Id ======>"+deviceBean.getEntid());
		}
		return deviceBean;
	}	

}