package com.unaas.utils;

import java.util.Properties;

public class Settings {
	
	public static String ACTIVATION_SERVER_PATH="http://192.168.1.151:8080";	                        
	public static String USERMANAGEMENT_URL="http://52.24.48.58:8080";
	public static String BACKENDGATEWAY_URL="http://52.24.48.58:8080";
	public static String KEYCLOAK_URL="http://52.24.48.58:8080";
	
	static{
		try{
	  		Properties prop = new Properties();		   			  
	  		prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("workspace.properties"));	  		
	  		ACTIVATION_SERVER_PATH="http://"+prop.getProperty("ACTIVATION_IPADDRESS")+":"+prop.getProperty("ACTIVATION_PORT");	  		                 
	  		USERMANAGEMENT_URL="http://"+prop.getProperty("USERMANAGEMENT_IP")+":"+prop.getProperty("USERMANAGEMENT_PORT");
	  		BACKENDGATEWAY_URL="http://"+prop.getProperty("BACKENDGATEWAY_IP")+":"+prop.getProperty("BACKENDGATEWAY_PORT");
	  		KEYCLOAK_URL="http://"+prop.getProperty("KEYCLOAK_IP")+":"+prop.getProperty("KEYCLOAK_PORT");
		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Error While Initializing Enterprise Workspace. Properties file is present");
		}
	}

}