package com.unaas.dao;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.ArrayList;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.unaas.parser.LinkParser;
import com.unaas.parser.ResourceParser;
import com.unaas.parser.SolutionParser;
import com.unaas.pojo.ResourceBean;
import com.unaas.utils.Settings;


public class Login {

	public ArrayList<ResourceBean> loginAuth(String domianname, String uid ,String pwd){

		System.out.println("Login.loginAuth()");	
		String resp4 = "";	
		ArrayList<ResourceBean> resources = new ArrayList<ResourceBean>();
		try{
			ResourceParser sp = new ResourceParser();

			//get parent id based on domain name
			Client c=Client.create();
			WebResource r=c.resource(Settings.ACTIVATION_SERVER_PATH+"/ActivationServer/service/getParentId/"+domianname);
			ClientResponse response=r.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);	
			String res1 = response.getEntity(String.class);
			int sts = response.getStatus();
			System.out.println("res1"+res1);
			//operator id parser
			ResourceBean oplist = sp.parseoperatorId(res1);	
			String parentId = oplist.getOpid();
			System.out.println("parentId  == "+parentId);

			if(sts==200){

				// authenticate user 
				Client c2=Client.create();
				WebResource r2=c2.resource(Settings.BACKENDGATEWAY_URL+"/BackEndGateway/CCCP/CCCPGateway/authopuser/"+uid+"/"+pwd);
				System.out.println("Login.loginAuth()"+Settings.BACKENDGATEWAY_URL+"/BackEndGateway/CCCP/CCCPGateway/authopuser/"+uid+"/"+pwd);
				ClientResponse response2=r2.type(MediaType.TEXT_PLAIN).post(ClientResponse.class);			
				int status = response2.getStatus();
				System.out.println("status ======> "+status);
				if(status==200){	

					// get role for user 
					Client c3=Client.create();
					WebResource r3=c3.resource(Settings.BACKENDGATEWAY_URL+"/BackEndGateway/CCCP/CCCPGateway/"+uid+"/getuserRole");
					ClientResponse response3=r3.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);				
					String respBody = response3.getEntity(String.class);

					// parsing role
					ResourceBean roles = sp.parseRoleId(respBody);
					String roleName=  roles.getRolename();
					System.out.println("roleName =======>"+roleName);				
					int st  = response3.getStatus();
					System.out.println("response value:"+st);

					// get resources for user
					int s =0;
					Client c4=Client.create();
					WebResource r4=c4.resource(Settings.BACKENDGATEWAY_URL+"/BackEndGateway/CCCP/CCCPGateway/"+parentId+"/"+roleName+"/getuserResources");
					ClientResponse response4=r4.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);				
					resp4 = response4.getEntity(String.class);	
					System.out.println("ROLE PROFILE XML ==> "+resp4);

					s=response4.getStatus();

					/*ArrayList<ResourceBean> resource = sp.parseResourceList(resp4);
					resources.addAll(resource);*/

					/*ArrayList<ResourceBean> resource =  sp.parseResourceIds(resp4);
					resources.addAll(resource);	*/	

					ArrayList<ResourceBean> resource =  sp.parseSolutionIdAndLink(resp4);
					resources.addAll(resource);

					if(s==200){						
						return resources;

					}else{
						System.out.println("Resources not Found");
						return resources;
					}
				}
				else{
					System.out.println(" UserId Not Valid");
					return null;
				}
			}else{
				System.out.println("Operator Id Not Valid");
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();			
		}		
		return  resources;
	}



	public ArrayList<ResourceBean> keycloakAuth(String domianname, String uid ,String pwd){

		System.out.println("Login.keycloakAuth()");	
		String resp4 = "";	
		ArrayList<ResourceBean> resources = new ArrayList<ResourceBean>();
		try{
			ResourceParser sp = new ResourceParser();

			//get parent id based on domain name
			Client c=Client.create();
			WebResource r=c.resource(Settings.ACTIVATION_SERVER_PATH+"/ActivationServer/service/getParentId/"+domianname);
			ClientResponse response=r.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);	
			String res1 = response.getEntity(String.class);
			int sts = response.getStatus();
			System.out.println("res1"+res1);
			//operator id parser
			ResourceBean oplist = sp.parseoperatorId(res1);	
			String parentId = oplist.getOpid();
			System.out.println("parentId  == "+parentId);

			if(sts==200){

				// authenticate user with key cloak
				String body = "username="+uid+"&password="+pwd+"&client_id=admin-cli&grant_type=password";
				Client c2=Client.create();
				WebResource r2=c2.resource(Settings.KEYCLOAK_URL+"/auth/realms/"+parentId+"/protocol/openid-connect/token");				
				ClientResponse response2=r2.type("application/x-www-form-urlencoded").post(ClientResponse.class,body);				
				String token = response2.getEntity(String.class);
				int resp = response2.getStatus();								
				System.out.println("status ======> "+resp);

				if(resp==200){	

					// get role for user 
					Client c3=Client.create();
					WebResource r3=c3.resource(Settings.BACKENDGATEWAY_URL+"/BackEndGateway/CCCP/CCCPGateway/"+uid+"/getuserRole");
					ClientResponse response3=r3.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);				
					String respBody = response3.getEntity(String.class);

					// parsing role
					ResourceBean roles = sp.parseRoleId(respBody);
					String roleName=  roles.getRolename();
					System.out.println("roleName =======>"+roleName);				
					int st  = response3.getStatus();
					System.out.println("response value:"+st);

					// get resources for user
					int s =0;
					Client c4=Client.create();
					WebResource r4=c4.resource(Settings.BACKENDGATEWAY_URL+"/BackEndGateway/CCCP/CCCPGateway/"+parentId+"/"+roleName+"/getuserResources");
					ClientResponse response4=r4.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);				
					resp4 = response4.getEntity(String.class);	
					System.out.println("ROLE PROFILE XML ==> "+resp4);

					s=response4.getStatus();				

					ArrayList<ResourceBean> resource =  sp.parseSolutionIdAndLink(resp4);
					resources.addAll(resource);

					if(s==200){						
						return resources;

					}else{
						System.out.println("Resources not Found");
						return resources;
					}
				}
				else{
					System.out.println(" UserId Not Valid");
					return null;
				}
			}else{
				System.out.println("Operator Id Not Valid");
				return null;
			}
		} catch (Exception e) {
			e.printStackTrace();			
		}		
		return  resources;
	}





	/*public String keycloakAuth() {		
		System.out.println("Login.keycloakAuth()");		
		String parentId ="";
		try{

			ResourceParser sp = new ResourceParser();

			//get parent id based on domain name
			Client c=Client.create();
			WebResource r=c.resource(Settings.ACTIVATION_SERVER_PATH+"/ActivationServer/service/getParentId/google");
			ClientResponse response=r.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);	
			String res = response.getEntity(String.class);
			System.out.println("res"+res);

			//Parent id parser
			ResourceBean oplist = sp.parseoperatorId(res);	
			parentId = oplist.getOpid();
			System.out.println("parentId  == "+parentId);			
		} catch (Exception e) {
			e.printStackTrace();			
		}		
		return parentId ;
	}*/



	/*public ArrayList<ResourceBean> getsolutions(String entid){

		System.out.println("Login.getsolutions()");		
		int s =0;
		String resp = "";		
		ArrayList<ResourceBean> links = new ArrayList<ResourceBean>();
		ArrayList<ResourceBean> link = null;
		Client c = Client.create();
		WebResource resource=c.resource(Settings.BACKENDGATEWAY_URL+"/DMBackEndGw/DMDevice/"+entid+"/getmapsols");
		ClientResponse response = resource.get(ClientResponse.class);
		String solutionxml = response.getEntity(String.class);
		System.out.println("Login.getsolutions()"+solutionxml);		
		ArrayList<ResourceBean> sollist = new SolutionParser().parseSolutionList(solutionxml);
		if(sollist!=null && sollist.size()>0){
			for(int index=0; index<sollist.size(); index++){
				ResourceBean resourcelistBean = sollist.get(index);
				if(resourcelistBean.resourceBeans.size()>0){                
					for(int i=0; i<resourcelistBean.resourceBeans.size(); i++){
						ResourceBean sBean = resourcelistBean.resourceBeans.get(i);							
						String solutionId = sBean.getSolution();
						System.out.println("SOLUTION ID ########  "+solutionId);						
						if(solutionId!=null){
							System.out.println("SOLUTION ID =======>"+solutionId);
							Client c4=Client.create();
							WebResource r4=c4.resource(Settings.BACKENDGATEWAY_URL+"/BackEndGateway/CCCP/CCCPGateway/getlink/"+solutionId);
							ClientResponse response4=r4.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);						
							resp= response4.getEntity(String.class);
							System.out.println("resp == >"+resp);
							s = response4.getStatus();
							//parsing link
							link =  new LinkParser().parseLinkList(resp);
							links.addAll(link);
						}
						else{
							System.out.println("Solutions not found");
							return sollist;
						}						
					}
					if(s==200){
						return links;
					}
					else{

						System.out.println("Links not found");
						return sollist;
					}
				}
			}
		}
		return sollist;
	}*/

}