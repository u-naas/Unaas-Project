package unaas.controller;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.unaas.utils.Settings;


@WebServlet("/SettingsServlet")
public class SettingsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	// @see HttpServlet#HttpServlet()


	//@see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		try{
			Properties prop=new Properties();
			prop.load(new FileInputStream(getServletContext().getRealPath("/WEB-INF/classes/workspace.properties")));
			String ip=prop.getProperty("ACTIVATION_IPADDRESS");
			String port=prop.getProperty("ACTIVATION_PORT");	 		             
			String usermanagementip=prop.getProperty("USERMANAGEMENT_IP");              
			String usermanagementport=prop.getProperty("USERMANAGEMENT_PORT"); 
			String backendgatewayip=prop.getProperty("BACKENDGATEWAY_IP");              
			String backendgatewayport=prop.getProperty("BACKENDGATEWAY_PORT");
			String keycloakip=prop.getProperty("KEYCLOAK_IP");
			String keycloakport=prop.getProperty("KEYCLOAK_PORT");
			String settingshtml="<html><head><title>User Login Server Settings</title></head>"+
					"<body><h1 align=\"center\">User Login Server Settings</h1>"+
					"<form method=\"post\" action=\""+"./SettingsServlet\">"+
					"<table width=\"50%\" align=\"center\" cellspacing=10 cellpadding=10>"+
					"<tr><td colspan=\"2\" align=\"center\">User Login Server Settings</td></tr>"+
					"<tr bgcolor=\"pink\"><td colspan=\"2\">ACTIVATION SERVER</td></tr>"+
					"<tr><td>IP Address</td><td><input type=\"text\" name=\"ip\" value=\""+ip+"\"></td></tr>"+
					"<tr><td>Port</td><td><input type=\"text\" name=\"port\" value=\""+port+"\"></td></tr>"+                               
					"<tr bgcolor=\"pink\"><td colspan=\"2\">USER MANAGEMENT</td></tr>"+                                                             
					"<tr><td>IP Address</td><td><input type=\"text\" name=\"usermanagementip\" value=\""+usermanagementip+"\"></td></tr>"+          
					"<tr><td>Port</td><td><input type=\"text\" name=\"usermanagementport\" value=\""+usermanagementport+"\"></td></tr>"+
					"<tr bgcolor=\"pink\"><td colspan=\"2\">BACKEND GATEWAY</td></tr>"+                                                             
					"<tr><td>IP Address</td><td><input type=\"text\" name=\"backendgatewayip\" value=\""+backendgatewayip+"\"></td></tr>"+          
					"<tr><td>Port</td><td><input type=\"text\" name=\"backendgatewayport\" value=\""+backendgatewayport+"\"></td></tr>"+
					"<tr bgcolor=\"pink\"><td colspan=\"2\">KEYCLOAK SERVER</td></tr>"+                                                             
					"<tr><td>IP Address</td><td><input type=\"text\" name=\"keycloakip\" value=\""+keycloakip+"\"></td></tr>"+          
					"<tr><td>Port</td><td><input type=\"text\" name=\"keycloakport\" value=\""+keycloakport+"\"></td></tr>"+					
					"<tr><td colspan=2 align=\"center\"><input type=\"SUBMIT\" value=\"Update\"></td></tr></table></form></body></html>";
			pw.println(settingshtml);

		}catch(Exception e){
			e.printStackTrace();
			pw.println("<h1>Error While Retrieving User Login Server Settings</h1>");
		}
		pw.close();
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ip=request.getParameter("ip");
		String port=request.getParameter("port");		
		String usermanagementip=request.getParameter("usermanagementip");              
		String usermanagementport=request.getParameter("usermanagementport");
		String backendgatewayip=request.getParameter("backendgatewayip");              
		String backendgatewayport=request.getParameter("backendgatewayport");		
		String keycloakip=request.getParameter("keycloakip");
		String keycloakport=request.getParameter("keycloakport");		
		Settings.ACTIVATION_SERVER_PATH="http://"+ip+":"+port;		                     
		Settings.USERMANAGEMENT_URL="http://"+usermanagementip+":"+usermanagementport;           
		Settings.BACKENDGATEWAY_URL="http://"+backendgatewayip+":"+backendgatewayport;
		Settings.KEYCLOAK_URL="http://"+keycloakip+":"+keycloakport;
		try{
			Properties prop = new Properties();		   			  
			prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("workspace.properties"));
			prop.setProperty("ACTIVATION_IPADDRESS",ip);
			prop.setProperty("ACTIVATION_PORT",port);			          
			prop.setProperty("USERMANAGEMENT_IP",usermanagementip);                 
			prop.setProperty("USERMANAGEMENT_PORT",usermanagementport); 
			prop.setProperty("BACKENDGATEWAY_IP",backendgatewayip);                 
			prop.setProperty("BACKENDGATEWAY_PORT",backendgatewayport);			
			prop.setProperty("KEYCLOAK_IP",keycloakip);                 
			prop.setProperty("KEYCLOAK_PORT",keycloakport);			
			prop.store(new FileOutputStream(getServletContext().getRealPath("/WEB-INF/classes/workspace.properties")),null);
			prop.load(new FileInputStream(getServletContext().getRealPath("/WEB-INF/classes/workspace.properties")));
			ip=prop.getProperty("ACTIVATION_IPADDRESS");
			port=prop.getProperty("ACTIVATION_PORT");		               
			usermanagementip=prop.getProperty("USERMANAGEMENT_IP");                       
			usermanagementport=prop.getProperty("USERMANAGEMENT_PORT");	
			backendgatewayip=prop.getProperty("BACKENDGATEWAY_IP");                       
			backendgatewayport=prop.getProperty("BACKENDGATEWAY_PORT");			
			keycloakip=prop.getProperty("KEYCLOAK_IP");                       
			keycloakport=prop.getProperty("KEYCLOAK_PORT");			
			PrintWriter pw=response.getWriter();
			String settingshtml="<html><head><title>User Login Server Settings</title></head>"+
					"<body><h1 align=\"center\">User Login Server Settings</h1>"+
					"<h2 align=\"center\">Settings Updated</h2>"+
					"<form method=\"post\" action=\""+"./SettingsServlet\">"+
					"<table width=\"50%\" align=\"center\" cellspacing=10 cellpadding=10>"+
					"<tr><td colspan=\"2\" align=\"center\">User Login Server Settings</td></tr>"+
					"<tr bgcolor=\"pink\"><td colspan=\"2\">ACTIVATION SERVER</td></tr>"+
					"<tr><td>IP Address</td><td><input type=\"text\" name=\"ip\" value=\""+ip+"\"></td></tr>"+
					"<tr><td>Port</td><td><input type=\"text\" name=\"port\" value=\""+port+"\"></td></tr>"+					     
					"<tr bgcolor=\"pink\"><td colspan=\"2\">USER MANAGEMENT</td></tr>"+                                                            
					"<tr><td>IP Address</td><td><input type=\"text\" name=\"usermanagementip\" value=\""+usermanagementip+"\"></td></tr>"+          
					"<tr><td>Port</td><td><input type=\"text\" name=\"usermanagementport\" value=\""+usermanagementport+"\"></td></tr>"+ 
					"<tr bgcolor=\"pink\"><td colspan=\"2\">BACKEND GATEWAY</td></tr>"+                                                             
					"<tr><td>IP Address</td><td><input type=\"text\" name=\"backendgatewayip\" value=\""+backendgatewayip+"\"></td></tr>"+          
					"<tr><td>Port</td><td><input type=\"text\" name=\"backendgatewayport\" value=\""+backendgatewayport+"\"></td></tr>"+
					"<tr bgcolor=\"pink\"><td colspan=\"2\">KEYCLOAK SERVER</td></tr>"+                                                             
					"<tr><td>IP Address</td><td><input type=\"text\" name=\"keycloakip\" value=\""+keycloakip+"\"></td></tr>"+          
					"<tr><td>Port</td><td><input type=\"text\" name=\"keycloakport\" value=\""+keycloakport+"\"></td></tr>"+
					"<tr><td colspan=2 align=\"center\"><input type=\"SUBMIT\" value=\"Update\"></td></tr></table></form></body></html>";
			pw.println(settingshtml);
			pw.close();
		}
		catch(Exception e){
			e.printStackTrace();
			PrintWriter pw=response.getWriter();
			pw.println("Error While Writing Settings to properties file");
			pw.close();
		}
	}

}
