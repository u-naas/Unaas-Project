package unaas.controller;

import java.net.URI;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import com.unaas.dao.Login;
import com.unaas.pojo.ResourceBean;
import com.unaas.utils.Settings;

public class Servicecontroller extends AbstractController {

	private HttpSession session;

	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest arg0, HttpServletResponse arg1) throws Exception {	
		String src=arg0.getParameter("src");		

		if(src.equals("2"))
		{
			// welcome page
			session=arg0.getSession(false);
			if(session!=null)
				session=null;
			return new ModelAndView("auth");
		}


		if(src.equals("0"))
		{
			// get login page
			session=arg0.getSession(false);
			if(session!=null)
				session=null;
			return new ModelAndView("loginpage");
		}


		if(src.equals("keycloak"))
		{
			// get keycloak login page
			session=arg0.getSession(false);
			if(session!=null)
				session=null;
			return new ModelAndView("keycloakauth");
		}		


		if(src.equals("1"))
		{			
			// get resources for user
			String userId=arg0.getParameter("userid");
			String pwd=arg0.getParameter("pwd");

			boolean domain = userId.contains("@");			
			if(domain!= false){
				String entId =userId.substring(userId.indexOf("@")+1,userId.lastIndexOf("."));			
				//String entId =userId.substring(userId.indexOf("@")+1);			
				String uid = userId.substring(0, userId.lastIndexOf("@"));


				//service class's object
				Login lo = new Login();
				ArrayList<ResourceBean> resources = lo.loginAuth(entId,uid,pwd);
				System.out.println("resources !!!!!!!!!! "+resources);
				if(resources!=null){
					session=arg0.getSession(true);						
					session.setAttribute("resources",resources);
					return new ModelAndView("index");
				}
				else{
					System.out.println("User Id not found");
					return new ModelAndView("reloginpage");
				}
			}
			else{
				System.out.println("Domain not found");
				return new ModelAndView("localDomain");
			}

		}		


		if(src.equals("3"))
		{			
			// get resources for user
			String userId=arg0.getParameter("userid");			
			String pwd=arg0.getParameter("pwd");

			boolean domain = userId.contains("@");			
			if(domain!= false){
				String entId =userId.substring(userId.indexOf("@")+1,userId.lastIndexOf("."));	
				//String entId =userId.substring(userId.indexOf("@")+1);
				String uid = userId.substring(0, userId.lastIndexOf("@"));

				//service class's object
				Login lo = new Login();
				ArrayList<ResourceBean> resources = lo.keycloakAuth(entId,uid,pwd);
				System.out.println("resources !!!!!!!!!! "+resources);
				if(resources!=null){
					session=arg0.getSession(true);						
					session.setAttribute("resources",resources);
					return new ModelAndView("index");
				}
				else{
					System.out.println("User Id not found");
					return new ModelAndView("reloginauth");
				}


			}
			else{
				System.out.println("Domain not found");
				return new ModelAndView("keycloakDomain");
			}			

		}

	/*	if(src.equals("keycloakauth"))
		{	
			Login lo = new Login();
			String realm = lo.keycloakAuth();			
			String url = Settings.KEYCLOAK_URL+"/auth/realms/"+realm+"/account";			
			return new ModelAndView("redirect:" + url);
		}	*/	



		/*if (src.equals("3")){

			// get solutions for enterprise
			Login lo = new Login();
			String entid = arg0.getParameter("resource");
			ArrayList<ResourceBean> solution = lo.getsolutions(entid);
			session.setAttribute("solution",solution);
			return new ModelAndView("index");

		}*/

		return null;	

	}		

}	
