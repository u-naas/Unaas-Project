package publicmw.utils;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.List;

import org.apache.log4j.Logger;

import com.amazonaws.AmazonClientException;
import com.amazonaws.AmazonServiceException;
import com.amazonaws.HttpMethod;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.ClasspathPropertiesFileCredentialsProvider;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.AccessControlList;
import com.amazonaws.services.s3.model.CannedAccessControlList;
import com.amazonaws.services.s3.model.GeneratePresignedUrlRequest;
import com.amazonaws.services.s3.model.GroupGrantee;
import com.amazonaws.services.s3.model.ObjectMetadata;
import com.amazonaws.services.s3.model.Permission;
import com.amazonaws.services.s3.model.PutObjectRequest;
import com.amazonaws.services.s3.model.S3Object;
import com.amazonaws.services.s3.model.S3ObjectSummary;
import com.amazonaws.services.s3.transfer.MultipleFileUpload;
import com.amazonaws.services.s3.transfer.TransferManager;
import publicmw.settings.Settings;

public class S3Util {

	public boolean uploadResFile(String TemplateId , String userid , String bucketName){
		S3Util fuS3 = new S3Util();
		try {	
			//Upload File (UNAAS-DEFAULT-V1\res\common\jquery\mobile\1.3.1\images\) Directory 	
			String key1        = TemplateId+"/res/common/jquery/mobile/1.3.1/images/ajax-loader.gif";
			String uploadFile1 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/jquery/mobile/1.3.1/images/ajax-loader.gif";
			fuS3.UploadFolderAndFile(bucketName, key1,uploadFile1);		
			String key2        = TemplateId+"/res/common/jquery/mobile/1.3.1/images/icons-18-black.png";
			String uploadFile2 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/jquery/mobile/1.3.1/images/icons-18-black.png";
			fuS3.UploadFolderAndFile(bucketName, key2,uploadFile2);		
			String key3        = TemplateId+"/res/common/jquery/mobile/1.3.1/images/icons-18-white.png";
			String uploadFile3 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/jquery/mobile/1.3.1/images/icons-18-white.png";
			fuS3.UploadFolderAndFile(bucketName, key3,uploadFile3);		
			String key4        = TemplateId+"/res/common/jquery/mobile/1.3.1/images/icons-36-black.png";
			String uploadFile4 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/jquery/mobile/1.3.1/images/icons-36-black.png";
			fuS3.UploadFolderAndFile(bucketName, key4,uploadFile4);		
			String key5        = TemplateId+"/res/common/jquery/mobile/1.3.1/images/icons-36-white.png";
			String uploadFile5 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/jquery/mobile/1.3.1/images/icons-36-white.png";
			fuS3.UploadFolderAndFile(bucketName, key5,uploadFile5);

			//Upload File (UNAAS-DEFAULT-V1\res\common\jquery\mobile\1.3.1\) Directory 		
			String key12        = TemplateId+"/res/common/jquery/mobile/1.3.1/jquery.mobile-1.3.1.min.css";
			String uploadFile12 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/jquery/mobile/1.3.1/jquery.mobile-1.3.1.min.css";
			fuS3.UploadFolderAndFile(bucketName, key12,uploadFile12);		
			String key13        = TemplateId+"/res/common/jquery/mobile/1.3.1/jquery.mobile-1.3.1.min.js";
			String uploadFile13 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/jquery/mobile/1.3.1/jquery.mobile-1.3.1.min.js";
			fuS3.UploadFolderAndFile(bucketName, key13,uploadFile13);

			//Upload File (UNAAS-DEFAULT-V1\res\common\ jquery\) Directory 						
			String key17       = TemplateId+"/res/common/jquery/jquery-1.8.3.min.js";
			String uploadFile17 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/jquery/jquery-1.8.3.min.js";
			fuS3.UploadFolderAndFile(bucketName, key17,uploadFile17);		

			//Upload File (UNAAS-DEFAULT-V1\res\common\pdev\) Directory 
			String key35        = TemplateId+"/res/common/pdev/regular.css";
			String uploadFile35 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/pdev/regular.css";
			fuS3.UploadFolderAndFile(bucketName, key35,uploadFile35);
			String key36        = TemplateId+"/res/common/pdev/screen.js";
			String uploadFile36 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/pdev/screen.js";
			fuS3.UploadFolderAndFile(bucketName, key36,uploadFile36);
			String key37        = TemplateId+"/res/common/pdev/small_screen.css";
			String uploadFile37 = Settings.GenPath+userid+"/"+TemplateId+"/res/common/pdev/small_screen.css";
			fuS3.UploadFolderAndFile(bucketName, key37,uploadFile37);

			//Upload File (UNAAS-DEFAULT-V1\res\ userTemplates\default\images\) Directory 
			String key45        = TemplateId+"/res/userTemplates/default/images/1loading.gif";
			String uploadFile45 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/1loading.gif";
			fuS3.UploadFolderAndFile(bucketName, key45,uploadFile45);
			String key46       = TemplateId+"/res/userTemplates/default/images/2loading.gif";
			String uploadFile46 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/2loading.gif";
			fuS3.UploadFolderAndFile(bucketName, key46,uploadFile46);		
			String key42        = TemplateId+"/res/userTemplates/default/images/bulb-icon.png";
			String uploadFile42 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/bulb-icon.png";
			fuS3.UploadFolderAndFile(bucketName, key42,uploadFile42);			
			String key55        = TemplateId+"/res/userTemplates/default/images/cfanoff.png";
			String uploadFile55 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/cfanoff.png";
			fuS3.UploadFolderAndFile(bucketName, key55,uploadFile55);
			String key56       = TemplateId+"/res/userTemplates/default/images/cfanon.gif";
			String uploadFile56 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/cfanon.gif";
			fuS3.UploadFolderAndFile(bucketName, key56,uploadFile56);		
			String key58       = TemplateId+"/res/userTemplates/default/images/closeDrapes.jpg";
			String uploadFile58 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/closeDrapes.jpg";
			fuS3.UploadFolderAndFile(bucketName, key58,uploadFile58);
			String key59       = TemplateId+"/res/userTemplates/default/images/openDrapes.jif";
			String uploadFile59 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/openDrapes.jif";
			fuS3.UploadFolderAndFile(bucketName, key59,uploadFile59);			
			String key43        = TemplateId+"/res/userTemplates/default/images/light.png";
			String uploadFile43 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/light.png";
			fuS3.UploadFolderAndFile(bucketName, key43,uploadFile43);
			String key44       = TemplateId+"/res/userTemplates/default/images/light_b.png";
			String uploadFile44 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/light_b.png";
			fuS3.UploadFolderAndFile(bucketName, key44,uploadFile44);				
			String key73        = TemplateId+"/res/userTemplates/default/images/loading.gif";
			String uploadFile73 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/loading.gif";
			fuS3.UploadFolderAndFile(bucketName, key73,uploadFile73);
			
			String key73a       = TemplateId+"/res/userTemplates/default/images/notconnted.png";
			String uploadFile73a = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/images/notconnted.png";
			fuS3.UploadFolderAndFile(bucketName, key73a,uploadFile73a);

			//Upload File (UNAAS-DEFAULT-V1\res\ userTemplates\default\icons\) Directory 
			String key89        = TemplateId+"/res/userTemplates/default/icons/01-refresh.png";
			String uploadFile89 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/icons/01-refresh.png";
			fuS3.UploadFolderAndFile(bucketName, key89,uploadFile89);

			String key90        = TemplateId+"/res/userTemplates/default/icons/02-redo.png";
			String uploadFile90 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/icons/02-redo.png";
			fuS3.UploadFolderAndFile(bucketName, key90,uploadFile90);

			String key91       = TemplateId+"/res/userTemplates/default/icons/06-magnify.png";
			String uploadFile91 = Settings.GenPath+userid+"/"+TemplateId+"/res/userTemplates/default/icons/06-magnify.png";
			fuS3.UploadFolderAndFile(bucketName, key91,uploadFile91);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;		
	}


	public boolean s3UploadIotFile(String sFile , String userid , String bucketName,String personalizedS3Folder){
		S3Util fuS3 = new S3Util();
		try {						
			fuS3.UploadFolderAndFile(bucketName,personalizedS3Folder,sFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;

	}

	public boolean s3UploadInfoFile(String sFile , String userid , String bucketName,String personalizedS3Folder){
		S3Util fuS3 = new S3Util();
		try {						
			fuS3.UploadFolderAndFile(bucketName,personalizedS3Folder,sFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;

	}

	public boolean s3UploadSelfFile(String sFile , String userid , String bucketName,String personalizedS3Folder){
		S3Util fuS3 = new S3Util();
		try {						
			fuS3.UploadFolderAndFile(bucketName,personalizedS3Folder,sFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;

	}


	public boolean s3UploadIndexFile(String sFile , String userid , String bucketName,String personalizedS3Folder){
		S3Util fuS3 = new S3Util();
		try {						
			fuS3.UploadFolderAndFile(bucketName,personalizedS3Folder,sFile);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;

	}


	public URL s3ReturnIndexUrl(String bucketName,String key){
		URL url =null;
		try {			
			AmazonS3 s3 = new AmazonS3Client(new ProfileCredentialsProvider());
			System.out.println("Generating pre-signed URL.");
			java.util.Date expiration = new java.util.Date();
			long milliSeconds = expiration.getTime();
			//milliSeconds += 1000 * 60 * 60; // Add 1 hour.
			milliSeconds += 1000*60*60*24*365; // Add 1 year.
			expiration.setTime(milliSeconds);
			GeneratePresignedUrlRequest generatePresignedUrlRequest = new GeneratePresignedUrlRequest(bucketName,key);
			generatePresignedUrlRequest.setMethod(HttpMethod.GET); 
			generatePresignedUrlRequest.setExpiration(expiration);

			url = s3.generatePresignedUrl(generatePresignedUrlRequest); 
			System.out.println("IndexUrl  = " + url.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return url;

	}


	public boolean createFolder(String bucketName, String folderName, AmazonS3 client) {
		try{
			// create meta-data for your folder and set content-length to 0
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentLength(0);
			// create empty content
			InputStream emptyContent = new ByteArrayInputStream(new byte[0]);
			// create a PutObjectRequest passing the folder name suffixed by /
			PutObjectRequest putObjectRequest = new PutObjectRequest(bucketName,
					folderName, emptyContent, metadata);
			// send request to S3 to create folder
			client.putObject(putObjectRequest);
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			System.out.println("Folder not Creating !!!!!!!!!!!!!!!!!!! ");

		}
		return false;
	}

	public void uploadTos3(String path,String bucket){

		File folder = new File(path);
		AmazonS3 s3client = new AmazonS3Client(new ProfileCredentialsProvider());

		AWSCredentials credentials = null;
		credentials = new ProfileCredentialsProvider("default").getCredentials();

		AccessControlList acl = new AccessControlList();
		acl.grantPermission(GroupGrantee.AllUsers,Permission.FullControl);

		TransferManager tm = new TransferManager( new AmazonS3Client(credentials));	
		//s3client.setObjectAcl(bucket, path, CannedAccessControlList.BucketOwnerFullControl);
		MultipleFileUpload upload = tm.uploadDirectory( bucket, folder.getName(), folder, true );
		System.out.println("################# Uploading Folder in s3 ###########################");
		try {
			upload.waitForCompletion();
		} catch (AmazonServiceException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (AmazonClientException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		tm.shutdownNow();
	}


	public boolean UploadFolderAndFile(String bucketName, String keyName,String uploadFileName){
		AmazonS3 s3client = new AmazonS3Client(new ProfileCredentialsProvider());
		AccessControlList acl = new AccessControlList();
		acl.grantPermission(GroupGrantee.AllUsers,Permission.FullControl);
		try {
			System.out.println("Uploading a File in S3 ############ "+keyName+"\n");
			File file = new File(uploadFileName);
			s3client.putObject(new PutObjectRequest(bucketName, keyName, file).withAccessControlList(acl));		


		} catch (AmazonServiceException ase) {
			System.out.println("Caught an AmazonServiceException, which " +
					"means your request made it " +
					"to Amazon S3, but was rejected with an error response" +
					" for some reason.");
			System.out.println("Error Message:    " + ase.getMessage());
			System.out.println("HTTP Status Code: " + ase.getStatusCode());
			System.out.println("AWS Error Code:   " + ase.getErrorCode());
			System.out.println("Error Type:       " + ase.getErrorType());
			System.out.println("Request ID:       " + ase.getRequestId());
		} catch (AmazonClientException ace) {
			System.out.println("Caught an AmazonClientException, which " +
					"means the client encountered " +
					"an internal error while trying to " +
					"communicate with S3, " +
					"such as not being able to access the network.");
			System.out.println("Error Message: " + ace.getMessage());
		}
		return true;		
	}



	public boolean check(String userId,String activation){	

		try {			
			AWSCredentials credentials = null;
			credentials = new ProfileCredentialsProvider("default").getCredentials();

			// create a client connection based on credentials
			AmazonS3 s3 = new AmazonS3Client(credentials);

			Region usWest2 = Region.getRegion(Regions.US_WEST_2);
			s3.setRegion(usWest2);  	    
			S3Object object = s3.getObject(userId,activation+"personalise/index.html");
			System.out.println("check ############## personalizedS3Folder "+object); 

		} catch (AmazonServiceException e) {
			String errorCode = e.getErrorCode();
			if (!errorCode.equals("NoSuchKey")) {
				throw e;
			}
			Logger.getLogger(getClass()).debug("No such key!!!", e);
			return false;
		}

		return true;

	}



	/**
	 * This method first deletes all the files in given folder and than the
	 * folder itself
	 */
	public void deleteFolder(String bucketName, String folderName, AmazonS3 client) {
		List<S3ObjectSummary> fileList = 
				client.listObjects(bucketName, folderName).getObjectSummaries();
		for (S3ObjectSummary file : fileList) {
			client.deleteObject(bucketName, file.getKey());
		}
		client.deleteObject(bucketName, folderName);
		System.out.println("################ Deleteing Personlized Folder in S3 ###############################");
	}


	/*
	//Upload file in S3
	String fileName = folderName + "/" + "testvideo.mp4";
	s3.putObject(new PutObjectRequest(bucketName, fileName, 
			new File("C:\\Users\\user\\Desktop\\testvideo.mp4")));

	//Deleting Bucket
	s3.deleteBucket(bucketName);

	//Deleting File
	s3.deleteObject(bucketName, fileName);*/


}
