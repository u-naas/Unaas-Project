

package publicmw.service;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import publicmw.parse.DomainPolicy;
import publicmw.parse.InfoDomain;
import publicmw.parse.IotDomain;
import publicmw.parse.customer;
import publicmw.pojo.AppInfo;
import publicmw.pojo.CMCInfo;
import publicmw.pojo.DeviceInfo;
import publicmw.pojo.DeviceRegister;
import publicmw.pojo.Info;
import publicmw.pojo.Iot;
import publicmw.pojo.RegistrationInfo;
import publicmw.pojo.User;
import publicmw.settings.Settings;
import publicmw.utils.S3Util;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.Bucket;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;





@Path("/personalize")
public class PersonalizeService {
	@Context
	ServletContext context;



	@POST
	@Produces(MediaType.TEXT_PLAIN)	
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/solution/{solutionid}")
	public String domainpolicySolution(@PathParam("solutionid") String solutionid,@Context HttpHeaders headers,@Context HttpServletRequest request){
		System.out.println("PersonalizeService.domainpolicySolution()");
		String acode=solutionid.substring(0,solutionid.indexOf("@"));

		String clientip=request.getRemoteAddr();
		String clientport=String.valueOf(request.getRemotePort());
		String publicip=clientip+":"+clientport;
		try{		
			String privateip=publicip;			
			Client client1=Client.create();
			WebResource resource1=client1.resource(Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customers/"+acode+"/users/sip:"+solutionid+"/userpolicy");
			ClientResponse polyresponse=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);		
			String policy=polyresponse.getEntity(String.class);
			if(policy.startsWith("404")){
				client1=null;
				resource1=null;
				polyresponse=null;
				policy=null;
				return "404";
			}
			else 
			{
				client1=null;
				resource1=null;
				polyresponse=null;
				String rres= masterindexSol(solutionid,policy,publicip,privateip);						
				if(rres.equals("201")){						
					System.out.println("PersonalizeService.domainpolicySolution() Response "+rres);
					return rres;
				}

				else{						
					System.out.println("master index not found for solution");
					return "500";
				}

			}			
		}catch(Exception e){
			e.printStackTrace();
			return "500";
		}


	}




	private String masterindexSol(String userid,String policyXml, String pubip, String privateip){

		System.out.println("PersonalizeService.masterindexSol()");
		System.out.println("Policy XML is "+policyXml);

		String cmcId = null;

		Client c = Client.create();
		WebResource resource = null;
		ClientResponse cresponse = null;

		String acode=userid.substring(0,userid.indexOf("@"));
		resource = c.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/CloudServer/"+acode+"/cloudserverid");
		cmcId = resource.get(String.class);
		String usertype=getDeviceType(cmcId);


		String cloudserverid;
		CMCInfo cmcInfo=new CMCInfo();

		if(usertype.equalsIgnoreCase("cloudserver"))
			cloudserverid=acode;
		else 
			cloudserverid=userid;


		if(policyXml!=null)
		{
			// Parse the solution domain policy

			DomainPolicy.parse(policyXml);	
			ArrayList<RegistrationInfo> infolist=new ArrayList<RegistrationInfo>();

			RegistrationInfo info = new RegistrationInfo();
			info.setDomainName("com");
			info.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info.setRegistrationType("service");
			infolist.add(info);

			RegistrationInfo info1 = new RegistrationInfo();
			info1.setDomainName("iot");
			info1.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info1.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info1.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info1.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info1.setRegistrationType("service");
			infolist.add(info1);

			RegistrationInfo info2 = new RegistrationInfo();
			info2.setDomainName("info");
			info2.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info2.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info2.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info2.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info2.setRegistrationType("service");
			infolist.add(info2);

			RegistrationInfo info3 = new RegistrationInfo();
			info3.setDomainName("ent");
			info3.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info3.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info3.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info3.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info3.setRegistrationType("service");
			infolist.add(info3);

			DeviceRegister dr = new DeviceRegister();
			dr.setCustomerId(userid);
			dr.setRegDate(Calendar.getInstance().getTime());
			dr.setAddressList(infolist);

			//preparing body

			String ppRequestBody="<?xml version=\"1.0\"?>"+
					"<userOpInfo>"+
					"<userType>SOLUTION</userType>"+
					"<activationCode>"+acode+"</activationCode>"+
					"<custId>"+cloudserverid+"</custId>"+
					"<userId>sip:"+userid+"</userId>";

			if(DomainPolicy.iotLink!=null)
			{
				int iotreg=201;
				cmcInfo.setInfo(true);
				System.out.println("Solution Registration Status for IOT domain is :"+iotreg);
				if(iotreg==200||iotreg==201)
				{
					ppRequestBody=ppRequestBody+"<iot>"+Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customer/"+acode+"/users/sip:"+userid+"/iot/master-index-enterprise"+"</iot>"; 

				}					   
				else{
					cmcInfo.setIot(false);
				}
			}      
			if(DomainPolicy.infoLink!=null)
			{
				int inforeg = 201;
				cmcInfo.setInfo(true);
				System.out.println("Solution Registration Status for info domain is :"+inforeg);
				if(inforeg==200||inforeg==201)
				{
					ppRequestBody=ppRequestBody+"<info>"+Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customer/"+acode+"/users/sip:"+userid+"/info/master-index-enterprise"+"</info>";

				}

			}  

			ppRequestBody=ppRequestBody+"</userOpInfo>";

			if(ppRequestBody.indexOf("<com>")== -1&&ppRequestBody.indexOf("<iot>")== -1&&ppRequestBody.indexOf("<ent>")== -1&&ppRequestBody.indexOf("<info>")== -1)
				return null;

			Client ppClient=Client.create();
			WebResource ppResource=ppClient.resource(Settings.MOBILE_WEBSITE_ADDRESS+"personalize/"+userid);
			String response=ppResource.type(MediaType.TEXT_PLAIN).post(String.class,ppRequestBody);					
			return response;
		}
		else
		{
			System.out.println("policyXml is null");
		}


		return null;	
	}


	private String getDeviceType(String deviceid){
		System.out.println("PersonalizeService.getDeviceType()");
		Client c=Client.create();
		WebResource resource=c.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/CloudServer/deviceType/"+deviceid);
		String response=resource.type(MediaType.TEXT_PLAIN).get(String.class);
		return response;
	}


	@POST
	@Produces(MediaType.TEXT_PLAIN)	
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/site/{siteid}")
	public String domainpolicySite(@PathParam("siteid") String siteid,@Context HttpHeaders headers,@Context HttpServletRequest request){
		System.out.println("PersonalizeService.domainpolicySite()");	
		String acode=siteid.substring(0,siteid.indexOf("@"));

		String clientip=request.getRemoteAddr();
		String clientport=String.valueOf(request.getRemotePort());
		String publicip=clientip+":"+clientport;
		try{		
			String privateip=publicip;
			if(siteid!=null){			
				Client client1=Client.create();
				WebResource resource1=client1.resource(Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customers/"+acode+"/site/sip:"+siteid+"/userpolicy");				
				ClientResponse polyresponse=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);		
				String policy=polyresponse.getEntity(String.class);
				if(policy.startsWith("404")){
					client1=null;
					resource1=null;
					polyresponse=null;
					policy=null;
					return "404";
				}
				else 
				{
					client1=null;
					resource1=null;
					polyresponse=null;
					String rres= masterindexSite(siteid,policy,publicip,privateip);						
					if(rres!=null){
						System.out.println("rres ############"+rres);						
						return rres;
					}

					else{						
						System.out.println("master index not found for Site");
						return "500";
					}

				}

			}
			else{
				System.out.println("Domain Policy not found for Site");
				return "500";
			}

		}catch(Exception e){
			e.printStackTrace();
			return "500";
		}


	}




	private String masterindexSite(String siteid,String policyXml, String pubip, String privateip){

		System.out.println("PersonalizeService.masterindexSite()");
		System.out.println("Policy XML is "+policyXml);

		String cmcId = null;

		Client c = Client.create();
		WebResource resource = null;
		ClientResponse cresponse = null;	

		String acode=siteid.substring(0,siteid.indexOf("@"));
		resource = c.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/CloudServer/"+acode+"/cloudserverid");
		cmcId = resource.get(String.class);
		String usertype=getDeviceType(cmcId);


		String cloudserverid;
		CMCInfo cmcInfo=new CMCInfo();

		if(usertype.equalsIgnoreCase("cloudserver"))
			cloudserverid=acode;
		else 
			cloudserverid=siteid;


		if(policyXml!=null)
		{
			// Parse the site domain policy

			DomainPolicy.parse(policyXml);	
			ArrayList<RegistrationInfo> infolist=new ArrayList<RegistrationInfo>();

			RegistrationInfo info = new RegistrationInfo();
			info.setDomainName("com");
			info.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info.setRegistrationType("service");
			infolist.add(info);

			RegistrationInfo info1 = new RegistrationInfo();
			info1.setDomainName("iot");
			info1.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info1.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info1.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info1.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info1.setRegistrationType("service");
			infolist.add(info1);

			RegistrationInfo info2 = new RegistrationInfo();
			info2.setDomainName("info");
			info2.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info2.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info2.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info2.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info2.setRegistrationType("service");
			infolist.add(info2);

			RegistrationInfo info3 = new RegistrationInfo();
			info3.setDomainName("ent");
			info3.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info3.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info3.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info3.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info3.setRegistrationType("service");
			infolist.add(info3);

			DeviceRegister dr = new DeviceRegister();
			dr.setCustomerId(siteid);
			dr.setRegDate(Calendar.getInstance().getTime());
			dr.setAddressList(infolist);

			//preparing body
			String ppRequestBody="<?xml version=\"1.0\"?>"+
					"<userOpInfo>"+
					"<userType>SITE</userType>"+
					"<activationCode>"+acode+"</activationCode>"+
					"<custId>"+cloudserverid+"</custId>"+
					"<userId>sip:"+siteid+"</userId>";

			if(DomainPolicy.iotLink!=null)
			{
				int iotreg=201;
				cmcInfo.setInfo(true);
				System.out.println("Site Registration Status for IOT domain is :"+iotreg);
				if(iotreg==200||iotreg==201)
				{
					ppRequestBody=ppRequestBody+"<iot>"+Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customer/"+acode+"/users/sip:"+siteid+"/iot/master-index-enterprise"+"</iot>"; 

				}					   
				else{
					cmcInfo.setIot(false);
				}
			}      
			if(DomainPolicy.infoLink!=null)
			{
				int inforeg = 201;
				cmcInfo.setInfo(true);
				System.out.println("Site Registration Status for info domain is :"+inforeg);
				if(inforeg==200||inforeg==201)
				{
					ppRequestBody=ppRequestBody+"<info>"+Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customer/"+acode+"/users/sip:"+siteid+"/info/master-index-enterprise"+"</info>";

				}

			}   


			ppRequestBody=ppRequestBody+"</userOpInfo>";

			if(ppRequestBody.indexOf("<com>")== -1&&ppRequestBody.indexOf("<iot>")== -1&&ppRequestBody.indexOf("<ent>")== -1&&ppRequestBody.indexOf("<info>")== -1)
				return null;

			Client ppClient=Client.create();
			WebResource ppResource=ppClient.resource(Settings.MOBILE_WEBSITE_ADDRESS+"personalize/"+siteid);
			ClientResponse ppResponse=ppResource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,ppRequestBody);		
			System.out.println("Public MobileWebsite Request Body is "+ppRequestBody);	
			String mobileWbsite = ppResponse.getEntity(String.class);
			System.out.println("Public Mobile Website Response =====>"+mobileWbsite);
			if(!mobileWbsite.equals("404")){				
				String mwurl=mobileWbsite.substring(mobileWbsite.indexOf("<indexUrl>")+10,mobileWbsite.indexOf("</indexUrl>"));
				ppClient=null;
				ppResource=null;
				ppResponse=null;
				mobileWbsite=null;
				System.out.println("Publc mwurl================>"+mwurl);
				return mwurl;	
			}
			else{
				System.out.println("Response from Public Mobile Website: Registration Failed");
				ppClient=null;
				ppResource=null;
				ppResponse=null;	
				return null;
			}
		}
		else
		{
			System.out.println("policyXml is null");
		}


		return null;	
	}


	@POST
	@Produces(MediaType.TEXT_PLAIN)	
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/lot/{lotid}")
	public String domainpolicyLot(@PathParam("lotid") String lotid,@Context HttpHeaders headers,@Context HttpServletRequest request){

		System.out.println("PersonalizeService.domainpolicyLot()");		
		String acode=lotid.substring(0,lotid.indexOf("@"));
		String clientip=request.getRemoteAddr();
		String clientport=String.valueOf(request.getRemotePort());
		String publicip=clientip+":"+clientport;
		try{		
			String privateip=publicip;
			if(lotid!=null){			
				Client client1=Client.create();
				WebResource resource1=client1.resource(Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customers/"+acode+"/gateway/sip:"+lotid+"/userpolicy");				
				ClientResponse polyresponse=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);		
				String policy=polyresponse.getEntity(String.class);
				if(policy.startsWith("404")){
					client1=null;
					resource1=null;
					polyresponse=null;
					policy=null;
					return "404";
				}
				else 
				{
					client1=null;
					resource1=null;
					polyresponse=null;
					String rres= masterindexLot(lotid,policy,publicip,privateip);						
					if(rres!=null){
						System.out.println("rres ############"+rres);						
						return rres;
					}

					else{						
						System.out.println("master index not found for Lot");
						return "500";
					}

				}

			}
			else{
				System.out.println("Domain Policy not found for Lot");
				return "500";
			}
		}catch(Exception e){
			e.printStackTrace();
			return "500";
		}


	}




	private String masterindexLot(String lotid,String policyXml, String pubip, String privateip){

		System.out.println("In Login Server to Register Lot");
		System.out.println("Policy XML is "+policyXml);

		String cmcId = null;

		Client c = Client.create();
		WebResource resource = null;
		ClientResponse cresponse = null;			

		String acode=lotid.substring(0,lotid.indexOf("@"));
		resource = c.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/CloudServer/"+acode+"/cloudserverid");
		cmcId = resource.get(String.class);
		String usertype=getDeviceType(cmcId);
		String cloudserverid;
		CMCInfo cmcInfo=new CMCInfo();

		if(usertype.equalsIgnoreCase("cloudserver"))
			cloudserverid=acode;
		else 
			cloudserverid=lotid;


		if(policyXml!=null)
		{
			// Parse the lot domain policy

			DomainPolicy.parse(policyXml);	
			ArrayList<RegistrationInfo> infolist=new ArrayList<RegistrationInfo>();

			RegistrationInfo info = new RegistrationInfo();
			info.setDomainName("com");
			info.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info.setRegistrationType("service");
			infolist.add(info);

			RegistrationInfo info1 = new RegistrationInfo();
			info1.setDomainName("iot");
			info1.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info1.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info1.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info1.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info1.setRegistrationType("service");
			infolist.add(info1);

			RegistrationInfo info2 = new RegistrationInfo();
			info2.setDomainName("info");
			info2.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info2.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info2.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info2.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info2.setRegistrationType("service");
			infolist.add(info2);

			RegistrationInfo info3 = new RegistrationInfo();
			info3.setDomainName("ent");
			info3.setPublicIP(pubip.substring(0,pubip.indexOf(":")));
			info3.setPublicPort(pubip.substring(pubip.indexOf(":")+1));
			info3.setPrivateIP(privateip.substring(0,privateip.indexOf(":")));
			info3.setPrivatePort(privateip.substring(privateip.indexOf(":")+1));
			info3.setRegistrationType("service");
			infolist.add(info3);

			DeviceRegister dr = new DeviceRegister();
			dr.setCustomerId(lotid);
			dr.setRegDate(Calendar.getInstance().getTime());
			dr.setAddressList(infolist);

			//preparing body
			String ppRequestBody="<?xml version=\"1.0\"?>"+
					"<userOpInfo>"+
					"<userType>LOT</userType>"+
					"<activationCode>"+acode+"</activationCode>"+
					"<custId>"+cloudserverid+"</custId>"+
					"<userId>sip:"+lotid+"</userId>";

			if(DomainPolicy.iotLink!=null)
			{
				int iotreg=201;
				cmcInfo.setInfo(true);
				System.out.println("Lot Registration Status for IOT domain is :"+iotreg);
				if(iotreg==200||iotreg==201)
				{
					ppRequestBody=ppRequestBody+"<iot>"+Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customer/"+acode+"/users/sip:"+lotid+"/iot/master-index-enterprise"+"</iot>"; 

				}					   
				else{
					cmcInfo.setIot(false);
				}
			}      
			if(DomainPolicy.infoLink!=null)
			{
				int inforeg = 201;
				cmcInfo.setInfo(true);
				System.out.println("Lot Registration Status for info domain is :"+inforeg);
				if(inforeg==200||inforeg==201)
				{
					ppRequestBody=ppRequestBody+"<info>"+Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/customer/"+acode+"/users/sip:"+lotid+"/info/master-index-enterprise"+"</info>";

				}

			}

			ppRequestBody=ppRequestBody+"</userOpInfo>";
			if(ppRequestBody.indexOf("<com>")== -1&&ppRequestBody.indexOf("<iot>")== -1&&ppRequestBody.indexOf("<ent>")== -1&&ppRequestBody.indexOf("<info>")== -1)
				return null;

			Client ppClient=Client.create();
			WebResource ppResource=ppClient.resource(Settings.MOBILE_WEBSITE_ADDRESS+"personalize/"+lotid);
			ClientResponse ppResponse=ppResource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class,ppRequestBody);		
			System.out.println("Public MobileWebsite Request Body is "+ppRequestBody);	
			String mobileWbsite = ppResponse.getEntity(String.class);
			System.out.println("Public Mobile Website Response =====>"+mobileWbsite);
			if(!mobileWbsite.equals("404")){				
				String mwurl=mobileWbsite.substring(mobileWbsite.indexOf("<indexUrl>")+10,mobileWbsite.indexOf("</indexUrl>"));
				ppClient=null;
				ppResource=null;
				ppResponse=null;
				mobileWbsite=null;
				System.out.println("mwurl================>"+mwurl);
				return mwurl;	
			}
			else{
				System.out.println("Response from Public Mobile Website: Registration Failed");
				ppClient=null;
				ppResource=null;
				ppResponse=null;	
				return null;
			}
		}
		else
		{
			System.out.println("policyXml is null");
		}
		return null;	
	}



	@POST
	@Path("/{userid}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public String  personaliseData(@PathParam("userid")String userid, String xmlBody){	

		System.out.println("personalizeService.personaliseData()################ ");
		System.out.println("Solution , Site and Lot Id for Login Request ############ "+userid);
		System.out.println("login Request xml body ###################### ::"+xmlBody);
		String indexUrlPath="";		
		try {
			customer customerinfo = new customer();	
			//Parse and get customerId				
			User id  =  customerinfo.parseLoginRquest(xmlBody);
			String userId = id.getUserId();		

			User uT  = customerinfo.parseUserType(xmlBody);
			String UserType = uT.getUserType();
			System.out.println("UserType ====== >"+UserType);

			User aId=  customerinfo.parseActivationCode(xmlBody);
			String activationid  = aId.getActivationcode();
			System.out.println("userId ############### ::"+userId);
			System.out.println("activationid ############### ::"+activationid);
			String activation = activationid.toLowerCase();		

			//check Enabled true or false 
			if (Settings.CLOUD_ENABLED.equalsIgnoreCase("false")){								
				System.out.println("In side the CLOUD_ENABLED False =====");			

				//Local public MobileWebsite Creation
				String Website = createWebsiteLocal(userId, activation, xmlBody, UserType);
				if(Website=="201"){
					System.out.println("Public Website Created ");
					return "201";
				}else if(Website=="404"){
					System.out.println("Registration Failed  ");
					return "404";
				}
				else{
					System.out.println("Public Website Creation Failed ");
				}
			}
			else if (Settings.CLOUD_ENABLED.equalsIgnoreCase("true")){
				System.out.println("In side the CLOUD_ENABLED true =====");
				//S3 public MobileWebsite Creation
				String Website = createWebsiteS3(userId, activation, xmlBody, UserType);				
				if(Website=="201"){
					System.out.println("Public Website Created (s3)");
					return "201";
				}else if(Website=="404"){
					System.out.println("Registration Failed (s3) ");
					return "404";
				}
				else{
					System.out.println("Public Website Creation Failed (s3) ");
				}

			}


		} catch (Exception e) {
			e.printStackTrace();

		}		
		return "500";

	}



	/******************************************* Local Operation Begin**********************************/

	private String createWebsiteLocal(String userid,String activation ,String body,String UserType){		
		System.out.println("PersonalizeService.createWebsiteLocal()");
		String resp = "";
		String respIot="";
		String respInfo="";
		String respHotelUri="";
		String respDeviceBookUri="";		
		String personalinfos="";		
		String cssos="";		
		String link="";				

		try {	
			IotDomain  iotDomain = new IotDomain();						

			//For IOT Domain	
			respIot = parseIotMasterIndexLinkLocal(body);

			String Pub = parseIotCssoUrlLocal(respIot);
			if(Pub!=null){			

				String loginUser = activation.toLowerCase();			
				String desFolder = loginUser+"personalise/";				

				//User's Personalized Folder creation
				boolean fStatus = personalizedFolderLocal(desFolder, userid);
				System.out.println("User Personalized Folder created!"+fStatus);

				//Parsing HotelUri
				String[] HotelempUris=iotDomain.parseHotelempUri(respIot);
				String[] hxmls=new String[HotelempUris.length];			
				for(int i=0;i<HotelempUris.length;i++){
					hxmls[i]=(HotelempUris[i]);

					//Client for hotelemp-doc uri Link
					Client c1=Client.create();
					WebResource resource1=c1.resource(hxmls[i]);
					ClientResponse response1=resource1.get(ClientResponse.class);
					respHotelUri=response1.getEntity(String.class);
					parseIotHotelUriLocal(respHotelUri);
				}				

				//Parsing DeviceBookUri			
				String[] DeviceBookUris=iotDomain.parseDeviceBookUri(respIot);
				String[] dbxmls=new String[DeviceBookUris.length];			
				for(int i=0;i<DeviceBookUris.length;i++){
					dbxmls[i]=(DeviceBookUris[i]);
					//Client for DeviceBookUri Link
					Client c1=Client.create();
					WebResource resource1=c1.resource(dbxmls[i]);
					ClientResponse response1=resource1.get(ClientResponse.class);
					respDeviceBookUri=response1.getEntity(String.class);
					System.out.println("respDeviceBookUri ==== >"+respDeviceBookUri);

				}

				//For INFO Domain
				System.out.println("Pub ########## "+Pub);
				respInfo = parseInfoMasterIndexLinkLocal(body);			
				String self =parseInfoSelfUrlLocal(respInfo);
				personalinfos = InfopersonalinfosLocal(self);	
				parseInfoDisplayNameLocal(personalinfos);	
				parseInfoUriAndImageURlLocal(respHotelUri);	
				String genderInfo = parseInfoGenderLocal(respHotelUri);
				String contryInfo =parseInfoContryLocal(respHotelUri);	
				String csurl = parseInfoCssoUrlLocal(respInfo);
				cssos = InfoCssosurlLocal(csurl);			
				String publicUrlInfo = parseInfoPublicUrlLocal(cssos);
				parseInfoPrivteUrlLocal(cssos);

				//Data's Replacing For Iot/Info html File
				UpdateIotAndInfoLocal(respInfo, respIot, Pub, desFolder, userid, publicUrlInfo, contryInfo, genderInfo, UserType);	
				System.out.println("Public Website Created ");
				return "201";
			}
			else{
				System.out.println("####### Registration Failed ######## ");
				return "404";	
			}			


		} catch (Exception e) {
			e.printStackTrace();

		}

		return "500";		

	}



	private String  parseIotMasterIndexLinkLocal(String body){
		System.out.println("parseIotMasterIndexLink()");
		String respIot=""; 
		IotDomain  iotDomain = new IotDomain();

		//Parsing MasterIndex IOT Link
		Iot masterIndexIot = iotDomain.parseMasterIndexIot(body);
		String iot = masterIndexIot.getIot();
		System.out.println("IOT MasterIndex ################# ::"+iot);	

		//Client go for IotMasterIndex link 
		Client c1=Client.create();
		WebResource resource1=c1.resource(iot);
		ClientResponse  response1=resource1.get(ClientResponse.class);
		respIot=response1.getEntity(String.class);

		return respIot;

	}


	private String parseIotHotelUriLocal(String respHotelUri){	

		System.out.println("parseIotHotelUri()");
		String contry="";
		String gender="";		
		IotDomain  iotDomain = new IotDomain();
		//parse PersonalInfo Link
		//Set DisplayName 
		Iot parseDisplayName = iotDomain.parseDisplayName(respHotelUri);
		String DisplayName = parseDisplayName.getDisplayname();
		System.out.println("User DisplayName For IOT Domain ############# "+DisplayName);

		//Set URI
		Iot parseUri = iotDomain.parseUri(respHotelUri);
		String uri = parseUri.getUri();
		System.out.println("User URI  For IOT Domain ############# "+uri);				

		//Set Image_Url
		Iot parseImageUrl = iotDomain.parseImageUrl(respHotelUri);
		String imageUrl = parseImageUrl.getImageurl();
		System.out.println("User Image_Url For IOT Domain ############# "+imageUrl);			

		//Set Gender
		Iot parseGender= iotDomain.parseGender(respHotelUri);
		gender = parseGender.getGender();
		System.out.println("User gender For IOT Domain  ############# "+gender);		

		//Set Contry
		Iot parseCountry = iotDomain.parseCountry(respHotelUri);
		contry = parseCountry.getCountry();
		System.out.println("User contry For IOT Domain ############# "+contry);
		return null;

	}




	private String parseIotCssoUrlLocal(String respIot){

		System.out.println("parseIotCssoUrl()");
		String respCssoUrl="";
		String Pub = null;
		IotDomain  iotDomain = new IotDomain();

		//Parsing CssoUrl
		Iot parseCssoUrl = iotDomain.parseCssoUrl(respIot);
		String CssoUrl = parseCssoUrl.getCssourl();
		System.out.println("CssoUrl uri =====================>"+CssoUrl);

		//Client for CssoUrl Link
		Client c1=Client.create();
		WebResource resource1=c1.resource(CssoUrl);
		ClientResponse response1=resource1.get(ClientResponse.class);
		respCssoUrl=response1.getEntity(String.class);
		int status = response1.getStatus();		
		if(status==200){
			System.out.println("resp CssoUrl ###################### ::"+respCssoUrl);

			//parse CssoURL Link
			//Set PublicIp and Port 
			Iot parsePublic = iotDomain.parsePublic(respCssoUrl);
			Pub = parsePublic.getPub();
			System.out.println("User PublicIp and Port For IOT Domain ############# "+Pub);

			//Set PrivateIp and Port 
			Iot parsePriv = iotDomain.parsePrivate(respCssoUrl);
			String priv = parsePriv.getPriv();
			System.out.println("User PrivateIp and Port For IOT Domain ############# "+priv);
		}else{			
			return Pub;
		}
		return Pub;
	}


	private String  parseInfoMasterIndexLinkLocal(String body){
		System.out.println("LocalFS.parseInfoMasterIndexLink()");
		String respInfo=""; 
		InfoDomain  infoDomain = new InfoDomain();

		//Parsing MasterIndex Info Link
		Info masterIndexInfo = infoDomain.parseMasterIndexInfo(body);
		String info = masterIndexInfo.getInfo();
		System.out.println("INFO MasterIndex ################# ::"+info);	

		//Client go for InfoMasterIndex link
		Client c2=Client.create();
		WebResource resource2=c2.resource(info);
		ClientResponse  response2=resource2.get(ClientResponse.class);
		respInfo=response2.getEntity(String.class);
		System.out.println("respInfo =====================>"+respInfo);
		return respInfo;

	}


	private String parseInfoSelfUrlLocal(String respInfo){
		System.out.println("LocalFS.parseInfoSelfUrl()");
		InfoDomain  infoDomain = new InfoDomain();
		//Parsing selfUrl
		Info selfUrl=infoDomain.parseSelfUrl(respInfo);
		String self = selfUrl.getSelfurl();
		System.out.println("selfUrl =================>"+self);

		return self;
	}


	private String InfopersonalinfosLocal(String self){
		System.out.println("LocalFS.Infopersonalinfos()");

		// Client for personal info uri Link			
		Client c1=Client.create();
		WebResource resource1=c1.resource(self);
		ClientResponse response1=resource1.get(ClientResponse.class);
		String personalinfos=response1.getEntity(String.class);
		System.out.println("resp personalinfo of User In INFO Domain  ############# ::"+personalinfos);

		return personalinfos;
	}


	private String parseInfoDisplayNameLocal(String personalinfos){
		System.out.println("LocalFS.parseInfoDisplayName()");
		InfoDomain  infoDomain = new InfoDomain();

		//parse PersonalInfo Link
		//Set DisplayName 
		Info parseDisplayName = infoDomain.parseDisplayName(personalinfos);
		String DisplayNameInfo = parseDisplayName.getDisplayname();
		System.out.println("User DisplayName For INFO Domain ############# "+DisplayNameInfo);
		return DisplayNameInfo;

	}

	private void parseInfoUriAndImageURlLocal(String respHotelUri){

		System.out.println("parseInfoUriAndImageURl()");
		InfoDomain  infoDomain = new InfoDomain();
		Info parseUri = infoDomain.parseUri(respHotelUri);
		String uriInfo = parseUri.getUri();
		System.out.println("User URI For INFO Domain ############# "+uriInfo);

		//Set Image_Url
		Info parseImageUrl = infoDomain.parseImageUrl(respHotelUri);
		String imageUrlInfo = parseImageUrl.getImageurl();
		System.out.println("User Image_Url For INFO Domain ############# "+imageUrlInfo);	

	}


	private String parseInfoGenderLocal(String respHotelUri){

		System.out.println("parseInfoGender()");
		InfoDomain  infoDomain = new InfoDomain();
		//Set Gender
		Info parseGender= infoDomain.parseGender(respHotelUri);
		String genderInfo = parseGender.getGender();
		System.out.println("User gender For INFO Domain  ############# "+genderInfo);	

		return genderInfo;

	}



	private String parseInfoContryLocal(String respHotelUri){
		System.out.println("LocalFS.parseInfoContry()");
		InfoDomain  infoDomain = new InfoDomain();
		//Set Country
		Info parseCountry = infoDomain.parseCountry(respHotelUri);
		String contryInfo = parseCountry.getCountry();
		System.out.println("User Country For INFO Domain #############"+contryInfo);
		return contryInfo;

	}


	private String parseInfoPrivteUrlLocal(String cssos){

		System.out.println("parseInfoPrivteUrl()");
		InfoDomain  infoDomain = new InfoDomain();
		//Set Private IP and Port
		Info parsePri= infoDomain.parsePrivteUrl(cssos);
		String privUr = parsePri.getPri();
		System.out.println("User Private Url For INFO Domain ############# "+privUr);
		return privUr;

	}


	private String InfoCssosurlLocal(String csurl){

		System.out.println("InfoCssosurl()");
		//Client for CSSO info Link
		Client c1=Client.create();
		WebResource resource1=c1.resource(csurl);
		ClientResponse response1=resource1.get(ClientResponse.class);
		String cssos=response1.getEntity(String.class);
		System.out.println("resp from CSSO INFO Domain  ############# ::"+cssos);

		return cssos;
	}


	private String parseInfoPublicUrlLocal(String cssos){

		System.out.println("parseInfoPublicUrl()");
		InfoDomain  infoDomain = new InfoDomain();
		//Set Public IP and Port 
		Info parsePub = infoDomain.parsePublicUrl(cssos);
		String publicUrlInfo = parsePub.getPub();
		System.out.println("User Public Url For INFO Domain ############# "+publicUrlInfo);

		return publicUrlInfo;

	}

	private String parseInfoCssoUrlLocal(String respInfo){

		System.out.println("parseInfoCssoUrl()");
		InfoDomain  infoDomain = new InfoDomain();
		//Parsing CssoUrl for INFO
		Info csso=infoDomain.parseCssoUrl(respInfo);
		String csurl = csso.getCssourl();
		System.out.println("CSSO URL for Info Domain =================>"+csurl);
		return csurl;

	}



	private void UpdateIotAndInfoLocal(String respInfo ,String respIot , String Pub ,String desFolder,String userid ,String publicUrlInfo,String contryInfo, String genderInfo,String UserType){

		System.out.println("UpdateIotAndInfo()");
		Iot parseCat=null;
		Iot parseDeviceType=null;
		Iot parseUdn=null;	
		Iot parseL1=null;
		Iot parseL2=null;
		Iot parseModelD = null;
		Iot parseId =null;
		Iot parsePi = null;
		Iot parseServiceType =null;

		IotDomain  iotDomain = new IotDomain();
		InfoDomain  infoDomain = new InfoDomain();
		/*LocalFsReplaceFiles rfs = new LocalFsReplaceFiles();
		LocalFsFileUtil fu 		= new LocalFsFileUtil();*/

		List<AppInfo> appList = infoDomain.parseAppLists(respInfo);
		List<AppInfo> nappList = new ArrayList<AppInfo>();


		//Data's Replacing For Iot html File
		List<DeviceInfo> deviceList = iotDomain.parseDeviceProfileUriList_new(respIot);
		List<DeviceInfo> ndeviceList = new ArrayList<DeviceInfo>();

		if(null != deviceList && deviceList.size() > 0)
		{			

			String deviceProfile = null;
			String deviceSA = null;
			for(DeviceInfo device : deviceList)
			{
				//-------------------------Device Profile operation

				String deviceUuid = UUID.randomUUID().toString();
				device.setDeviceUuid(deviceUuid);

				Client c1=Client.create();
				WebResource resource1=c1.resource(device.getpUri());		
				ClientResponse response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
				deviceProfile = response1.getEntity(String.class);					

				//Set Category
				parseCat = iotDomain.parseCategory(deviceProfile);
				String cat = parseCat.getCategory();
				System.out.println("User Category For IOT Domain ############# "+cat);
				device.setDeviceCat(cat);					

				//Set DeviceType
				parseDeviceType = iotDomain.parseDeviceType(deviceProfile);
				String deviceType = parseDeviceType.getDevicetype();
				System.out.println("User DeviceType For IOT Domain  ############# "+deviceType);
				device.setDeviceType(deviceType);				

				//layoutGrp(L1)
				parseL1 = iotDomain.parseL1(deviceProfile);
				String l1 = parseL1.getL1();
				System.out.println("User L1 For IOT Domain  ############# "+l1);
				device.setL1(l1);

				//layoutGrp(L2)					
				parseL2= iotDomain.parseL2(deviceProfile);
				String l2 = parseL2.getL2();
				System.out.println("User L2 For IOT Domain  ############# "+l2);
				device.setL2(l2);

				//Set UDN
				parseUdn = iotDomain.parseUdn(deviceProfile);
				String udns = parseUdn.getUdn();
				System.out.println("User UDN For IOT Domain  ############# "+udns);	
				device.setUDN(udns);					

				//Set Model Desc
				parseModelD = iotDomain.parseModelDesc(deviceProfile);
				String md = parseModelD.getModeldesc();
				System.out.println("User ModelDesc  For IOT Domain ############# "+md);
				device.setDeviceModelDesc(md);

				//-------------------------Service action operation
				//Client for DeviceServiceActionUri Link
				System.out.println("----device.getsUri()-----------------"+device.getsUri());
				resource1=c1.resource(device.getsUri());		
				response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
				String SAuris=response1.getEntity(String.class);					

				//Parse DeviceServiceAction link
				Iot deviceServiceUri = iotDomain.parseServiceActions(SAuris); // deviceSA
				String uri = deviceServiceUri.getUriloginDetails();

				// Client DeviceServiceAction Link
				resource1=c1.resource(uri);		
				response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
				deviceSA=response1.getEntity(String.class);

				//parse DeviceServiceAction Link				
				parseId = iotDomain.parseId(deviceSA);

				//Set ProductId
				parsePi = iotDomain.parseProdectId(deviceSA);
				String product = parsePi.getProductid();
				System.out.println("User ProductId For IOT Domain ############# "+product);
				device.setProductId(product);

				//Set ServiceType
				parseServiceType = iotDomain.parseServiceType(deviceSA);
				String serviceType = parseServiceType.getServicetype();
				System.out.println("User ServiceType For IOT Domain ############# "+serviceType);
				device.setServiceType(serviceType);

				updateIotFileLocal(desFolder,userid, Pub,device);	
				ndeviceList.add(device);
			}

			//Data's Replacing For Info html File 			

			if(null != appList && appList.size() > 0)
			{
				String appIds = "";
				String appSType = "";
				for(AppInfo app : appList)
				{
					appIds 		= app.getAppId();
					System.out.println("appIds ---------->"+appIds);
					app.setAppId(appIds);												

					appSType	= app.getServiceType();
					System.out.println("App Service Type ----------->"+appSType);
					app.setServiceType(appSType);

					updateInfoFileLocal(desFolder, userid, publicUrlInfo,app);
					nappList.add(app);
				}								

			}
		}

		//update Self.html file
		updateSelfFileLocal(desFolder, userid, contryInfo, genderInfo, Settings.LOGIN_SERVER,UserType);

		//update index.html file 				
		readIndexFileLocal(ndeviceList,nappList,desFolder, "index",userid);

	}

	private boolean updateInfoFileLocal(String desFolder,String userid, String publicUrlInfo,AppInfo app){		

		System.out.println("updateInfoFile() ####### getAppId : "+app.getAppId());
		System.out.println("UserId ===============>"+userid);
		System.out.println("publicUrlInfo =========>"+publicUrlInfo);		
		try {

			//Read,update&Replace Info html file in Personalized Folder
			readInfoFileLocal(desFolder, app.getAppId(), publicUrlInfo, userid, app.getServiceType());				

		} catch (Exception e) {
			e.printStackTrace();		
		}
		return true;

	}
	private boolean updateSelfFileLocal(String desFolder,String userid, String contryName,String gender,String  LoginServerUrl,String UserType){	
		System.out.println("updateSelfFile()");
		System.out.println("gender  for User =====>"+gender);		
		System.out.println("Country  for User =====>"+contryName);	
		System.out.println("LoginServerUrl  for User =====>"+LoginServerUrl);		
		try {					

			//Read,update&Replace self.html file in Personalized Folder
			readSelfFileLocal(desFolder, "self", userid, contryName, gender, LoginServerUrl,UserType);			

		} catch (Exception e) {
			e.printStackTrace();		
		}
		return true;
	}	

	private boolean updateIotFileLocal(String desFolder,String userid, String publicUrlIot,DeviceInfo device){		
		System.out.println("updateIotFileLocal() ####### getDeviceId  : "+device.getDeviceId());		
		try {				
			//Read,update&Replace Iot html file in Personalized Folder
			readIotFileLocal(device.getDeviceUuid(),
					desFolder,
					device.getDeviceId(),
					device.getDeviceModelDesc(),
					publicUrlIot,
					device.getProductId(),
					userid,
					device.getUDN(),
					device.getDeviceType(),
					device.getServiceType());

		} catch (Exception e) {
			e.printStackTrace();		
		}
		return true;

	}

	private boolean personalizedFolderLocal(String desFolder,String userid){

		File fil = new File(Settings.GenPath+userid+"\\"+desFolder);

		if (!fil.exists()) {
			if (fil.mkdirs()) {
				System.out.println(userid+"###"+desFolder+"==> User Personalized Folder created!");
			} else {
				System.out.println("Failed to create a Personalized Folder!");
			}}

		return true;
	}

	private void readIotFileLocal(String deviceUuid , String desFolder,String deviceId,String ctrltype , String pulicUrl ,String productId ,String userId ,String udn ,String deviceType,String serviceType){
		System.out.println("Inside the readIotFile ========>");			
		System.out.println("deviceType ####################### "+deviceType);
		//http://192.168.0.3:8080 Old pulicUrl
		//https://192.168.0.3:8443 New PulicUrl
		String http = pulicUrl.substring(pulicUrl.indexOf("h"),pulicUrl.lastIndexOf("p"));
		String nhttps = http+"ps://";		
		String publicIp = pulicUrl.substring(pulicUrl.indexOf("//")+2,pulicUrl.lastIndexOf(":"));		
		String updatedPubIp= nhttps+publicIp+":"+Settings.HTTPS_PORT;

		System.out.println("############## updated PublicIp ########## "+updatedPubIp);
		String devT=deviceType.substring(deviceType.indexOf("device:")+7, deviceType.lastIndexOf(":"));
		String devType=devT.toLowerCase();
		System.out.println("Find the file on the based of devType ####### "+devType);

		//System.out.println("Ignore Case for deviceId ========>"+devid);
		System.out.println("ctrltype #################### "+ctrltype);
		System.out.println("pulicUrl #################### "+pulicUrl);
		System.out.println("productId #################### "+productId);
		System.out.println("userId #################### "+userId);
		System.out.println("UDN ########################## "+udn);
		System.out.println("ServiceType #################### "+serviceType);

		String servicename=serviceType;
		servicename = servicename.substring(31);

		String sev = servicename.substring(servicename.indexOf("ras"), servicename.lastIndexOf(":")-0);
		//System.out.println("New Sev ################### "+sev);
		System.out.println("servicename ################### "+servicename);

		String filePath = Settings.GenPath+userId+"\\UNAAS-DEFAULT-V1\\res\\userTemplates\\default\\"+devType+".html";
		BufferedReader br = null;
		String temp = "";
		try {

			String sCurrentLine;
			//String deviceUuid= UUID.randomUUID().toString();

			br = new BufferedReader(new FileReader(filePath));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);				
				temp = temp+sCurrentLine;
			}
			temp = temp.replace("##COMMON_URL##", "../UNAAS-DEFAULT-V1/res/common/");			
			temp = temp.replace("##CTRL_URL##",updatedPubIp+"/"+productId+"/"+userId+"/sip:"+userId+"@unaas.com/"+udn+"/"+sev+"/");
			temp = temp.replace("##IMAGE_URL##", "../UNAAS-DEFAULT-V1/res/userTemplates/default/images/");
			temp = temp.replace("##SERVICE_TYPE##",serviceType);
			temp = temp.replace("##SELF_URL##", "Self.html");
			System.out.println(temp+"\n");


			//Personalized Iot File			
			File f = null;
			boolean bool = false;

			// create new file			
			f = new File(Settings.GenPath+userId+"\\"+desFolder+"\\"+deviceUuid+devType+".html");

			// tries to create new file in the system
			bool = f.createNewFile();

			// prints
			System.out.println("File created: "+bool); 

			PrintWriter writer = new PrintWriter(Settings.GenPath+userId+"\\"+desFolder+"\\"+deviceUuid+devType+".html", "UTF-8");
			writer.println(temp);		
			writer.close();	


		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}	

	}

	private void readInfoFileLocal(String desFolder,String appId,String pulicUrl,String userId ,String serviceType){
		System.out.println("Inside the readInfoFile ========>");		
		String appid = appId.toLowerCase();
		System.out.println("Ignore Case for AppId ========>"+appid);		
		System.out.println("pulicUrl #################### "+pulicUrl);		
		System.out.println("userId #################### "+userId);
		System.out.println("ServiceType #################### "+serviceType);

		String servicename=serviceType;
		servicename = servicename.substring(31);
		System.out.println("servicename ################### "+servicename);
		String sev = servicename.substring(servicename.indexOf("info"), servicename.lastIndexOf(":")-0);

		String filePath = Settings.GenPath+userId+"\\UNAAS-DEFAULT-V1\\res\\userTemplates\\default\\"+appid+".html";
		BufferedReader br = null;
		String temp = "";
		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader(filePath));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);				
				temp = temp+sCurrentLine;				
			}
			temp = temp.replace("##COMMON_URL##", "../UNAAS-DEFAULT-V1/res/common/");	
			//temp = temp.replace("##CTRL_URL##", Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/sip:"+userId+"@unaas.com/"+userId+"/"+sev+"/");
			temp = temp.replace("##CTRL_URL##", "https://"+Settings.BACKEND_DATABASES_IP+":"+Settings.HTTPS_PORT+"/BackEndGateway/CCCP/CCCPGateway/sip:"+userId+"@unaas.com/"+userId+"/"+sev+"/");
			temp = temp.replace("##SERVICE_TYPE##",serviceType);
			temp = temp.replace("##SELF_URL##", "Self.html");
			System.out.println(temp+"\n");	


			//Personalized App's File		
			File f = null;
			boolean bool = false;

			// create new file			
			f = new File(Settings.GenPath+userId+"\\"+desFolder+"\\"+appid+".html");

			// tries to create new file in the system
			bool = f.createNewFile();

			// prints
			System.out.println("File created: "+bool);  			
			PrintWriter writer = new PrintWriter(Settings.GenPath+userId+"\\"+desFolder+"\\"+appid+".html", "UTF-8");
			writer.println(temp);	       
			writer.close();


		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}	

	}

	private void readIndexFileLocal(List<DeviceInfo> deviceList,List<AppInfo> appList , String desFolder,String indexId,String userId){		

		//URL indexUrl= null;
		System.out.println("Inside the readIndexFileLocal ========>");				
		System.out.println("userId For ROOM_NUMBER  #################### "+userId);
		String sPath = Settings.GenPath+userId+"\\UNAAS-DEFAULT-V1\\res\\userTemplates\\default\\"+indexId+".html";
		String dPath = Settings.GenPath+userId+"\\"+desFolder+"\\"+indexId+".html";
		String building = "";
		String info ="";
		String iotAndinfoXml="";
		List<DeviceInfo> ndevicelist = null;
		//boolean flag = true;

		if(null != deviceList && deviceList.size()>0)
		{
			iotAndinfoXml="div  id=\"navmenu\" data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
					+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"
					+ "\n<h3>Remote Monitoring</h3>\n";
			//+ "\n<!-- ##C-LEVEL1## -->\n"	
			ndevicelist = deviceList;
			//}

			for(int i=0; i < deviceList.size(); i++ )
			{
				DeviceInfo device = deviceList.get(i);
				System.out.println(i+" ==================== In side 1st For Block get(i).getL1 ======> "+device.getL1()+" and device.getL2() => "+device.getL2()+"===============================");

				for(int j=0; j < ndevicelist.size(); j++ ){
					DeviceInfo ndevice = ndevicelist.get(j);

					System.out.println(j+" - In side 2nd For Block get(j).getL1 ======>> "+ndevice.getL1()+" and ndevice.getL2() =>> "+ndevice.getL2());
					if(device.getL1().equalsIgnoreCase(ndevice.getL1()))
					{
						System.out.println(j+" - In side 1st If Block get(j).getL1 match ======>>> "+ndevice.getL1());


						if(device.getL2().equalsIgnoreCase(ndevice.getL2()))
						{
							System.out.println(j+" - In side 2nd If Block get(j).getL2 match  ============>>>>  "+ndevice.getL2());
							String devid = ndevice.getDeviceId().toLowerCase();

							if(device.getDeviceId().equalsIgnoreCase(ndevice.getDeviceId())){
								String dev = ndevice.getDeviceType();
								String devT=dev.substring(dev.indexOf("device:")+7, dev.lastIndexOf(":"));
								String deviceType = devT.toLowerCase();

								System.out.println(j+" - In side 3nd If Block get(i).getDeviceId : "+device.getDeviceId()+" not match with get(j).getDeviceId :  ============>>>>  "+ndevice.getDeviceId());
								System.out.println(" Going to add device ========>"+devid);
								/*if(!flag)
								{*/
								building = building	
										+"<div  data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
										+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"
										+ "\n<h3>"+ndevice.getL1()+"</h3>\n";
								building = building		
										+"<div  id=\"navmenu\" data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
										+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"
										+ "\n<h3>"+ndevice.getL2()+"</h3>\n"
										+"<div  id=\"navmenu\" data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
										+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"					
										+ "\n<h3>"+ndevice.getDeviceId()+"</h3>\n";								
								/*flag = true;
								}*/
								building = building			
										+"<ul data-role=\"listview\" data-inset=\"true\" data-theme=\"d\" data-dividertheme=\"b\" class=\"sc_nav\" id=\"inner\">"
										+ "<li><a href=javascript:showContent(\""+ndevice.getDeviceUuid()+deviceType+".html\")>"+ndevice.getDeviceId()+"</a></li></ul>";
								building = building			
										+"</div>"
										+"</div>"
										+"</div>"
										+"</div>"
										+"</div>"
										+"</div>";
							}							
						}
						else
							System.out.println("################# L2 not matched.... ###################");
					}
					else
						System.out.println("################## L1 not matched.... #####################");
				}
			}
			building = building			
					//+"</div>"
					+"</div>";
		}

		iotAndinfoXml = iotAndinfoXml + building		
				//+"</div>"										
				+"<div  data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
				+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"
				+ "\n<h3>Dashboard Apps</h3>\n"				
				+"<ul data-role=\"listview\" data-inset=\"true\" data-theme=\"d\" data-dividertheme=\"b\" class=\"sc_nav\" id=\"inner\">";
		for(AppInfo app : appList)
		{
			String apps = app.getAppId();
			String appsId = apps.toLowerCase();
			System.out.println("AppId !!!!!!!!!!!!!!!!!!!!!!!!!!! == > "+appsId);
			//String app = app
			String AppName = app.getAppId();
			info	=info
					+"<li>";

			if(AppName.equalsIgnoreCase("mod")){
				info=info
						+"<a href=javascript:showContent(\""+appsId+".html\")>Music</a>";
			}
			else if(AppName.equalsIgnoreCase("vod")){
				info=info
						+"<a href=javascript:showContent(\""+appsId+".html\")>Video</a>";
			}
			else if(AppName.equalsIgnoreCase("webapps")){
				info=info
						+"<a href=javascript:showContent(\""+appsId+".html\")>Web</a>";
			}
			else{
				System.out.println("No App Found ======>");				
			}				
			info=info
					+"</li>";				
		}
		iotAndinfoXml =	iotAndinfoXml+info
				+"</ul>"
				+"</div>"
				+"</div>"						
				+"</div";

		BufferedReader br = null;
		String temp = "";
		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader(sPath));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);				
				temp = temp+sCurrentLine;				
			}
			temp = temp.replace("##COMMON_URL##", "../UNAAS-DEFAULT-V1/res/common/");			
			temp = temp.replace("##ROOM_NUMBER##", userId);	

			for(DeviceInfo device : deviceList)
			{
				String dev = deviceList.get(0).getDeviceType();
				String devT=dev.substring(dev.indexOf("device:")+7, dev.lastIndexOf(":"));
				String deviceType = devT.toLowerCase();
				temp = temp.replace("##FIRST_PAGE##",device.getDeviceUuid()+deviceType+".html");
			}

			temp = temp.replace("!-- ##CSET--LEVEL1## --",iotAndinfoXml);	


			System.out.println(temp+"\n");		

			//Personalized index.html File			
			File f = null;
			boolean bool = false;

			// create new file
			f = new File(Settings.GenPath+userId+"\\"+desFolder+"\\"+indexId+".html");

			// tries to create new file in the system
			bool = f.createNewFile();

			// prints
			System.out.println("File created: "+bool);  			
			PrintWriter writer = new PrintWriter(dPath, "UTF-8");
			writer.println(temp);	       
			writer.close();


		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		//return indexUrl;	

	}

	private void readSelfFileLocal(String desFolder,String selfId,String userid,String contryName,String gender,String LoginServerUrl,String UserType){
		System.out.println("Inside the readSelfFile ========>");
		//System.out.println("desFoder ################ "+desFoder);
		System.out.println("DISPLAY NAME #################### "+userid);
		System.out.println("ContryName #################### "+contryName);
		System.out.println("Gender #################### "+gender);
		System.out.println("LoginServer Ip and Port #################### "+LoginServerUrl);
		System.out.println("UserType ################## "+UserType);

		String filePath = Settings.GenPath+userid+"\\UNAAS-DEFAULT-V1\\res\\userTemplates\\default\\"+selfId+".html";
		BufferedReader br = null;
		String temp = "";
		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader(filePath));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);				
				temp = temp+sCurrentLine;				
			}
			temp = temp.replace("##COMMON_URL##", "../UNAAS-DEFAULT-V1/res/common/");
			temp = temp.replace("##MY_DISPLAY_NAME##",userid);
			temp = temp.replace("##MY_COUNTRY_NAME##",contryName);
			temp = temp.replace("##MY_GENDER##", gender);		


			if(UserType.equalsIgnoreCase("SOLUTION")){
				temp = temp.replace("##LOGOUT_URL##","https://"+Settings.Login_Server_IP+":"+Settings.HTTPS_PORT+"/PublicMobileWebsite/login/logout/"+userid+"@unaas.com");
			}
			else if(UserType.equalsIgnoreCase("SITE")){
				temp = temp.replace("##LOGOUT_URL##","https://"+Settings.Login_Server_IP+":"+Settings.HTTPS_PORT+"/PublicMobileWebsite/login/logout/"+userid+"@unaas.com");	
			}

			else if(UserType.equalsIgnoreCase("GATEWAY")){
				temp = temp.replace("##LOGOUT_URL##","https://"+Settings.Login_Server_IP+":"+Settings.HTTPS_PORT+"/PublicMobileWebsite/login/logout/"+userid+"@unaas.com");
			}
			else{
				System.out.println("User Type Not Matched ");
			}

			System.out.println(temp+"\n");	


			//Personalized Self.html File		
			File f = null;
			boolean bool = false;

			// create new file			
			f = new File(Settings.GenPath+userid+"\\"+desFolder+"\\"+selfId+".html");

			// tries to create new file in the system
			bool = f.createNewFile();

			// prints
			System.out.println("File created: "+bool);     			
			PrintWriter writer = new PrintWriter(Settings.GenPath+userid+"\\"+desFolder+"\\"+selfId+".html", "UTF-8");
			writer.println(temp);	       
			writer.close();



		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}	

	}	




	/******************************************* S3 Operation Begin**********************************/

	public String createWebsiteS3(String userid,String activation ,String body,String UserType){

		System.out.println("createWebsiteS3");
		String resp = "";
		String respIot="";
		String respInfo="";
		String respHotelUri="";
		String respDeviceBookUri="";	
		String personalinfos="";		
		String cssos="";		
		String link="";

		try {			

			IotDomain  iotDomain					= new IotDomain();				

			String user= userid.toLowerCase();

			// credentials object identifying user for authentication
			AWSCredentials credentials = null;
			credentials = new ProfileCredentialsProvider("default").getCredentials();

			// create a client connection based on credentials
			AmazonS3 s3 = new AmazonS3Client(credentials);

			Region usWest2 = Region.getRegion(Regions.US_WEST_2);
			s3.setRegion(usWest2);        


			String bucketName = user;
			String loginUser = activation.toLowerCase();
			String personalizedS3Folder = loginUser+"personalise/";						
			String desFolder = loginUser+"personalise/";

			S3Util fuS3 = new S3Util();		

			//For IOT Domain	
			respIot =  parseIotMasterIndexLinkS3(body);

			String Pub = parseIotCssoUrlS3(respIot);
			if(Pub!=null){	


				//create personalise folder into bucket			
				boolean respPF = fuS3.createFolder(bucketName,personalizedS3Folder,s3);
				System.out.println("Creating personalise Folder :: "+respPF);

				// list buckets
				for (Bucket bucket : s3.listBuckets()) {
					System.out.println(" - " + bucket.getName());
				}									

				//User's Personalized Folder creation
				boolean fStatus = personalizedFolderS3(desFolder, userid);
				System.out.println("User Personalized Folder created!"+fStatus);


				//Parsing HotelUri
				String[] HotelempUris=iotDomain.parseHotelempUri(respIot);
				String[] hxmls=new String[HotelempUris.length];			
				for(int i=0;i<HotelempUris.length;i++){
					hxmls[i]=(HotelempUris[i]);			

					//Client for hotelemp-doc uri Link
					Client c1=Client.create();
					WebResource resource1=c1.resource(hxmls[i]);
					ClientResponse response1=resource1.get(ClientResponse.class);
					respHotelUri=response1.getEntity(String.class);	
					parseIotHotelUriS3(respHotelUri);				
				}				

				//Parsing DeviceBookUri			
				String[] DeviceBookUris=iotDomain.parseDeviceBookUri(respIot);
				String[] dbxmls=new String[DeviceBookUris.length];			
				for(int i=0;i<DeviceBookUris.length;i++){
					dbxmls[i]=(DeviceBookUris[i]);
					//Client for DeviceBookUri Link
					Client c1=Client.create();
					WebResource resource1=c1.resource(dbxmls[i]);
					ClientResponse response1=resource1.get(ClientResponse.class);
					respDeviceBookUri=response1.getEntity(String.class);
					System.out.println("respDeviceBookUri ==== >"+respDeviceBookUri);
				}

				//For INFO Domain	
				System.out.println("Pub ########## "+Pub);
				respInfo = parseInfoMasterIndexLinkS3(body);			
				String self = parseInfoSelfUrlS3(respInfo);
				personalinfos = InfopersonalinfosS3(self);	
				parseInfoDisplayNameS3(personalinfos);	
				parseInfoUriAndImageURlS3(respHotelUri);	
				String genderInfo = parseInfoGenderS3(respHotelUri);
				String contryInfo =parseInfoContryS3(respHotelUri);	
				String csurl = parseInfoCssoUrlS3(respInfo);
				cssos = InfoCssosurlS3(csurl);			
				String publicUrlInfo = parseInfoPublicUrlS3(cssos);
				parseInfoPrivteUrlS3(cssos);

				//Data's Replacing For Iot html File
				UpdateIotAndInfoS3(respInfo, respIot, desFolder, userid, Pub, bucketName, personalizedS3Folder, publicUrlInfo, contryInfo, genderInfo, UserType);
				System.out.println("Public Website Created ");
				return "201";
			}
			else{
				System.out.println("####### Registration Failed ######## ");
				return "404";	
			}		

		} catch (Exception e) {
			e.printStackTrace();

		}

		return "500";		

	}


	private String  parseIotMasterIndexLinkS3(String body){
		System.out.println("parseIotMasterIndexLinkS3()");
		String respIot=""; 
		IotDomain  iotDomain = new IotDomain();
		//Parsing MasterIndex IOT Link
		Iot masterIndexIot = iotDomain.parseMasterIndexIot(body);
		String iot = masterIndexIot.getIot();
		System.out.println("IOT MasterIndex ################# ::"+iot);	
		//Client go for IotMasterIndex link 
		Client c1=Client.create();
		WebResource resource1=c1.resource(iot);
		ClientResponse  response1=resource1.get(ClientResponse.class);
		respIot=response1.getEntity(String.class);

		return respIot;

	}


	private String parseIotHotelUriS3(String respHotelUri){	
		System.out.println("parseIotHotelUriS3()");
		String contry="";
		String gender="";	
		IotDomain  iotDomain = new IotDomain();
		//parse PersonalInfo Link
		//Set DisplayName 
		Iot parseDisplayName = iotDomain.parseDisplayName(respHotelUri);
		String DisplayName = parseDisplayName.getDisplayname();
		System.out.println("User DisplayName For IOT Domain ############# "+DisplayName);

		//Set URI
		Iot parseUri = iotDomain.parseUri(respHotelUri);
		String uri = parseUri.getUri();
		System.out.println("User URI  For IOT Domain ############# "+uri);				

		//Set Image_Url
		Iot parseImageUrl = iotDomain.parseImageUrl(respHotelUri);
		String imageUrl = parseImageUrl.getImageurl();
		System.out.println("User Image_Url For IOT Domain ############# "+imageUrl);			

		//Set Gender
		Iot parseGender= iotDomain.parseGender(respHotelUri);
		gender = parseGender.getGender();
		System.out.println("User gender For IOT Domain  ############# "+gender);		

		//Set Contry
		Iot parseCountry = iotDomain.parseCountry(respHotelUri);
		contry = parseCountry.getCountry();
		System.out.println("User contry For IOT Domain ############# "+contry);

		return null;

	}

	private String parseIotCssoUrlS3(String respIot){
		System.out.println("parseIotCssoUrlS3()");
		String respCssoUrl="";
		String Pub = null;
		IotDomain  iotDomain = new IotDomain();
		//Parsing CssoUrl
		Iot parseCssoUrl = iotDomain.parseCssoUrl(respIot);
		String CssoUrl = parseCssoUrl.getCssourl();
		System.out.println("CssoUrl uri =====================>"+CssoUrl);
		//Client for CssoUrl Link
		Client c1=Client.create();
		WebResource resource1=c1.resource(CssoUrl);
		ClientResponse response1=resource1.get(ClientResponse.class);
		respCssoUrl=response1.getEntity(String.class);
		int status = response1.getStatus();		
		if(status==200){
			System.out.println("resp CssoUrl ###################### ::"+respCssoUrl);
			//parse CssoURL Link
			//Set PublicIp and Port 
			Iot parsePublic = iotDomain.parsePublic(respCssoUrl);
			Pub = parsePublic.getPub();
			System.out.println("User PublicIp and Port For IOT Domain ############# "+Pub);
			//Set PrivateIp and Port 
			Iot parsePriv = iotDomain.parsePrivate(respCssoUrl);
			String priv = parsePriv.getPriv();
			System.out.println("User PrivateIp and Port For IOT Domain ############# "+priv);
		}else{			
			return Pub;
		}
		return Pub;

	}


	private String  parseInfoMasterIndexLinkS3(String body){
		System.out.println("parseInfoMasterIndexLinkS3()");
		String respInfo=""; 
		InfoDomain  infoDomain = new InfoDomain();

		//Parsing MasterIndex Info Link
		Info masterIndexInfo = infoDomain.parseMasterIndexInfo(body);
		String info = masterIndexInfo.getInfo();
		System.out.println("INFO MasterIndex ################# ::"+info);	

		//Client go for InfoMasterIndex link
		Client c2=Client.create();
		WebResource resource2=c2.resource(info);
		ClientResponse  response2=resource2.get(ClientResponse.class);
		respInfo=response2.getEntity(String.class);
		System.out.println("respInfo =====================>"+respInfo);


		return respInfo;

	}

	private String parseInfoSelfUrlS3(String respInfo){
		System.out.println("parseInfoSelfUrlS3()");
		InfoDomain  infoDomain = new InfoDomain();
		//Parsing selfUrl
		Info selfUrl=infoDomain.parseSelfUrl(respInfo);
		String self = selfUrl.getSelfurl();
		System.out.println("selfUrl =================>"+self);
		return self;
	}

	private String InfopersonalinfosS3(String self){
		System.out.println("InfopersonalinfosS3()");
		//Client for personalinfo uri Link			
		Client c1=Client.create();
		WebResource resource1=c1.resource(self);
		ClientResponse response1=resource1.get(ClientResponse.class);
		String personalinfos=response1.getEntity(String.class);
		System.out.println("resp personalinfo of User In INFO Domain  ############# ::"+personalinfos);

		return personalinfos;
	}


	private String parseInfoDisplayNameS3(String personalinfos){
		System.out.println("parseInfoDisplayNameS3()");
		InfoDomain  infoDomain = new InfoDomain();

		//parse PersonalInfo Link
		//Set DisplayName 
		Info parseDisplayName = infoDomain.parseDisplayName(personalinfos);
		String DisplayNameInfo = parseDisplayName.getDisplayname();
		System.out.println("User DisplayName For INFO Domain ############# "+DisplayNameInfo);

		return DisplayNameInfo;

	}

	private void parseInfoUriAndImageURlS3(String respHotelUri){
		System.out.println("parseInfoUriAndImageURlS3()");
		InfoDomain  infoDomain = new InfoDomain();
		Info parseUri = infoDomain.parseUri(respHotelUri);
		String uriInfo = parseUri.getUri();
		System.out.println("User URI For INFO Domain ############# "+uriInfo);

		//Set Image_Url
		Info parseImageUrl = infoDomain.parseImageUrl(respHotelUri);
		String imageUrlInfo = parseImageUrl.getImageurl();
		System.out.println("User Image_Url For INFO Domain ############# "+imageUrlInfo);	

	}


	private String parseInfoGenderS3(String respHotelUri){
		System.out.println("parseInfoGenderS3()");
		InfoDomain  infoDomain = new InfoDomain();
		//Set Gender
		Info parseGender= infoDomain.parseGender(respHotelUri);
		String genderInfo = parseGender.getGender();
		System.out.println("User gender For INFO Domain  ############# "+genderInfo);
		return genderInfo;

	}



	private String parseInfoContryS3(String respHotelUri){
		System.out.println("parseInfoContryS3()");
		InfoDomain  infoDomain = new InfoDomain();
		//Set Country
		Info parseCountry = infoDomain.parseCountry(respHotelUri);
		String contryInfo = parseCountry.getCountry();
		System.out.println("User Country For INFO Domain #############"+contryInfo);
		return contryInfo;

	}


	private String parseInfoPrivteUrlS3(String cssos){
		System.out.println("parseInfoPrivteUrlS3()");
		InfoDomain  infoDomain = new InfoDomain();
		//Set Private IP and Port
		Info parsePri= infoDomain.parsePrivteUrl(cssos);
		String privUr = parsePri.getPri();
		System.out.println("User Private Url For INFO Domain ############# "+privUr);	

		return privUr;

	}


	private String InfoCssosurlS3(String csurl){
		System.out.println("InfoCssosurlS3()");
		//Client for CSSO info Link
		Client c1=Client.create();
		WebResource resource1=c1.resource(csurl);
		ClientResponse response1=resource1.get(ClientResponse.class);
		String cssos=response1.getEntity(String.class);
		System.out.println("resp from CSSO INFO Domain  ############# ::"+cssos);

		return cssos;
	}


	private String parseInfoPublicUrlS3(String cssos){
		System.out.println("parseInfoPublicUrlS3()");
		InfoDomain  infoDomain = new InfoDomain();
		//Set Public IP and Port 
		Info parsePub = infoDomain.parsePublicUrl(cssos);
		String publicUrlInfo = parsePub.getPub();
		System.out.println("User Public Url For INFO Domain ############# "+publicUrlInfo);

		return publicUrlInfo;

	}

	private String parseInfoCssoUrlS3(String respInfo){
		System.out.println("parseInfoCssoUrlS3()");
		InfoDomain  infoDomain = new InfoDomain();
		//Parsing CssoUrl for INFO
		Info csso=infoDomain.parseCssoUrl(respInfo);
		String csurl = csso.getCssourl();
		System.out.println("CSSO URL for Info Domain =================>"+csurl);
		return csurl;

	}



	private void UpdateIotAndInfoS3(String respInfo,String respIot,String desFolder,String userid, String Pub,String bucketName,String personalizedS3Folder,String publicUrlInfo,String contryInfo, String genderInfo,String UserType){
		System.out.println("UpdateIotAndInfoS3()");
		Iot parseCat=null;
		Iot parseDeviceType=null;
		Iot parseUdn=null;	
		Iot parseL1=null;
		Iot parseL2=null;
		Iot parseModelD = null;
		Iot parseId =null;
		Iot parsePi = null;
		Iot parseServiceType =null;

		IotDomain  iotDomain					= new IotDomain();
		InfoDomain  infoDomain 					= new InfoDomain();

		List<AppInfo> appList = infoDomain.parseAppLists(respInfo);
		List<AppInfo> nappList = new ArrayList<AppInfo>();

		List<DeviceInfo> deviceList = iotDomain.parseDeviceProfileUriList_new(respIot);
		List<DeviceInfo> ndeviceList = new ArrayList<DeviceInfo>();

		if(null != deviceList && deviceList.size() > 0)
		{			

			String deviceProfile = null;
			String deviceSA = null;
			for(DeviceInfo device : deviceList)
			{
				//Device Profile operation
				String deviceUuid = UUID.randomUUID().toString();
				device.setDeviceUuid(deviceUuid);

				Client c1=Client.create();
				WebResource resource1=c1.resource(device.getpUri());		
				ClientResponse response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
				deviceProfile = response1.getEntity(String.class);				

				//Set Category
				parseCat = iotDomain.parseCategory(deviceProfile);
				String cat = parseCat.getCategory();
				System.out.println("User Category For IOT Domain ############# "+cat);
				device.setDeviceCat(cat);					

				//Set DeviceType
				parseDeviceType = iotDomain.parseDeviceType(deviceProfile);
				String deviceType = parseDeviceType.getDevicetype();
				System.out.println("User DeviceType For IOT Domain  ############# "+deviceType);
				device.setDeviceType(deviceType);				

				//layoutGrp(L1)
				parseL1 = iotDomain.parseL1(deviceProfile);
				String l1 = parseL1.getL1();
				System.out.println("User L1 For IOT Domain  ############# "+l1);
				device.setL1(l1);

				//layoutGrp(L2)					
				parseL2= iotDomain.parseL2(deviceProfile);
				String l2 = parseL2.getL2();
				System.out.println("User L2 For IOT Domain  ############# "+l2);
				device.setL2(l2);

				//Set UDN
				parseUdn = iotDomain.parseUdn(deviceProfile);
				String udns = parseUdn.getUdn();
				System.out.println("User UDN For IOT Domain  ############# "+udns);	
				device.setUDN(udns);					

				//Set Model Desc
				parseModelD = iotDomain.parseModelDesc(deviceProfile);
				String md = parseModelD.getModeldesc();
				System.out.println("User ModelDesc  For IOT Domain ############# "+md);
				device.setDeviceModelDesc(md);

				//-------------------------Service action operation
				//Client for DeviceServiceActionUri Link
				System.out.println("----device.getsUri()-----------------"+device.getsUri());
				resource1=c1.resource(device.getsUri());		
				response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
				String SAuris=response1.getEntity(String.class);				

				//Parse DeviceServiceAction link
				Iot deviceServiceUri = iotDomain.parseServiceActions(SAuris); // deviceSA
				String uri = deviceServiceUri.getUriloginDetails();				

				// Client DeviceServiceAction Link
				resource1=c1.resource(uri);		
				response1=resource1.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);
				deviceSA=response1.getEntity(String.class);

				//parse DeviceServiceAction Link				 
				parseId = iotDomain.parseId(deviceSA);

				//Set ProductId
				parsePi = iotDomain.parseProdectId(deviceSA);
				String product = parsePi.getProductid();
				System.out.println("User ProductId For IOT Domain ############# "+product);
				device.setProductId(product);


				//Set ServiceType
				parseServiceType = iotDomain.parseServiceType(deviceSA);
				String serviceType = parseServiceType.getServicetype();
				System.out.println("User ServiceType For IOT Domain ############# "+serviceType);
				device.setServiceType(serviceType);

				updateIotFileS3(desFolder,userid, Pub,device,bucketName,personalizedS3Folder);	
				ndeviceList.add(device);
			}


			//Data's Replacing For Info html File 			

			if(null != appList && appList.size() > 0)
			{
				String appIds = "";
				String appSType = "";
				for(AppInfo app : appList)
				{
					appIds 		= app.getAppId();
					System.out.println("appIds ---------->"+appIds);
					app.setAppId(appIds);												

					appSType	= app.getServiceType();
					System.out.println("App Service Type ----------->"+appSType);
					app.setServiceType(appSType);

					updateInfoFileS3(desFolder, userid, publicUrlInfo,app,bucketName,personalizedS3Folder);
					nappList.add(app);
				}								

			}
		}

		//update Self.html file
		updateSelfFileS3(desFolder, userid, contryInfo, genderInfo, Settings.LOGIN_SERVER,bucketName,personalizedS3Folder,UserType);

		//update index.html file 				
		readIndexFileS3(ndeviceList,nappList,desFolder, "index",userid,bucketName,personalizedS3Folder);


	}

	private boolean personalizedFolderS3(String desFolder,String userid){

		File fil = new File(Settings.GenPath+userid+"\\"+desFolder);

		if (!fil.exists()) {
			if (fil.mkdirs()) {
				System.out.println(userid+"###"+desFolder+"==> User Personalized Folder created!");
			} else {
				System.out.println("Failed to create a Personalized Folder!");
			}}

		return true;
	}

	private boolean updateIotFileS3(String desFolder,String userid, String publicUrlIot,DeviceInfo device,String bucketName,String personalizedS3Folder){		
		System.out.println("updateIotFileS3 ####### getDeviceId  : "+device.getDeviceId());			
		try {				
			//Read,update&Replace Iot html file in Personalized Folder
			readIotFileS3(device.getDeviceUuid(),
					desFolder,
					device.getDeviceId(),
					device.getDeviceModelDesc(),
					publicUrlIot,
					device.getProductId(),
					userid,
					device.getUDN(),
					device.getDeviceType(),
					device.getServiceType(),
					bucketName,
					personalizedS3Folder);

		} catch (Exception e) {
			e.printStackTrace();		
		}
		return true;

	}	

	private boolean updateInfoFileS3(String desFolder,String userid, String publicUrlInfo,AppInfo app,String bucketName,String personalizedS3Folder){		
		System.out.println("updateInfoFileS3() ####### getAppId : "+app.getAppId());
		System.out.println("UserId ===============>"+userid);
		System.out.println("publicUrlInfo =========>"+publicUrlInfo);		
		try {

			//Read,update&Replace Info html file in Personalized Folder
			readInfoFileS3(desFolder, app.getAppId(), publicUrlInfo, userid, app.getServiceType(),bucketName,personalizedS3Folder);				

		} catch (Exception e) {
			e.printStackTrace();		
		}
		return true;

	}





	private boolean updateSelfFileS3(String desFolder,String userid, String contryName,String gender,String  LoginServerUrl,String bucketName,String personalizedS3Folder,String UserType){	
		System.out.println("updateSelfFileS3");
		System.out.println("gender  for User =====>"+gender);		
		System.out.println("Country  for User =====>"+contryName);	
		System.out.println("LoginServerUrl  for User =====>"+LoginServerUrl);

		try {					

			//Read,update&Replace self.html file in Personalized Folder
			readSelfFileS3(desFolder, "self", userid, contryName, gender, LoginServerUrl,bucketName,personalizedS3Folder,UserType);			

		} catch (Exception e) {
			e.printStackTrace();		
		}
		return true;
	}	



	private void readIotFileS3(String deviceUuid , String desFolder,String deviceId,String ctrltype , String pulicUrl ,String productId ,String userId ,String udn ,String deviceType,String serviceType,String bucketName,String personalizedS3Folder){
		System.out.println("Inside the readIotFileS3 ========>");		
		//String devid = deviceId.toLowerCase();

		//http://192.168.0.3:8080 Old pulicUrl
		//https://192.168.0.3:8443 New PulicUrl
		String http = pulicUrl.substring(pulicUrl.indexOf("h"),pulicUrl.lastIndexOf("p"));
		String nhttps = http+"ps://";		
		String publicIp = pulicUrl.substring(pulicUrl.indexOf("//")+2,pulicUrl.lastIndexOf(":"));		
		String updatedPubIp= nhttps+publicIp+":"+Settings.HTTPS_PORT;
		System.out.println("############## updated PublicIp ########## "+updatedPubIp);		

		System.out.println("deviceType ####################### "+deviceType);
		String devT=deviceType.substring(deviceType.indexOf("device:")+7, deviceType.lastIndexOf(":"));
		String devType=devT.toLowerCase();
		System.out.println("Find the file on the based of devType ####### "+devType);

		//System.out.println("Ignore Case for deviceId ========>"+devid);
		System.out.println("ctrltype #################### "+ctrltype);
		System.out.println("pulicUrl #################### "+pulicUrl);
		System.out.println("productId #################### "+productId);
		System.out.println("userId #################### "+userId);
		System.out.println("UDN ########################## "+udn);
		System.out.println("ServiceType #################### "+serviceType);

		String servicename=serviceType;
		servicename = servicename.substring(31);

		String sev = servicename.substring(servicename.indexOf("ras"), servicename.lastIndexOf(":")-0);
		//System.out.println("New Sev ################### "+sev);
		System.out.println("servicename ################### "+servicename);

		String filePath = Settings.GenPath+userId+"\\UNAAS-DEFAULT-V1\\res\\userTemplates\\default\\"+devType+".html";
		BufferedReader br = null;
		String temp = "";
		try {

			String sCurrentLine;
			//String deviceUuid= UUID.randomUUID().toString();

			br = new BufferedReader(new FileReader(filePath));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);				
				temp = temp+sCurrentLine;
			}
			temp = temp.replace("##COMMON_URL##", "../UNAAS-DEFAULT-V1/res/common/");
			//temp = temp.replace("##CTRL_TYPE##", ctrltype);
			//temp = temp.replace("##CTRL_URL##",pulicUrl+"/"+productId+"/"+userId+"/sip:"+userId+"@unaas.com/"+udn+"/"+sev+"/");
			temp = temp.replace("##CTRL_URL##",updatedPubIp+"/"+productId+"/"+userId+"/sip:"+userId+"@unaas.com/"+udn+"/"+sev+"/");
			//temp = temp.replace("##CTRL_URL##",pulicUrl+"/"+productId+"/"+userId+"/sip:"+userId+"@unaas.com/"+udn+"/"+sev+"/");
			temp = temp.replace("##IMAGE_URL##", "../UNAAS-DEFAULT-V1/res/userTemplates/default/images/");
			temp = temp.replace("##SERVICE_TYPE##",serviceType);
			temp = temp.replace("##SELF_URL##", "Self.html");
			System.out.println(temp+"\n");


			//Personalized Iot File			
			File f = null;
			boolean bool = false;

			// create new file			
			f = new File(Settings.GenPath+userId+"\\"+desFolder+"\\"+deviceUuid+devType+".html");

			// tries to create new file in the system
			bool = f.createNewFile();

			// prints
			System.out.println("File created: "+bool); 

			PrintWriter writer = new PrintWriter(Settings.GenPath+userId+"\\"+desFolder+"\\"+deviceUuid+devType+".html", "UTF-8");
			writer.println(temp);		
			writer.close();

			//call for personalized Iot html File send to S3 
			S3Util fus3 = new S3Util();
			String user = userId.toLowerCase();
			String sFile= Settings.GenPath+userId+"\\"+desFolder+"\\"+deviceUuid+devType+".html";			
			String s3PersonalizedFLocation = personalizedS3Folder+deviceUuid+devType+".html";
			fus3.s3UploadIotFile(sFile, user, bucketName,s3PersonalizedFLocation);


		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}	

	}


	private void readInfoFileS3(String desFolder,String appId,String pulicUrl,String userId ,String serviceType,String bucketName,String personalizedS3Folder){
		System.out.println("Inside the readInfoFileS3 ========>");		
		String appid = appId.toLowerCase();
		System.out.println("Ignore Case for AppId ========>"+appid);		
		System.out.println("pulicUrl #################### "+pulicUrl);		
		System.out.println("userId #################### "+userId);
		System.out.println("ServiceType #################### "+serviceType);

		String servicename=serviceType;
		servicename = servicename.substring(31);
		System.out.println("servicename ################### "+servicename);
		String sev = servicename.substring(servicename.indexOf("info"), servicename.lastIndexOf(":")-0);
		//System.out.println("Info Sev ==== > "+sev);

		String filePath = Settings.GenPath+userId+"\\UNAAS-DEFAULT-V1\\res\\userTemplates\\default\\"+appid+".html";
		BufferedReader br = null;
		String temp = "";
		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader(filePath));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);				
				temp = temp+sCurrentLine;				
			}
			temp = temp.replace("##COMMON_URL##", "../UNAAS-DEFAULT-V1/res/common/");			
			//temp = temp.replace("##CTRL_URL##", pulicUrl+"/sip:"+userId+"@unaas.com/"+userId+"/"+sev+"/");
			//temp = temp.replace("##CTRL_URL##", Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/sip:"+userId+"@unaas.com/"+userId+"/"+sev+"/");
			temp = temp.replace("##CTRL_URL##", "https://"+Settings.BACKEND_DATABASES_IP+":"+Settings.HTTPS_PORT+"/BackEndGateway/CCCP/CCCPGateway/sip:"+userId+"@unaas.com/"+userId+"/"+sev+"/");
			temp = temp.replace("##SERVICE_TYPE##",serviceType);
			temp = temp.replace("##SELF_URL##", "Self.html");
			System.out.println(temp+"\n");	


			//Personalized App's File		
			File f = null;
			boolean bool = false;

			// create new file			
			f = new File(Settings.GenPath+userId+"\\"+desFolder+"\\"+appid+".html");

			// tries to create new file in the system
			bool = f.createNewFile();

			// prints
			System.out.println("File created: "+bool);  			
			PrintWriter writer = new PrintWriter(Settings.GenPath+userId+"\\"+desFolder+"\\"+appid+".html", "UTF-8");
			writer.println(temp);	       
			writer.close();

			//call for personalized Info html File send to S3 
			S3Util fus3 = new S3Util();
			String user = userId.toLowerCase();
			String sFile= Settings.GenPath+userId+"\\"+desFolder+"\\"+appid+".html";			
			String s3PersonalizedFLocation = personalizedS3Folder+appid+".html";
			fus3.s3UploadInfoFile(sFile, user, bucketName,s3PersonalizedFLocation);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}	

	}

	private void readIndexFileS3(List<DeviceInfo> deviceList,List<AppInfo> appList , String desFolder,String indexId,String userId,String bucketName,String personalizedS3Folder){		
		//URL indexUrl= null;
		System.out.println("Inside the readIndexFileS3 ========>");				
		System.out.println("userId For ROOM_NUMBER  #################### "+userId);		


		String sPath = Settings.GenPath+userId+"\\UNAAS-DEFAULT-V1\\res\\userTemplates\\default\\"+indexId+".html";
		String dPath = Settings.GenPath+userId+"\\"+desFolder+"\\"+indexId+".html";
		String building = "";
		String info ="";
		String iotAndinfoXml="";
		List<DeviceInfo> ndevicelist = null;
		//boolean flag = true;

		if(null != deviceList && deviceList.size()>0)
		{
			iotAndinfoXml="div  id=\"navmenu\" data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
					+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"
					+ "\n<h3>Remote Monitoring</h3>\n";
			//+ "\n<!-- ##C-LEVEL1## -->\n"	
			ndevicelist = deviceList;
			//}

			for(int i=0; i < deviceList.size(); i++ )
			{
				DeviceInfo device = deviceList.get(i);
				System.out.println(i+" ==================== In side 1st For Block get(i).getL1 ======> "+device.getL1()+" and device.getL2() => "+device.getL2()+"===============================");

				for(int j=0; j < ndevicelist.size(); j++ ){
					DeviceInfo ndevice = ndevicelist.get(j);

					System.out.println(j+" - In side 2nd For Block get(j).getL1 ======>> "+ndevice.getL1()+" and ndevice.getL2() =>> "+ndevice.getL2());
					if(device.getL1().equalsIgnoreCase(ndevice.getL1()))
					{
						System.out.println(j+" - In side 1st If Block get(j).getL1 match ======>>> "+ndevice.getL1());


						if(device.getL2().equalsIgnoreCase(ndevice.getL2()))
						{
							System.out.println(j+" - In side 2nd If Block get(j).getL2 match  ============>>>>  "+ndevice.getL2());
							String devid = ndevice.getDeviceId().toLowerCase();

							if(device.getDeviceId().equalsIgnoreCase(ndevice.getDeviceId())){
								String dev = ndevice.getDeviceType();
								String devT=dev.substring(dev.indexOf("device:")+7, dev.lastIndexOf(":"));
								String deviceType = devT.toLowerCase();

								System.out.println(j+" - In side 3nd If Block get(i).getDeviceId : "+device.getDeviceId()+" not match with get(j).getDeviceId :  ============>>>>  "+ndevice.getDeviceId());
								System.out.println(" Going to add device ========>"+devid);
								/*if(!flag)
								{*/
								building = building	
										+"<div  data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
										+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"
										+ "\n<h3>"+ndevice.getL1()+"</h3>\n";
								building = building		
										+"<div  id=\"navmenu\" data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
										+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"
										+ "\n<h3>"+ndevice.getL2()+"</h3>\n"
										+"<div  id=\"navmenu\" data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
										+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"					
										+ "\n<h3>"+ndevice.getDeviceId()+"</h3>\n";								
								/*flag = true;
								}*/
								building = building			
										+"<ul data-role=\"listview\" data-inset=\"true\" data-theme=\"d\" data-dividertheme=\"b\" class=\"sc_nav\" id=\"inner\">"
										+ "<li><a href=javascript:showContent(\""+ndevice.getDeviceUuid()+deviceType+".html\")>"+ndevice.getDeviceId()+"</a></li></ul>";
								building = building			
										+"</div>"
										+"</div>"
										+"</div>"
										+"</div>"
										+"</div>"
										+"</div>";
							}							
						}
						else
							System.out.println("################# L2 not matched.... ###################");
					}
					else
						System.out.println("################## L1 not matched.... #####################");
				}
			}
			building = building			
					//+"</div>"
					+"</div>";
		}

		iotAndinfoXml = iotAndinfoXml + building		
				//+"</div>"										
				+"<div  data-role=\"collapsible-set\"  data-collapsed-icon=\"arrow-d\" data-expanded-icon=\"arrow-u\" data-iconpos=\"right\" data-theme=\"a\">"
				+ "<div data-role=\"collapsible\" data-collapsed=\"true\" data-theme=\"a\"  data-content-theme=\"a\" >"
				+ "\n<h3>Dashboard Apps</h3>\n"				
				+"<ul data-role=\"listview\" data-inset=\"true\" data-theme=\"d\" data-dividertheme=\"b\" class=\"sc_nav\" id=\"inner\">";
		for(AppInfo app : appList)
		{
			String apps = app.getAppId();
			String appsId = apps.toLowerCase();
			System.out.println("AppId !!!!!!!!!!!!!!!!!!!!!!!!!!! == > "+appsId);
			//String app = app
			String AppName = app.getAppId();
			info	=info
					+"<li>";

			if(AppName.equalsIgnoreCase("mod")){
				info=info
						+"<a href=javascript:showContent(\""+appsId+".html\")>Music</a>";
			}
			else if(AppName.equalsIgnoreCase("vod")){
				info=info
						+"<a href=javascript:showContent(\""+appsId+".html\")>Video</a>";
			}
			else if(AppName.equalsIgnoreCase("webapps")){
				info=info
						+"<a href=javascript:showContent(\""+appsId+".html\")>Web</a>";
			}
			else{
				System.out.println("No App Found ======>");				
			}				
			info=info
					+"</li>";				
		}
		iotAndinfoXml =	iotAndinfoXml+info
				+"</ul>"
				+"</div>"
				+"</div>"						
				+"</div";

		BufferedReader br = null;
		String temp = "";
		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader(sPath));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);				
				temp = temp+sCurrentLine;				
			}
			temp = temp.replace("##COMMON_URL##", "../UNAAS-DEFAULT-V1/res/common/");			
			temp = temp.replace("##ROOM_NUMBER##", userId);	

			for(DeviceInfo device : deviceList)
			{
				String dev = deviceList.get(0).getDeviceType();
				String devT=dev.substring(dev.indexOf("device:")+7, dev.lastIndexOf(":"));
				String deviceType = devT.toLowerCase();
				temp = temp.replace("##FIRST_PAGE##",device.getDeviceUuid()+deviceType+".html");
			}

			temp = temp.replace("!-- ##CSET--LEVEL1## --",iotAndinfoXml);	


			System.out.println(temp+"\n");		

			//Personalized index.html File			
			File f = null;
			boolean bool = false;

			// create new file
			f = new File(Settings.GenPath+userId+"\\"+desFolder+"\\"+indexId+".html");

			// tries to create new file in the system
			bool = f.createNewFile();

			// prints
			System.out.println("File created: "+bool);  			
			PrintWriter writer = new PrintWriter(dPath, "UTF-8");
			writer.println(temp);	       
			writer.close();

			//call for personalized Index html File send to S3 
			S3Util fus3 = new S3Util();
			String user = userId.toLowerCase();
			String sFile= Settings.GenPath+userId+"\\"+desFolder+"\\"+indexId+".html";			
			String s3PersonalizedFLocation = personalizedS3Folder+indexId+".html";
			fus3.s3UploadIndexFile(sFile, user, bucketName,s3PersonalizedFLocation);

			//Call IndexUrl 
			//indexUrl = fus3.s3ReturnIndexUrl(bucketName,s3PersonalizedFLocation);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}
		//return indexUrl;	

	}

	private void readSelfFileS3(String desFolder,String selfId,String userid,String contryName,String gender,String LoginServerUrl,String bucketName,String personalizedS3Folder,String UserType){
		System.out.println("Inside the readSelfFileS3 ========>");
		//System.out.println("desFoder ################ "+desFoder);
		System.out.println("DISPLAY NAME #################### "+userid);
		System.out.println("ContryName #################### "+contryName);
		System.out.println("Gender #################### "+gender);
		System.out.println("LoginServer Ip and Port #################### "+LoginServerUrl);
		System.out.println("UserType ################## "+UserType);

		String filePath = Settings.GenPath+userid+"\\UNAAS-DEFAULT-V1\\res\\userTemplates\\default\\"+selfId+".html";
		BufferedReader br = null;
		String temp = "";
		try {

			String sCurrentLine;

			br = new BufferedReader(new FileReader(filePath));

			while ((sCurrentLine = br.readLine()) != null) {
				//System.out.println(sCurrentLine);				
				temp = temp+sCurrentLine;				
			}
			temp = temp.replace("##COMMON_URL##", "../UNAAS-DEFAULT-V1/res/common/");
			temp = temp.replace("##MY_DISPLAY_NAME##",userid);
			temp = temp.replace("##MY_COUNTRY_NAME##",contryName);
			temp = temp.replace("##MY_GENDER##", gender);				

			if(UserType.equalsIgnoreCase("SOLUTION")){
				temp = temp.replace("##LOGOUT_URL##","https://"+Settings.Login_Server_IP+":"+Settings.HTTPS_PORT+"/MobileWebsite/userLogin/logout/"+userid+"@unaas.com");
			}
			else if(UserType.equalsIgnoreCase("SITE")){
				temp = temp.replace("##LOGOUT_URL##","https://"+Settings.Login_Server_IP+":"+Settings.HTTPS_PORT+"/MobileWebsite/userLogin/logout/"+userid+"@unaas.com");	
			}

			else if(UserType.equalsIgnoreCase("GATEWAY")){
				temp = temp.replace("##LOGOUT_URL##","https://"+Settings.Login_Server_IP+":"+Settings.HTTPS_PORT+"/MobileWebsite/userLogin/logout/"+userid+"@unaas.com");
			}
			else{
				System.out.println("User Type Not Matched ");
			}

			System.out.println(temp+"\n");	


			//Personalized Self.html File		
			File f = null;
			boolean bool = false;

			// create new file			
			f = new File(Settings.GenPath+userid+"\\"+desFolder+"\\"+selfId+".html");

			// tries to create new file in the system
			bool = f.createNewFile();

			// prints
			System.out.println("File created: "+bool);     			
			PrintWriter writer = new PrintWriter(Settings.GenPath+userid+"\\"+desFolder+"\\"+selfId+".html", "UTF-8");
			writer.println(temp);	       
			writer.close();

			//call for personalized Self html File send to S3 
			S3Util fus3 = new S3Util();
			String user = userid.toLowerCase();
			String sFile= Settings.GenPath+userid+"\\"+desFolder+"\\"+selfId+".html";			
			String s3PersonalizedFLocation = personalizedS3Folder+selfId+".html";
			fus3.s3UploadSelfFile(sFile, user, bucketName,s3PersonalizedFLocation);

		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if (br != null)br.close();
			} catch (IOException ex) {
				ex.printStackTrace();
			}
		}	
	}


	@DELETE	
	@Path("/delpersonalise/data/{id}")
	public String delpersonalise(@PathParam("id")String id){

		System.out.println("PersonalizeService.delpersonalise()");
		String userid = id.substring(0, id.lastIndexOf("@"));
		//Delete personalized Folder in Local File System
		String desFolder = userid+"personalise/";
		String delPersonalise=Settings.GenPath+userid+"\\"+desFolder+"\\";
		File delPerFol = new File(delPersonalise);
		String resp = deleteDir(delPerFol);
		System.out.println("############################## Personalize Folder Deleted From Local File System #######################");
		return resp;
	}

	private String deleteDir(File file) {
		try{
		File[] contents = file.listFiles();
		if (contents != null) {
			for (File f : contents) {
				deleteDir(f);
			}
		}
		file.delete();		
		return "201";
		}
		catch(Exception e){
			e.printStackTrace();
			return "500";
		}

	}
}