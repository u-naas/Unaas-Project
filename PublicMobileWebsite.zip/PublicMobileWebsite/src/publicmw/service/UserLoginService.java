
package publicmw.service;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.PrintWriter;
import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Hashtable;
import java.util.List;
import java.util.Map.Entry;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Consumes;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.log4j.Logger;

import publicmw.settings.Settings;
import publicmw.parse.ParentParser;
import publicmw.pojo.CMCInfo;
import publicmw.parse.CloudServerInfo;
import publicmw.pojo.DeviceRegister;
import publicmw.pojo.RegistrationInfo;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.S3Object;

import publicmw.utils.Utils;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

import publicmw.pojo.ResourceBean;


@Path("/login")
public class UserLoginService {
	@Context
	ServletContext context;


	@GET
	@Path("/")
	@Produces(MediaType.TEXT_HTML)
	public Response getLoginPage(){

		String msg="In User login Service for Login";
		String url;
		if(Settings.useSSL)
			url=Settings.SELF_URL1;
		else
			url=Settings.SELF_URL;
		System.out.println(msg);
		msg=null;
		try{
			String path=context.getRealPath("/");
			String cpath=context.getContextPath();
			System.out.println("Context path is :"+cpath);
			System.out.println("Path is :"+path);
			BufferedReader br=new BufferedReader(new FileReader(path+"/login.html"));
			String loginhtml="";
			String line;
			while((line=br.readLine())!=null){
				if(line.indexOf("action=\"\"")!=-1)
					line=line.replace("action=\"\"","action=\""+url+"/PublicMobileWebsite/login/authenticateUser"+"\"");
				System.out.println(line);
				loginhtml=loginhtml+"\n"+line;
			}	
			br.close();
			path=null;
			cpath=null;
			br=null;
			return Response.ok(loginhtml,MediaType.TEXT_HTML).build();
		}
		catch(Exception e){
			e.printStackTrace();
			return Response.serverError().build();
		}
	}



	@POST
	@Path("/logout/{userid}")
	public Response logout(@PathParam("userid")String userid){

		String url;
		if(Settings.useSSL)
			url=Settings.SELF_URL1;
		else
			url=Settings.SELF_URL;

		System.out.println("In Login Server to Logout  :"+userid);
		String xml="<?xml version=\"1.0\"?><login>"+
				"<loginUrl>"+url+"/PublicMobileWebsite/login/"+"</loginUrl>"+
				"</login>";

		return Response.ok(xml).build();
	}

	/*@POST
	@Path("/site")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public URI createWebsiteSite(@FormParam("siteid")String siteid,@FormParam("userid")String userid,@FormParam("pwd")String pwd,@FormParam("userType")String userType@Context HttpHeaders headers,@Context HttpServletRequest request@FormParam("publicIp")String publicip,@FormParam("privateIp")String privateip){

		System.out.println("UserLoginService.site()");		
		String site = siteid.substring(0, siteid.lastIndexOf("@"));
		Client c=Client.create();	
		WebResource resource=c.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/CloudServer/"+site+"/info");                         
		ClientResponse response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);	
		String xml = response.getEntity(String.class);						
		CloudServerInfo info=CloudServerInfo.parse(xml);
		String solutionid = info.getParentId();
		System.out.println("parent ======= >"+solutionid);

		//Template Extraction(local file system and s3)
		Client client=Client.create();
		resource = client.resource(Settings.MOBILE_WEBSITE_ADDRESS+"extract/Template/"+solutionid);
		String tempresp= resource.type(MediaType.TEXT_PLAIN).post(String.class);
		if(tempresp.equalsIgnoreCase("201")){

			//Personalize Data (Domain policy, master index and replacement in local file system and s3)
			client=Client.create();
			resource = client.resource(Settings.MOBILE_WEBSITE_ADDRESS+"personalize/site/"+siteid);
			ClientResponse resp= resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class);			
			URI link = resp.getLocation();

			if(link!=null){				
				return link;	
			}
			else{
				System.out.println("Link creation failed Site ");				
				return null;	
			}

		}
		return null;

	}




	@POST
	@Path("/lot")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public URI createWebsiteLot(@FormParam("lotid")String lotid,@FormParam("userid")String userid,@FormParam("pwd")String pwd,@FormParam("userType")String userType@Context HttpHeaders headers,@Context HttpServletRequest request@FormParam("publicIp")String publicip,@FormParam("privateIp")String privateip){

		System.out.println("UserLoginService.lot()");
		String lot = lotid.substring(0, lotid.lastIndexOf("@"));

		//Get Parent of lot = Site
		Client c=Client.create();	
		WebResource resource=c.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/CloudServer/"+lot+"/info");                         
		ClientResponse response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);	
		String xml = response.getEntity(String.class);						
		CloudServerInfo info=CloudServerInfo.parse(xml);
		String siteId = info.getParentId();
		System.out.println("siteId ======= >"+siteId);					

		//Get Parent of site = Solution
		c=Client.create();	
		resource=c.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/CloudServer/"+siteId+"/info");                         
		response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);	
		String xml1 = response.getEntity(String.class);						
		CloudServerInfo info2=CloudServerInfo.parse(xml1);
		String solutionid = info2.getParentId();
		System.out.println("parent ======= >"+solutionid);

		//Template Extraction(local file system and s3)
		Client client=Client.create();
		resource = client.resource(Settings.MOBILE_WEBSITE_ADDRESS+"extract/Template/"+solutionid);
		String tempresp= resource.type(MediaType.TEXT_PLAIN).post(String.class);

		if(tempresp.equalsIgnoreCase("201")){

			//Personalize Data (Domain policy, master index and replacement in local file system and s3)
			client=Client.create();
			resource = client.resource(Settings.MOBILE_WEBSITE_ADDRESS+"personalize/lot/"+lotid);
			ClientResponse resp= resource.type(MediaType.TEXT_PLAIN).post(ClientResponse.class);			
			URI link = resp.getLocation();

			if(link!=null){									
				return link;	
			}
			else{				
				System.out.println("Link creation failed Lot ");
				return null;
			}

		}
		return null;
	}*/



	@POST
	@Path("/solution")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public String createWebsiteSolution(@FormParam("solutionid")String solutionid){

		System.out.println("UserLoginService.Solution()");
		System.out.println("solution private Id =====>"+solutionid);

		String solution = solutionid.substring(0, solutionid.lastIndexOf("@"));
		System.out.println("solution public Id ###### "+solution);

		//Template Extraction(local file system and s3)		
		Client client=Client.create();
		WebResource	resource = client.resource(Settings.MOBILE_WEBSITE_ADDRESS+"extract/Template/"+solution);
		String tempresp= resource.type(MediaType.TEXT_PLAIN).post(String.class);

		if(tempresp.equalsIgnoreCase("201")){

			//Personalize Data (Domain policy, master index and replacement in local file system and s3)
			client=Client.create();
			resource = client.resource(Settings.MOBILE_WEBSITE_ADDRESS+"personalize/solution/"+solutionid);
			String  resp= resource.type(MediaType.TEXT_PLAIN).post(String.class);		
			if(resp.equals("201")){				
				System.out.println("Public Mobile Website Response (UserLoginService)"+resp);
				return resp;
			}
			else{
				System.out.println("Public Mobile Website failed for Solution ");
				return "500";
			}

		}
		return "500";

	}



	@POST
	@Path("/authenticateUser")
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public Response authenticateUser(@FormParam("solution")String solution,@FormParam("userid")String userid,@FormParam("pwd")String pwd,/*@FormParam("userType")String userType*/@Context HttpHeaders headers,@Context HttpServletRequest request/*@FormParam("publicIp")String publicip,@FormParam("privateIp")String privateip*/){

		System.out.println("UserLoginService.authenticateUser()");
		try{
			String url;
			if(Settings.useSSL)
				url=Settings.SELF_URL1;
			else
				url=Settings.SELF_URL;
			Client client=Client.create();
			client.setConnectTimeout(60000);
			client.setReadTimeout(60000);

			String acode=solution.substring(0,solution.indexOf("@"));

			//get parent id based on domain name
			String domianname =userid.substring(userid.indexOf("@")+1,userid.lastIndexOf("."));
			String uid = userid.substring(0, userid.lastIndexOf("@"));

			ParentParser rp = new ParentParser();
			Client c=Client.create();
			WebResource r=c.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/service/getParentId/"+domianname);
			ClientResponse response=r.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);	
			String res1 = response.getEntity(String.class);
			int sts = response.getStatus();
			System.out.println("res1"+res1);

			//parent id parser
			ResourceBean oplist = rp.parseoperatorId(res1);	
			String parentId = oplist.getOpid();
			System.out.println("parentId  == "+parentId);

			// authenticate user with key cloak
			String body = "username="+uid+"&password="+pwd+"&client_id=PublicMobileWebsite&grant_type=password";
			Client c2=Client.create();
			WebResource r2=c2.resource(Settings.KeyCloak_ADDRESS+"/auth/realms/"+parentId+"/protocol/openid-connect/token");				
			ClientResponse response2=r2.type("application/x-www-form-urlencoded").post(ClientResponse.class,body);				
			String token = response2.getEntity(String.class);
			//String res   =response2.getEntity(String.class);
			int resp     = response2.getStatus();		
			String res = Integer.toString(resp);
			System.out.println("User Authentication Response ======"+res);		

			if(res.startsWith("400")||res.startsWith("<html>")){
				System.out.println("Authentication Failed Client not Found ");
				try{
					String path=context.getRealPath("/");
					String cpath=context.getContextPath();
					System.out.println("Context path is :"+cpath);
					System.out.println("Path is :"+path);
					BufferedReader br=new BufferedReader(new FileReader(path+"/noauth.html"));
					String loginhtml="";
					String line;
					while((line=br.readLine())!=null){
						if(line.indexOf("action=\"\"")!=-1)
							line=line.replace("action=\"\"","action=\""+url+"/PublicMobileWebsite/login/authenticateUser"+"\"");
						System.out.println(line);
						loginhtml=loginhtml+"\n"+line;
					}	
					br.close();
					path=null;
					cpath=null;
					br=null;
					return Response.ok(loginhtml,MediaType.TEXT_HTML).build();
				}
				catch(Exception e){
					e.printStackTrace();
					return Response.serverError().build();
				}
			}			
			else{
				// find Solution	
				Client client1 = Client.create();
				WebResource resource=client1.resource(Settings.ACTIVATION_SERVER_ADDRESS+"/ActivationServer/service/checkSolution/"+acode);
				String resp1=resource.type(MediaType.TEXT_PLAIN).post(String.class);						
				System.out.println(" ###### Solution  resp===========>######### "+resp1);

				if(resp1.equals("404")){
					System.out.println("Solution not Found  = "+resp1);
					try{
						String path=context.getRealPath("/");
						String cpath=context.getContextPath();
						System.out.println("Context path is :"+cpath);
						System.out.println("Path is :"+path);
						BufferedReader br=new BufferedReader(new FileReader(path+"/authfailed.html"));
						String loginhtml="";
						String line;
						while((line=br.readLine())!=null){
							if(line.indexOf("action=\"\"")!=-1)
								line=line.replace("action=\"\"","action=\""+url+"/PublicMobileWebsite/login/authenticateUser"+"\"");
							System.out.println(line);
							loginhtml=loginhtml+"\n"+line;
						}	
						br.close();
						path=null;
						cpath=null;
						br=null;
						return Response.ok(loginhtml,MediaType.TEXT_HTML).build();
					}
					catch(Exception e){
						e.printStackTrace();
						return Response.serverError().build();
					}
				}
				else{


					if (Settings.CLOUD_ENABLED.equalsIgnoreCase("false")){
						boolean status = check(solution, acode);
						String privateid = acode.toLowerCase();
						if (status==true) {	
							//return index html page local
							String link = "https://"+Settings.SELF_IP+":"+Settings.HTTPS_PORT+"/MW/"+acode+"/"+privateid+"personalise/index.html";
							return Response.seeOther(new URI(link)).build();
						}else{
							try{								
								String path=context.getRealPath("/");
								String cpath=context.getContextPath();
								System.out.println("Context path is :"+cpath);
								System.out.println("Path is :"+path);
								BufferedReader br=new BufferedReader(new FileReader(path+"/webfailed.html"));
								String loginhtml="";
								String line;
								while((line=br.readLine())!=null){
									if(line.indexOf("action=\"\"")!=-1)
										line=line.replace("action=\"\"","action=\""+url+"/PublicMobileWebsite/login/authenticateUser"+"\"");
									System.out.println(line);
									loginhtml=loginhtml+"\n"+line;
								}
								br.close();
								path=null;
								cpath=null;
								br=null;
								line=null;
								return Response.ok(loginhtml,MediaType.TEXT_HTML).build();
							}
							catch(Exception e){
								e.printStackTrace();
								return Response.serverError().build();
							}
						}

					}
					else if (Settings.CLOUD_ENABLED.equalsIgnoreCase("true")){
						//return index html page (s3)
						boolean status = checks3(solution, acode);					
						if (status==true) {	
							String link = "https://s3-us-west-2.amazonaws.com/"+solution+"/"+acode+"personalise/index.html";
							return Response.seeOther(new URI(link)).build();
						}
						else{
							try{								
								String path=context.getRealPath("/");
								String cpath=context.getContextPath();
								System.out.println("Context path is :"+cpath);
								System.out.println("Path is :"+path);
								BufferedReader br=new BufferedReader(new FileReader(path+"/webfailed.html"));
								String loginhtml="";
								String line;
								while((line=br.readLine())!=null){
									if(line.indexOf("action=\"\"")!=-1)
										line=line.replace("action=\"\"","action=\""+url+"/PublicMobileWebsite/login/authenticateUser"+"\"");
									System.out.println(line);
									loginhtml=loginhtml+"\n"+line;
								}
								br.close();
								path=null;
								cpath=null;
								br=null;
								line=null;
								return Response.ok(loginhtml,MediaType.TEXT_HTML).build();
							}
							catch(Exception e){
								e.printStackTrace();
								return Response.serverError().build();
							}
						}

					}else{
						try{								
							String path=context.getRealPath("/");
							String cpath=context.getContextPath();
							System.out.println("Context path is :"+cpath);
							System.out.println("Path is :"+path);
							BufferedReader br=new BufferedReader(new FileReader(path+"/enabledfail.html"));
							String loginhtml="";
							String line;
							while((line=br.readLine())!=null){
								if(line.indexOf("action=\"\"")!=-1)
									line=line.replace("action=\"\"","action=\""+url+"/PublicMobileWebsite/login/authenticateUser"+"\"");
								System.out.println(line);
								loginhtml=loginhtml+"\n"+line;
							}
							br.close();
							path=null;
							cpath=null;
							br=null;
							line=null;
							return Response.ok(loginhtml,MediaType.TEXT_HTML).build();
						}
						catch(Exception e){
							e.printStackTrace();
							return Response.serverError().build();
						}
					}	
				}
			}
		}catch(Exception e1){
			e1.printStackTrace();
			return Response.serverError().build();
		}


	}
	
	@GET
	@Path("/checkwebsite/{id}")	
	public String checkwebsite(@PathParam("id")String id){
		
		System.out.println("UserLoginService.checkwebsite() "+id);
		try {			
			String privateid = id.toLowerCase();
			File file = new File(Settings.GenPath+id+"/"+privateid+"personalise/");

			if (file.exists() && file.isDirectory()) {
				System.out.println("Folder exists");			   
				return "201";
			}else{
				return "404"; 
			}				

		} catch (Exception e) {
			e.printStackTrace();

		}	
		return "500";
		
	}
	
	@DELETE	
	@Path("/deletewebsite/{id}")
	public String deletewebsite(@PathParam("id")String id){

		System.out.println("UserLoginService.deletewebsite()");
		String userid = id.substring(0, id.lastIndexOf("@"));
		
		//Delete Website  in Local File System		
		String delWebsite=Settings.GenPath+userid;
		File delWs = new File(delWebsite);
		String resp = deleteDir(delWs);
		System.out.println("################### Public Mobile Website Deleted ###################");
		return resp;
	}

	private boolean check(String userId,String activation){
		System.out.println("UserLoginService.check()");
		try {
			System.out.println("UserLoginService.check()" +userId);
			System.out.println("UserLoginService.check()" +activation);
			String privateid = activation.toLowerCase();
			File file = new File(Settings.GenPath+activation+"/"+privateid+"personalise/");

			if (file.exists() && file.isDirectory()) {
				System.out.println("Folder exists");			   
				return true;
			}else{
				return false; 
			}				

		} catch (Exception e) {
			e.printStackTrace();

		}	
		return false;

	}

	private boolean checks3(String userId,String activation){	
		userId = userId.toLowerCase();
		activation = activation.toLowerCase();	
		try {			
			AWSCredentials credentials = null;
			credentials = new ProfileCredentialsProvider("default").getCredentials();

			// create a client connection based on credentials
			AmazonS3 s3 = new AmazonS3Client(credentials);

			Region usWest2 = Region.getRegion(Regions.US_WEST_2);
			s3.setRegion(usWest2);  	    
			S3Object object = s3.getObject(userId,activation+"personalise/index.html");
			System.out.println("check ############## personalizedS3Folder "+object); 

		} catch (AmazonServiceException e) {
			String errorCode = e.getErrorCode();
			if (!errorCode.equals("NoSuchKey")) {
				throw e;
			}
			Logger.getLogger(getClass()).debug("No such key!!!", e);
			return false;
		}

		return true;

	}	

	private String deleteDir(File file) {
		try{
		File[] contents = file.listFiles();
		if (contents != null) {
			for (File f : contents) {
				deleteDir(f);
			}
		}
		file.delete();		
		return "201";
		}
		catch(Exception e){
			e.printStackTrace();
			return "500";
		}

	}


}