/* This class represents the Login Services and handles Solution, Site and Gateway Logins
 * Author : Avikesh */


package publicmw.service;

import java.io.File;
import java.io.FileOutputStream;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.util.EntityUtils;

import publicmw.parse.Template;
import publicmw.pojo.Temp;
import publicmw.settings.Settings;
import publicmw.utils.S3Util;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.org.apache.xml.internal.security.utils.Base64;



@Path("/extract")
public class ExtractTemplateService {
	@Context
	ServletContext context;


	@POST
	@Produces(MediaType.TEXT_PLAIN)	
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/Template/{activation}")
	public String extractTemplate(@PathParam("activation")String activation){
		System.out.println("ExtractTemplateService.extractTemplate()");
		String TemplateId;
		//check Enabled true or false 
		if (Settings.CLOUD_ENABLED.equalsIgnoreCase("false")){			
			System.out.println("GetDefaultTemplateIdforSolution()");
			String resp = "";
			//Get DefaultTemplateId for Solution
			Client c=Client.create();
			WebResource resource=c.resource(Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/"+activation+"/getDefaultTempId");
			ClientResponse response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);		
			resp=response.getEntity(String.class);	

			Template  temparse = new Template();
			//Parse and get the TemplateId
			Temp t =  temparse.parseTemplateInfo(resp);
			TemplateId = t.getTemplateId();
			System.out.println("templateId ################ ========>"+TemplateId);			

			//Make Directory for Resource Jar Folder			
			File files = new File(Settings.GenPath+activation+"\\"+TemplateId+"\\res\\");
			if (!files.exists()) {
				if (files.mkdirs()) {
					System.out.println("directories are created!");
				} else {
					System.out.println("Failed to create directories!");
				}
			}	


			//Download Resource Jar File
			System.out.println("TemplateId ============= > "+TemplateId );
			String url = Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/"+activation+"/"+TemplateId+"/getResourcePackage";
			try {
				int tcpConnTimeout = 10000;
				int rspTimeout=10000;

				byte[] bytes 			= null;
				HttpClient httpclient 	= null;
				HttpEntity entity 		= null;
				try{
					final HttpParams httpParams = new BasicHttpParams();

					if(0 >= tcpConnTimeout){
						tcpConnTimeout = 10000;
					}

					if(0 >= rspTimeout){
						rspTimeout = 10000;
					}

					HttpConnectionParams.setConnectionTimeout(httpParams, tcpConnTimeout);			
					HttpConnectionParams.setSoTimeout(httpParams, rspTimeout);
					HttpConnectionParams.setStaleCheckingEnabled(httpParams, true);
					httpParams.setParameter("http.tcp.nodelay", true);

					httpclient = new DefaultHttpClient(httpParams);

					HttpGet httpget = new HttpGet(url);
					System.out.println("Downloading downloadResJar for URL:" + url);
					HttpResponse response1 = httpclient.execute(httpget);
					if(response1.getStatusLine().getStatusCode() == 200){
						entity = response1.getEntity();
						if (entity != null) {
							bytes = EntityUtils.toByteArray(entity);
							System.out.println("Downloaded downloadResJar for URL:" + url);
						}
					}                        
				}catch(Exception e){
					e.printStackTrace();
					bytes = null;			
				}finally{
					if(null != entity){
						EntityUtils.consumeQuietly(entity);
					}

					if(null == bytes){
						System.out.println("Couldn't download downloadResJar for URL:" + url);

					}
				}		

				bytes = Base64.decode(bytes);			
				File file = new File(Settings.GenPath+activation+"/"+TemplateId+"/res/"+TemplateId+".jar");					         

				FileOutputStream fos = new FileOutputStream(file);
				fos.write(bytes);
				fos.close();


				//Extract Resource Jar File			
				String jarFile = Settings.GenPath+activation+"\\"+TemplateId+"\\res\\"+TemplateId+".jar";
				String destDir = Settings.GenPath+activation+"\\"+TemplateId+"\\res\\";
				boolean bRetVal = false;			
				try {
					java.util.jar.JarFile jarfile = new java.util.jar.JarFile(new java.io.File(jarFile)); 
					java.util.Enumeration<java.util.jar.JarEntry> enu= jarfile.entries();
					while(enu.hasMoreElements())
					{
						String destdir = destDir;
						java.util.jar.JarEntry je = enu.nextElement();

						System.out.println(je.getName());

						java.io.File fl = new java.io.File(destdir + je.getName());
						if(!fl.exists())
						{
							fl.getParentFile().mkdirs();
							fl = new java.io.File(destdir + je.getName());
						}
						if(je.isDirectory())
						{
							continue;
						}
						java.io.InputStream is = jarfile.getInputStream(je);
						java.io.FileOutputStream fo = new java.io.FileOutputStream(fl);
						while(is.available()>0)
						{
							fo.write(is.read());
						}
						fo.close();
						is.close();				    
					}

					jarfile.close();
					bRetVal = true;
					System.out.println("Extract Resource File:" + destDir + " : SUCCESSFULL");
				} catch (Exception e) {
					System.out.println("Extract Resource File:" + destDir + " : FAILED");
					e.printStackTrace();
				}	

				//Delete Resource Jar File			
				new File(Settings.GenPath+activation+"\\"+TemplateId+"\\res\\"+TemplateId+".jar").delete();		

			} catch (Exception e) {
				e.printStackTrace();

			}
		}	
		else if (Settings.CLOUD_ENABLED.equalsIgnoreCase("true")){		

			// credentials object identifying user for authentication
			AWSCredentials credentials = null;
			credentials = new ProfileCredentialsProvider("default").getCredentials();

			// create a client connection based on credentials
			AmazonS3 s3 = new AmazonS3Client(credentials);

			Region usWest2 = Region.getRegion(Regions.US_WEST_2);
			s3.setRegion(usWest2);	


			Template  temparse = new Template();
			Client c=Client.create();
			WebResource resource=c.resource(Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/"+activation+"/getDefaultTempId");
			ClientResponse response=resource.type(MediaType.TEXT_PLAIN).get(ClientResponse.class);		
			String resp=response.getEntity(String.class);

			//Parse and get the TemplateId
			Temp t =  temparse.parseTemplateInfo(resp);
			TemplateId = t.getTemplateId();
			System.out.println("templateId ################ ========>"+TemplateId);		


			//Make Directory for Resource Jar Folder			
			File files = new File(Settings.GenPath+activation+"\\"+TemplateId+"\\res\\");
			if (!files.exists()) {
				if (files.mkdirs()) {
					System.out.println("directories are created!");
				} else {
					System.out.println("Failed to create directories!");
				}
			}	


			//Download Resource Jar File
			System.out.println("TemplateId ============= > "+TemplateId );
			String url = Settings.BACKEND_GATEWAY_ADDRESS+"/BackEndGateway/CCCP/CCCPGateway/"+activation+"/"+TemplateId+"/getResourcePackage";
			try {
				int tcpConnTimeout = 10000;
				int rspTimeout=10000;

				byte[] bytes 			= null;
				HttpClient httpclient 	= null;
				HttpEntity entity 		= null;
				try{
					final HttpParams httpParams = new BasicHttpParams();

					if(0 >= tcpConnTimeout){
						tcpConnTimeout = 10000;
					}

					if(0 >= rspTimeout){
						rspTimeout = 10000;
					}

					HttpConnectionParams.setConnectionTimeout(httpParams, tcpConnTimeout);			
					HttpConnectionParams.setSoTimeout(httpParams, rspTimeout);
					HttpConnectionParams.setStaleCheckingEnabled(httpParams, true);
					httpParams.setParameter("http.tcp.nodelay", true);

					httpclient = new DefaultHttpClient(httpParams);

					HttpGet httpget = new HttpGet(url);
					System.out.println("Downloading downloadResJar for URL:" + url);
					HttpResponse response1 = httpclient.execute(httpget);
					if(response1.getStatusLine().getStatusCode() == 200){
						entity = response1.getEntity();
						if (entity != null) {
							bytes = EntityUtils.toByteArray(entity);
							System.out.println("Downloaded downloadResJar for URL:" + url);
						}
					}                        
				}catch(Exception e){
					e.printStackTrace();
					bytes = null;			
				}finally{
					if(null != entity){
						EntityUtils.consumeQuietly(entity);
					}

					if(null == bytes){
						System.out.println("Couldn't download downloadResJar for URL:" + url);

					}
				}		

				bytes = Base64.decode(bytes);			
				File file = new File(Settings.GenPath+activation+"/"+TemplateId+"/res/"+TemplateId+".jar");					         

				FileOutputStream fos = new FileOutputStream(file);
				fos.write(bytes);
				fos.close();


				//Extract Resource Jar File			
				String jarFile = Settings.GenPath+activation+"\\"+TemplateId+"\\res\\"+TemplateId+".jar";
				String destDir = Settings.GenPath+activation+"\\"+TemplateId+"\\res\\";
				boolean bRetVal = false;
				try {
					java.util.jar.JarFile jarfile = new java.util.jar.JarFile(new java.io.File(jarFile)); 
					java.util.Enumeration<java.util.jar.JarEntry> enu= jarfile.entries();
					while(enu.hasMoreElements())
					{
						String destdir = destDir;
						java.util.jar.JarEntry je = enu.nextElement();

						System.out.println(je.getName());

						java.io.File fl = new java.io.File(destdir + je.getName());
						if(!fl.exists())
						{
							fl.getParentFile().mkdirs();
							fl = new java.io.File(destdir + je.getName());
						}
						if(je.isDirectory())
						{
							continue;
						}
						java.io.InputStream is = jarfile.getInputStream(je);
						java.io.FileOutputStream fo = new java.io.FileOutputStream(fl);
						while(is.available()>0)
						{
							fo.write(is.read());
						}
						fo.close();
						is.close();				    
					}

					jarfile.close();
					bRetVal = true;
					System.out.println("Extract Resource File:" + destDir + " : SUCCESSFULL");
				} catch (Exception e) {
					System.out.println("Extract Resource File:" + destDir + " : FAILED");
					e.printStackTrace();
				}	

				//Delete Resource Jar File			
				new File(Settings.GenPath+activation+"\\"+TemplateId+"\\res\\"+TemplateId+".jar").delete();				
				//create folder into bucket	
				String templateFolder = TemplateId+"/res/";
				String solution= activation.toLowerCase();
				String bucketName = solution;			

				S3Util fuS3 = new S3Util();	
				boolean respTF = fuS3.createFolder(bucketName,templateFolder,s3);
				System.out.println("Creating Template Folder :: "+respTF);

				//File And Folder Transfer Local File System To S3 Bucket
				fuS3.uploadResFile(TemplateId, solution, bucketName);				

			} catch (Exception e) {
				e.printStackTrace();
			}

		}
		else{
			System.out.println	("Template Extraction Failed");
			return "500";

		}
		return "201";

	}
}