package publicmw.pojo;

public class User {

	
//	String custId;
	String userId;
	String activationcode;
	String userType;
	
	public String getUserType() {
		return userType;
	}
	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getActivationcode() {
		return activationcode;
	}
	public void setActivationcode(String activationcode) {
		this.activationcode = activationcode;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	
	
	
	/*public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
		
		
		
	}*/
}
