package publicmw.pojo;

import java.util.ArrayList;
import java.util.Date;
public class DeviceRegister {
	
	
	private String customerId;
	ArrayList<RegistrationInfo> addressList;
	private Date regDate; 
	
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public ArrayList<RegistrationInfo> getAddressList() {
		return addressList;
	}
	public void setAddressList(ArrayList<RegistrationInfo> addressList) {
		this.addressList = addressList;
	}
	
	
	
	

}
