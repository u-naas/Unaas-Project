package publicmw.pojo;

public class Temp {
	
	
	//Template
	String templateId;
	
	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
	
	
}
