package publicmw.pojo;

public class RegistrationInfo {
    private String registrationType;
    private String domainName;
    private String publicIP;
	private String privateIP;
	private String publicPort;
	private String privatePort;
	public String getRegistrationType() {
		return registrationType;
	}
	public void setRegistrationType(String registrationType) {
		this.registrationType = registrationType;
	}
	public String getDomainName() {
		return domainName;
	}
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}
	public String getPublicIP() {
		return publicIP;
	}
	public void setPublicIP(String publicIP) {
		this.publicIP = publicIP;
	}
	public String getPrivateIP() {
		return privateIP;
	}
	public void setPrivateIP(String privateIP) {
		this.privateIP = privateIP;
	}
	public String getPublicPort() {
		return publicPort;
	}
	public void setPublicPort(String publicPort) {
		this.publicPort = publicPort;
	}
	public String getPrivatePort() {
		return privatePort;
	}
	public void setPrivatePort(String privatePort) {
		this.privatePort = privatePort;
	}
	
    
}
