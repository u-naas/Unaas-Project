package publicmw.pojo;

import java.util.Date;

public class CMCInfo {
    private String cmcId;
	private String activationCode;
	private String userId;
	private String password;
	private String policyXML;
	private String publicIp;
	private String privateIp;
	private String parentId;
	private Date regCheckDate;
	private boolean iot;
	private boolean com;
	private boolean info;
	private boolean ent;
	
	public CMCInfo(){
		
	}

	public Date getRegCheckDate() {
		return regCheckDate;
	}

	public void setRegCheckDate(Date regCheckDate) {
		this.regCheckDate = regCheckDate;
	}

	public String getActivationCode() {
		return activationCode;
	}

	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPolicyXML() {
		return policyXML;
	}

	public void setPolicyXML(String policyXML) {
		this.policyXML = policyXML;
	}

	public String getPublicIp() {
		return publicIp;
	}

	public void setPublicIp(String publicIp) {
		this.publicIp = publicIp;
	}

	public String getPrivateIp() {
		return privateIp;
	}

	public void setPrivateIp(String privateIp) {
		this.privateIp = privateIp;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public boolean isIot() {
		return iot;
	}

	public void setIot(boolean iot) {
		this.iot = iot;
	}

	public boolean isCom() {
		return com;
	}

	public void setCom(boolean com) {
		this.com = com;
	}

	public boolean isInfo() {
		return info;
	}

	public void setInfo(boolean info) {
		this.info = info;
	}

	public boolean isEnt() {
		return ent;
	}

	public void setEnt(boolean ent) {
		this.ent = ent;
	}

	public String getCmcId() {
		return cmcId;
	}

	public void setCmcId(String cmcId) {
		this.cmcId = cmcId;
	}
	
}
