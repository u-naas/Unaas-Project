package publicmw.pojo;

public class Iot {

	//Csso
	String pub;	
	public String getPub() {
		return pub;
	}
	public void setPub(String pub) {
		this.pub = pub;
	}
	public String getPriv() {
		return priv;
	}
	public void setPriv(String priv) {
		this.priv = priv;
	}
	String priv;
	
	//DeviceList
	String deviceids;
	
	public String getDeviceids() {
		return deviceids;
	}

	public void setDeviceids(String deviceids) {
		this.deviceids = deviceids;
	}
	
	//DeviceProfiles
	String deviceid;	
	String category;
	String devicetype;
	String modeldesc;
	String udn;
	String layoutGroup;
	String l1;
	String l2;
	
	public String getL1() {
		return l1;
	}
	public void setL1(String l1) {
		this.l1 = l1;
	}
	public String getL2() {
		return l2;
	}
	public void setL2(String l2) {
		this.l2 = l2;
	}
	
	
	public String getLayoutGroup() {
		return layoutGroup;
	}
	public void setLayoutGroup(String layoutGroup) {
		this.layoutGroup = layoutGroup;
	}
	public String getUdn() {
		return udn;
	}
	public void setUdn(String udn) {
		this.udn = udn;
	}
	public String getDeviceid() {
		return deviceid;
	}
	public void setDeviceid(String deviceid) {
		this.deviceid = deviceid;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getDevicetype() {
		return devicetype;
	}
	public void setDevicetype(String devicetype) {
		this.devicetype = devicetype;
	}
	public String getModeldesc() {
		return modeldesc;
	}
	public void setModeldesc(String modeldesc) {
		this.modeldesc = modeldesc;
	}
	
	//DeviceSA
	String id;	
	String productid;
	String servicetype;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProductid() {
		return productid;
	}
	public void setProductid(String productid) {
		this.productid = productid;
	}
	public String getServicetype() {
		return servicetype;
	}
	public void setServicetype(String servicetype) {
		this.servicetype = servicetype;
	}
	
	
	
	
	//PersonalInfoUser
	String displayname;	
	String uri;
	String imageurl;
	String gender;
	String country;
	
	public String getDisplayname() {
		return displayname;
	}
	public void setDisplayname(String displayname) {
		this.displayname = displayname;
	}
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getImageurl() {
		return imageurl;
	}
	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	
	
	
	//Template
	String templateId;
	
	public String getTemplateId() {
		return templateId;
	}

	public void setTemplateId(String templateId) {
		this.templateId = templateId;
	}
	
	
	
	//LoginDetails
	String custId;
	String uriloginDetails;
	
	public String getUriloginDetails() {
		return uriloginDetails;
	}
	public void setUriloginDetails(String uriloginDetails) {
		this.uriloginDetails = uriloginDetails;
	}
	public String getCustId() {
		return custId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
		
		
		
	}
	
	//Domain
		String iot;	
		//String info;
		String com;	
		
		String cssourl;
		
		
		public String getCssourl() {
			return cssourl;
		}
		public void setCssourl(String cssourl) {
			this.cssourl = cssourl;
		}
		
		public String getIot() {
			return iot;
		}
		public void setIot(String iot) {
			this.iot = iot;
		}
		/*public String getInfo() {
			return info;
		}
		public void setInfo(String info) {
			this.info = info;
		}
*/		public String getCom() {
			return com;
		}
		public void setCom(String com) {
			this.com = com;
		}
	
}
