package publicmw.pojo;

public class DeviceInfo {

	private String deviceId;
	private String deviceName;
	private String deviceCat;
	private String deviceType;
	private String deviceModelDesc;
	private String UDN;
	private String productId;
	private String serviceType;
	private String layoutGroup;
	private String l1;	
	private String l2;	
	private String deviceUuid;
	
	private String appid;
	
	
	/**
	 * @return the appid
	 */
	public String getAppid() {
		return appid;
	}
	/**
	 * @param appid the appid to set
	 */
	public void setAppid(String appid) {
		this.appid = appid;
	}
	/**
	 * @return the deviceUuid
	 */
	public String getDeviceUuid() {
		return deviceUuid;
	}
	/**
	 * @param deviceUuid the deviceUuid to set
	 */
	public void setDeviceUuid(String deviceUuid) {
		this.deviceUuid = deviceUuid;
	}
	public String getL1() {
		return l1;
	}
	public void setL1(String l1) {
		this.l1 = l1;
	}
	public String getL2() {
		return l2;
	}
	public void setL2(String l2) {
		this.l2 = l2;
	}
	
	public String getLayoutGroup() {
		return layoutGroup;
	}
	public void setLayoutGroup(String layoutGroup) {
		this.layoutGroup = layoutGroup;
	}
	
	//private String deviceId;
	private String pUri;
	/**
	 * @return the pUri
	 */
	public String getpUri() {
		return pUri;
	}
	/**
	 * @param pUri the pUri to set
	 */
	public void setpUri(String pUri) {
		this.pUri = pUri;
	}
	/**
	 * @return the sUri
	 */
	public String getsUri() {
		return sUri;
	}
	/**
	 * @param sUri the sUri to set
	 */
	public void setsUri(String sUri) {
		this.sUri = sUri;
	}
	private String sUri;
	
	/**
	 * @return the deviceId
	 */
	public String getDeviceId() {
		return deviceId;
	}
	/**
	 * @param deviceId the deviceId to set
	 */
	public void setDeviceId(String deviceId) {
		this.deviceId = deviceId;
	}
	/**
	 * @return the deviceName
	 */
	public String getDeviceName() {
		return deviceName;
	}
	/**
	 * @param deviceName the deviceName to set
	 */
	public void setDeviceName(String deviceName) {
		this.deviceName = deviceName;
	}
	/**
	 * @return the deviceCat
	 */
	public String getDeviceCat() {
		return deviceCat;
	}
	/**
	 * @param deviceCat the deviceCat to set
	 */
	public void setDeviceCat(String deviceCat) {
		this.deviceCat = deviceCat;
	}
	/**
	 * @return the deviceType
	 */
	public String getDeviceType() {
		return deviceType;
	}
	/**
	 * @param deviceType the deviceType to set
	 */
	public void setDeviceType(String deviceType) {
		this.deviceType = deviceType;
	}
	/**
	 * @return the deviceModelDesc
	 */
	public String getDeviceModelDesc() {
		return deviceModelDesc;
	}
	/**
	 * @param deviceModelDesc the deviceModelDesc to set
	 */
	public void setDeviceModelDesc(String deviceModelDesc) {
		this.deviceModelDesc = deviceModelDesc;
	}
	/**
	 * @return the uDN
	 */
	public String getUDN() {
		return UDN;
	}
	/**
	 * @param uDN the uDN to set
	 */
	public void setUDN(String uDN) {
		UDN = uDN;
	}
	/**
	 * @return the productId
	 */
	public String getProductId() {
		return productId;
	}
	/**
	 * @param productId the productId to set
	 */
	public void setProductId(String productId) {
		this.productId = productId;
	}
	/**
	 * @return the serviceType
	 */
	public String getServiceType() {
		return serviceType;
	}
	/**
	 * @param serviceType the serviceType to set
	 */
	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}
		
}
