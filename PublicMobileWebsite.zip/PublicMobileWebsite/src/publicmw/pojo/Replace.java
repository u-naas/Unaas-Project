package publicmw.pojo;

public class Replace {
	
	String displaynameIot;	
	String uriIot;
	String imageurlIot;
	String genderIot;
	String contryIot;
	String publicIot;
	String privateIot;	
	String deviceIdIot;	
	String devicenameIot;
	String categoryIot;
	String devicetypeIot;
	String modeldescriptionIot;
	String idIot;
	String productidIot;
	String servicetypeIot;
	
	String displaynameInfo;	
	String uriInfo;
	String imageurlInfo;
	String genderInfo;
	String countryInfo;
	String appidInfo;
	String publicurlInfo;
	String privateurlInfo;
	String serviceidInfo;
	String servicetypeInfo;
	String udn;
	
	public String getUdn() {
		return udn;
	}
	public void setUdn(String udn) {
		this.udn = udn;
	}
	public String getDisplaynameIot() {
		return displaynameIot;
	}
	public void setDisplaynameIot(String displaynameIot) {
		this.displaynameIot = displaynameIot;
	}
	public String getUriIot() {
		return uriIot;
	}
	public void setUriIot(String uriIot) {
		this.uriIot = uriIot;
	}
	public String getImageurlIot() {
		return imageurlIot;
	}
	public void setImageurlIot(String imageurlIot) {
		this.imageurlIot = imageurlIot;
	}
	public String getGenderIot() {
		return genderIot;
	}
	public void setGenderIot(String genderIot) {
		this.genderIot = genderIot;
	}
	public String getContryIot() {
		return contryIot;
	}
	public void setContryIot(String contryIot) {
		this.contryIot = contryIot;
	}
	public String getPublicIot() {
		return publicIot;
	}
	public void setPublicIot(String publicIot) {
		this.publicIot = publicIot;
	}
	public String getPrivateIot() {
		return privateIot;
	}
	public void setPrivateIot(String privateIot) {
		this.privateIot = privateIot;
	}
	
	
	public String getDeviceIdIot() {
		return deviceIdIot;
	}
	public void setDeviceIdIot(String deviceIdIot) {
		this.deviceIdIot = deviceIdIot;
	}
	public String getDevicenameIot() {
		return devicenameIot;
	}
	public void setDevicenameIot(String devicenameIot) {
		this.devicenameIot = devicenameIot;
	}
	public String getCategoryIot() {
		return categoryIot;
	}
	public void setCategoryIot(String categoryIot) {
		this.categoryIot = categoryIot;
	}
	public String getDevicetypeIot() {
		return devicetypeIot;
	}
	public void setDevicetypeIot(String devicetypeIot) {
		this.devicetypeIot = devicetypeIot;
	}
	public String getModeldescriptionIot() {
		return modeldescriptionIot;
	}
	public void setModeldescriptionIot(String modeldescriptionIot) {
		this.modeldescriptionIot = modeldescriptionIot;
	}
	public String getIdIot() {
		return idIot;
	}
	public void setIdIot(String idIot) {
		this.idIot = idIot;
	}
	public String getProductidIot() {
		return productidIot;
	}
	public void setProductidIot(String productidIot) {
		this.productidIot = productidIot;
	}
	public String getServicetypeIot() {
		return servicetypeIot;
	}
	public void setServicetypeIot(String servicetypeIot) {
		this.servicetypeIot = servicetypeIot;
	}
	
	
	public String getDisplaynameInfo() {
		return displaynameInfo;
	}
	public void setDisplaynameInfo(String displaynameInfo) {
		this.displaynameInfo = displaynameInfo;
	}
	public String getUriInfo() {
		return uriInfo;
	}
	public void setUriInfo(String uriInfo) {
		this.uriInfo = uriInfo;
	}
	public String getImageurlInfo() {
		return imageurlInfo;
	}
	public void setImageurlInfo(String imageurlInfo) {
		this.imageurlInfo = imageurlInfo;
	}
	public String getGenderInfo() {
		return genderInfo;
	}
	public void setGenderInfo(String genderInfo) {
		this.genderInfo = genderInfo;
	}
	public String getCountryInfo() {
		return countryInfo;
	}
	public void setCountryInfo(String countryInfo) {
		this.countryInfo = countryInfo;
	}
	public String getAppidInfo() {
		return appidInfo;
	}
	public void setAppidInfo(String appidInfo) {
		this.appidInfo = appidInfo;
	}
	public String getPublicurlInfo() {
		return publicurlInfo;
	}
	public void setPublicurlInfo(String publicurlInfo) {
		this.publicurlInfo = publicurlInfo;
	}
	public String getPrivateurlInfo() {
		return privateurlInfo;
	}
	public void setPrivateurlInfo(String privateurlInfo) {
		this.privateurlInfo = privateurlInfo;
	}
	public String getServiceidInfo() {
		return serviceidInfo;
	}
	public void setServiceidInfo(String serviceidInfo) {
		this.serviceidInfo = serviceidInfo;
	}
	public String getServicetypeInfo() {
		return servicetypeInfo;
	}
	public void setServicetypeInfo(String servicetypeInfo) {
		this.servicetypeInfo = servicetypeInfo;
	}
}
