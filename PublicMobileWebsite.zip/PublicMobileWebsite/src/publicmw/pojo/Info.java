package publicmw.pojo;

public class Info {

	String selfurl;
	String ibookurl;
	String cssourl;

	String displayname;
	String uri;
	String imageurl;
	String gender;
	String country;
	
	String pub;
	String pri;	
	
	String serviceid;
	String servicetype;
	
	String info;
	
	
	
	public String getInfo() {
		return info;
	}
	public void setInfo(String info) {
		this.info = info;
	}

	public String getServicetype() {
		return servicetype;
	}

	public void setServicetype(String servicetype) {
		this.servicetype = servicetype;
	}

	public String getServiceid() {
		return serviceid;
	}

	public void setServiceid(String serviceid) {
		this.serviceid = serviceid;
	}

	public String getSelfurl() {
		return selfurl;
	}

	public void setSelfurl(String selfurl) {
		this.selfurl = selfurl;
	}
	
	
	public String getIbookurl() {
		return ibookurl;
	}

	public void setIbookurl(String ibookurl) {
		this.ibookurl = ibookurl;
	}	
	

	public String getCssourl() {
		return cssourl;
	}

	public void setCssourl(String cssourl) {
		this.cssourl = cssourl;
	}

	
	
	public String getDisplayname() {
		return displayname;
	}

	public void setDisplayname(String displayname) {
		this.displayname = displayname;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getImageurl() {
		return imageurl;
	}

	public void setImageurl(String imageurl) {
		this.imageurl = imageurl;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}
	
	
	public String getPub() {
		return pub;
	}

	public void setPub(String pub) {
		this.pub = pub;
	}

	public String getPri() {
		return pri;
	}

	public void setPri(String pri) {
		this.pri = pri;
	}
	
}
