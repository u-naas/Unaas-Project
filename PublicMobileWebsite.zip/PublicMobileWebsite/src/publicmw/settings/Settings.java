package publicmw.settings;


public class Settings {

	public static String web_content_path = "";	
	public static String BACKEND_GATEWAY_ADDRESS;	
	public static String ACTIVATION_SERVER_ADDRESS;	
	public static String MOBILE_WEBSITE_ADDRESS="http://192.168.1.103:8080/PublicMobileWebsite/";	
	public static String SELF_URL;
	public static String SELF_URL1;
	public static boolean useSSL;
	public static String SW;
	public static int PUBLISH_TIMEOUT_IN_MINUTES=600;
	public static int REGISTER_TIMEOUT_IN_MINUTES=5;
	public static String MAIL_HOST;
	public static String MAILID;
	public static String MAIL_PWD;
	
	public static String CLOUD_ENABLED;
	public static String GenPath;
	public static String LOGIN_SERVER;
	public static String HTTPS_PORT;
	public static String BACKEND_DATABASES_IP;
	public static String Login_Server_IP;
	public static String SELF_IP;
	public static String KeyCloak_ADDRESS;
	
	
}
