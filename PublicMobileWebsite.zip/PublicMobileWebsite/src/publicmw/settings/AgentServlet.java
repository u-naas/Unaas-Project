package publicmw.settings;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import publicmw.settings.Settings;


/* Servlet implementation class AgentServlet */
@WebServlet("/AgentServlet")
public class AgentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;



	/* @see HttpServlet#HttpServlet() */
	public AgentServlet() {
		super();       
	}

	public void init(ServletConfig config) throws ServletException{
		try{
			Settings.web_content_path = config.getServletContext().getRealPath("/");
			System.out.println("web_content_path = "+ Settings.web_content_path);

			String newpath = Settings.web_content_path + "/../..";
			System.out.println(" After updating web_content_fath : "+ newpath );
			newpath = newpath+"/cccpgwConfig.properties";
			System.out.println("config file path : \n"+newpath);
			Properties prop = new Properties();		   			  

			prop.load(new FileInputStream(newpath));
			System.out.println("-------------------prop loaded-------------------");
			Settings.BACKEND_GATEWAY_ADDRESS="http://"+prop.getProperty("BACKEND-Gateway_IPAdd")+":"+prop.getProperty("BACKEND-Gateway_port");
			Settings.BACKEND_DATABASES_IP=prop.getProperty("BACKEND-Gateway_IPAdd");
			
			Settings.ACTIVATION_SERVER_ADDRESS="http://"+prop.getProperty("ACTIVATIONSERVER_ip")+":"+prop.getProperty("ACTIVATIONSERVER_port");			
			Settings.KeyCloak_ADDRESS="http://"+prop.getProperty("KeyCloak_Ip")+":"+prop.getProperty("KeyCloak_Port");			
			Settings.SELF_URL="http://"+prop.getProperty("Self_IP")+":"+prop.getProperty("Self_port");
			Settings.LOGIN_SERVER=prop.getProperty("Self_IP")+":"+prop.getProperty("Self_port");
			Settings.Login_Server_IP=prop.getProperty("Self_IP");
			Settings.SELF_URL1="https://"+prop.getProperty("Self_IP")+":"+prop.getProperty("Self_https_port");
			Settings.useSSL=Boolean.parseBoolean(prop.getProperty("Use_SSL"));
			Settings.MOBILE_WEBSITE_ADDRESS="http://"+prop.getProperty("MOBILEWEBSITE_Address")+":"+prop.getProperty("MOBILEWEBSITE_Port")+"/PublicMobileWebsite/";
			

			Settings.SW="http://"+prop.getProperty("SWIP")+":"+prop.getProperty("SWPORT");
			Settings.MAIL_HOST=prop.getProperty("MailHost");
			Settings.MAILID=prop.getProperty("SenderMailId");
			Settings.MAIL_PWD=prop.getProperty("SenderMailPassword");
			Settings.REGISTER_TIMEOUT_IN_MINUTES=Integer.parseInt(prop.getProperty("Register_timeout"));
			Settings.PUBLISH_TIMEOUT_IN_MINUTES=Integer.parseInt(prop.getProperty("Publish_timeout"));
			
			Settings.GenPath= prop.getProperty("GenDoc");
			Settings.CLOUD_ENABLED= prop.getProperty("CLOUD_ENABLED");
			Settings.HTTPS_PORT=prop.getProperty("HTTPS_PORT");
			Settings.SELF_IP= prop.getProperty("Self_IP");
			
			System.out.println("Settings.BACKEND_GATEWAY_ADDRESS : "+Settings.BACKEND_GATEWAY_ADDRESS);			
			System.out.println("AgentServlet.init() : Setting initialized...");
		}catch(Exception e){
			e.printStackTrace();
		}
	}



	/* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response) */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		pw.println("<h1>In Agent Servlet Get Method</h1>");
		pw.close();
	}



	/* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response) */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		System.out.println("Settings Updated");
	}

}
