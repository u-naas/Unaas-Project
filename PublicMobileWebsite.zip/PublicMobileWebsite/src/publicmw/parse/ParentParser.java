package publicmw.parse;

import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import publicmw.utils.Utils;
import publicmw.pojo.ResourceBean;


public class ParentParser {


	public static final String CONST_RESOURCELIST="global-resource-list";
	public static final String CONST_CATEGORY="category";
	Element element = null;
	Document doc = null;


	public ArrayList<ResourceBean> parseResourceList(String xml){
		System.out.println("Inside the ResourceList ---------1 -------- ");
		ArrayList<ResourceBean> resourcelists = new ArrayList<ResourceBean>();		
		try{		 
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			doc = db.parse(is);
		}catch (Exception e) {
			e.printStackTrace();		
		}
		Node rootNode = doc.getElementsByTagName(CONST_RESOURCELIST).item(0);		
		Node[] noofchild = Utils.getChildNodes(rootNode); 
		if(noofchild!= null && noofchild.length>0){
			for(int i=0; i<noofchild.length; i++){			
				ResourceBean rlist = this.parseResourceListnew(noofchild[i]);			
				resourcelists.add(rlist);
			}
			System.out.println("ResourceList ============>"+resourcelists);
			return resourcelists;

		}
		return null;
	}

	public ResourceBean parseResourceListnew(Node dlistNode){
		System.out.println("Inside the ResourceList ---------2-------- ");
		ResourceBean resourceParseBean = new ResourceBean();
		if(null != dlistNode && dlistNode.getNodeType()==Node.ELEMENT_NODE){
			Element element = (Element)dlistNode;			
			resourceParseBean.setCategory(element.getAttribute("category"));

			Node[] noofres = Utils.getChildNodes(dlistNode);

			if(noofres!= null && noofres.length>0){
				for(int i=0; i<noofres.length; i++){				
					ResourceBean dev = this.parseResourcenew(noofres[i]);
					resourceParseBean.resourceBeans.add(dev);
				}
				return resourceParseBean;
			}
		}
		return resourceParseBean;
	}

	public ResourceBean parseResourcenew(Node dNode){
		System.out.println("Inside the ResourceList ---------3-------- ");
		ResourceBean resourceBean = new ResourceBean();
		if(null != dNode && dNode.getNodeType()==Node.ELEMENT_NODE){
			Element develement = (Element)dNode;
			resourceBean.setResourceid(develement.getAttribute("id"));
			System.out.println("Resource Id ======>"+resourceBean.getResourceid());
		}
		return resourceBean;
	}	

	public static final String CONST_PARENT="parent";
	public static final String CONST_ID="id";


	public ResourceBean parseoperatorId(String xml){
		System.out.println("inside the parseoperatorId"+xml);
		ResourceBean opIdBean = new ResourceBean();
		Document doc = Utils.getDocument(xml);	
		Element modelElement = null;	
		Node udnNode = doc.getElementsByTagName(CONST_PARENT).item(0);
		if(udnNode.getNodeType() == Node.ELEMENT_NODE) {
			modelElement = (Element) udnNode;
			opIdBean.setOpid(Utils.getChildTagValue(CONST_ID,modelElement));			  
		}
		return opIdBean;
	}

	public static final String CONST_ROLENAME="rolename";
	public static final String CONST_ROLE="role";

	public ResourceBean parseRoleId(String xml){
		System.out.println("inside the parseRoleId"+xml);
		ResourceBean roleidBean = new ResourceBean();
		Document doc = Utils.getDocument(xml);	
		Element modelElement = null;	
		Node udnNode = doc.getElementsByTagName(CONST_ROLENAME).item(0);
		if(udnNode.getNodeType() == Node.ELEMENT_NODE) {
			modelElement = (Element) udnNode;
			roleidBean.setRolename(Utils.getChildTagValue(CONST_ROLE,modelElement));			  
		}
		return roleidBean;
	}	
	

	public static final String CONST_ROLES="role";
	public static final String CONST_RESOURCES="resources";		
	public static final String CONST_LINKXML="linkxml";
	public static final String CONST_SOLID="solid";		
	public static final String CONST_LINK="link";
	
	public ArrayList<ResourceBean>  parseSolutionIdAndLink(String xml){
		
		ArrayList<ResourceBean> roleidBean = new ArrayList<ResourceBean>();
		ResourceBean resourceParseBean = new ResourceBean();
		try{
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			Document doc = db.parse(is);

			Node rootNodeIndex=doc.getElementsByTagName(CONST_ROLES).item(0);
			if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){
				Element rootElementIndex=(Element)rootNodeIndex;
				NodeList deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_RESOURCES);			
				if(null!=deviceListNodeEntry && deviceListNodeEntry.getLength()!=0){
					for(int j=0;j<deviceListNodeEntry.getLength();j++){
						Node deviceIdNodes=deviceListNodeEntry.item(j);	
						Element rootElement=(Element)deviceIdNodes;		    			    	
						if(rootElement!=null){
							Element deviceListElement=(Element)rootElement;
							NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_LINKXML);					    		
							if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){			    		
								for(int i=0;i<deviceIdNodeList.getLength();i++){

									Node deviceIdNode=deviceIdNodeList.item(i);			    			
									Element deviceIdElement=(Element)deviceIdNode;
									//resourceParseBean = new ResourceBean();
									
									resourceParseBean.setSolution(Utils.getChildTagValue(CONST_SOLID,deviceIdElement));	
									System.out.println("SolutionId ##### ====>"+resourceParseBean.getSolution());
									resourceParseBean.setLink(Utils.getChildTagValue(CONST_LINK,deviceIdElement));	
									System.out.println("Link ##### ====>"+resourceParseBean.getLink());	
									
									roleidBean.add(resourceParseBean);
									
									
								}							
								
							}
							
						}
						
					}
					return roleidBean;	
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
}
