package publicmw.parse;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import publicmw.pojo.DeviceInfo;
import publicmw.pojo.Iot;
import publicmw.utils.Utils;

public class IotDomain {
	//Template Info
	public static final String CONST_TEMPLATELIST="templateList";
	public static final String CONST_TEMPLATE="template";
	public static final String CONST_TEMPLATEID="templateId";
	private static final String CONST_INDEX="edb-index";	
	private static final String CONST_ROOT="device-lists";
	private static final String CONST_DEVICE_LIST="device-list";
	private static final String CONST_DEVICEID="deviceid";	
	private static final String CONST_PROFILEURI="DeviceProfileUri";
	public static final String CONST_DEVICESERVICEACTION="deviceserviceactions";
	public static final String CONST_ACTION="service-action";
	public static final String CONST_URI="uri";
	public static final String CONST_USEROPINFO="userOpInfo";
	public static final String CONST_CUSTID="custId";
	public static final String CONST_IOT="iot";
	public static final String CONST_INFO="info";
	private static final String CONST_EDB="edb-index";
	private static final String CONST_ENTRY="entry";
	private static final String CONST_HOTELDOC="hotelemp-doc";	
	private static final String CONST_DeviceServiceActionURI="DeviceServiceActionUri";
	private static final String CONST_CSSOURL="cssoUrl";
	private static final String CONST_DEVICEBOOK="device-book";
	
	public Iot parseTemplateInfo(String xml){		
		Iot dInfoBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_TEMPLATELIST).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;	
			Node templateNode=deviceElement.getElementsByTagName(CONST_TEMPLATE).item(0);
			Element deviceIdElement=(Element)templateNode;
			dInfoBean.setTemplateId(Utils.getChildTagValue(CONST_TEMPLATEID,deviceIdElement));			   

		}			 

		return dInfoBean;
	}
	
	public Iot parseServiceActions(String xml){		
		Iot loginBean = new Iot();
		Document doc = Utils.getDocument(xml);
		System.out.println("parseServiceActions ############ "+xml);
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_DEVICESERVICEACTION).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;	
			Node templateNode=deviceElement.getElementsByTagName(CONST_ACTION).item(0);
			Element deviceIdElement=(Element)templateNode;
			loginBean.setUriloginDetails(Utils.getChildTagValue(CONST_URI,deviceIdElement));
		}			 

		return loginBean;
	}




	

	public Iot parseLoginRquest(String xml){		
		Iot loginBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_USEROPINFO).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;
			loginBean.setCustId(Utils.getChildTagValue(CONST_CUSTID,deviceElement));			  
		}			 

		return loginBean;
	}


	
	
	public Iot parseMasterIndexIot(String xml){		
		Iot domainBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_USEROPINFO).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;			
			domainBean.setIot(Utils.getChildTagValue(CONST_IOT,deviceElement));	
		}	
		return domainBean;
	}
	
		
	public String[] parseHotelempUri(String xml){
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);
				Node rootNode=doc.getElementsByTagName(CONST_EDB).item(0);
			    if(null!=rootNode && rootNode.getNodeType()==Node.ELEMENT_NODE){
			    	Element rootElement=(Element)rootNode;
			    	Node entryListNode=rootElement.getElementsByTagName(CONST_ENTRY).item(0);
			    	if(entryListNode!=null){
			    		Element entryListElement=(Element)entryListNode;
			    		NodeList hotelDocdNodeList=entryListElement.getElementsByTagName(CONST_HOTELDOC);
			    		String[] hotelDocUris=new String[hotelDocdNodeList.getLength()];
			    		for(int i=0;i<hotelDocdNodeList.getLength();i++){
			    			Node deviceIdNode=hotelDocdNodeList.item(i);
			    			Element hotelIdElement=(Element)deviceIdNode;
			    			hotelDocUris[i]=hotelIdElement.getAttribute("uri");
			    			//System.out.println(" parseHotelempUri ##################"+hotelDocUris[i]);
			    		}
			    		return hotelDocUris;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}	

	
	
	public String[] parseDeviceBookUri(String xml){
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);
				Node rootNode=doc.getElementsByTagName(CONST_EDB).item(0);
			    if(null!=rootNode && rootNode.getNodeType()==Node.ELEMENT_NODE){
			    	Element rootElement=(Element)rootNode;
			    	Node entryListNode=rootElement.getElementsByTagName(CONST_ENTRY).item(0);
			    	if(entryListNode!=null){
			    		Element entryListElement=(Element)entryListNode;
			    		NodeList deviceBookNodeList=entryListElement.getElementsByTagName(CONST_DEVICEBOOK);
			    		String[] deviceBookUris=new String[deviceBookNodeList.getLength()];
			    		for(int i=0;i<deviceBookNodeList.getLength();i++){
			    			Node deviceBookNode=deviceBookNodeList.item(i);
			    			Element deviceBookElement=(Element)deviceBookNode;
			    			deviceBookUris[i]=deviceBookElement.getAttribute("uri");
			    			//System.out.println(" parseDeviceBookUri ##################"+deviceBookUris[i]);
			    		}
			    		return deviceBookUris;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	public Iot parseCssoUrl(String xml){
		Iot domainBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_EDB).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;	
			Node templateNode=deviceElement.getElementsByTagName(CONST_ENTRY).item(0);
			Element deviceIdElement=(Element)templateNode;
			domainBean.setCssourl(Utils.getChildTagValue(CONST_CSSOURL,deviceIdElement));	
		}			 

		return domainBean;
	}
	
	
	public List<DeviceInfo> parseDeviceProfileUriList_new(String xml){		
		//Map<String, String> deviceMap = new HashMap<String, String>();
		List<DeviceInfo> deviceInfoList = new ArrayList<DeviceInfo>();
		DeviceInfo deviceInfo = null;
	try{
		    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			Document doc = db.parse(is);
			
			Node rootNodeIndex=doc.getElementsByTagName(CONST_INDEX).item(0);
			 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){
				 Element rootElementIndex=(Element)rootNodeIndex;
				 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_ENTRY).item(0);
		    	
			deviceListNodeEntry=doc.getElementsByTagName(CONST_ROOT).item(0);
		    if(null!=deviceListNodeEntry && deviceListNodeEntry.getNodeType()==Node.ELEMENT_NODE){
		    	Element rootElement=(Element)deviceListNodeEntry;
		    	Node deviceListNode=rootElement.getElementsByTagName(CONST_DEVICE_LIST).item(0);			    	
		    	 if(deviceListNode!=null){
			    		Element deviceListElement=(Element)deviceListNode;
			    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEID);					    		
			    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){
			    		String pUri = null;
			    		String sUri=null;
			    		for(int i=0;i<deviceIdNodeList.getLength();i++){	
			    			deviceInfo = new DeviceInfo();
			    			
			       			Node deviceIdNode=deviceIdNodeList.item(i);
			    			
			       			Element deviceIdElement=(Element)deviceIdNode;				       			
			       			deviceInfo.setDeviceId(deviceIdElement.getAttribute("uri"));
			    			 NodeList devplist = deviceIdElement.getElementsByTagName(CONST_PROFILEURI);
			    			 if(null != devplist && devplist.getLength()>0)
			    			 {
			    				Element delement = (Element)devplist.item(0);
			    				if(null != delement)
			    				{
			    					NodeList textFNList = delement.getChildNodes();			    					
			    					deviceInfo.setpUri(textFNList.item(0).getNodeValue());
			    					//System.out.println("------------getpUri---------------------"+deviceInfo.getpUri()); 					
			    					
			    				}
			    			 }			    							    			 
			    			 NodeList devSlist = deviceIdElement.getElementsByTagName(CONST_DeviceServiceActionURI);
			    			 if(null != devSlist && devSlist.getLength()>0)
			    			 {
			    				Element delement = (Element)devSlist.item(0);
			    				if(null != delement)
			    				{
			    					NodeList textFNList = delement.getChildNodes();
			    					//sUri= textFNList.item(0).getNodeValue();
			    					deviceInfo.setsUri(textFNList.item(0).getNodeValue());
			    					//System.out.println("-----------------------------getsUri---------------"+deviceInfo.getsUri());
			    				}
			    			 }
			    			
			    			deviceInfoList.add(deviceInfo);
			    		}		    		
		    		return deviceInfoList;
		    		}
		    		else 
		    		   return null;
		    	}
		    }}
	}catch(Exception e){
		e.printStackTrace();
	}
	return null;
}	
	
	
	public String[] parseDeviceProfileUriList(String xml){
			
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_INDEX).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_ENTRY).item(0);
			    	
				deviceListNodeEntry=doc.getElementsByTagName(CONST_ROOT).item(0);
			    if(null!=deviceListNodeEntry && deviceListNodeEntry.getNodeType()==Node.ELEMENT_NODE){
			    	Element rootElement=(Element)deviceListNodeEntry;
			    	Node deviceListNode=rootElement.getElementsByTagName(CONST_DEVICE_LIST).item(0);			    	
			    	 if(deviceListNode!=null){
				    		Element deviceListElement=(Element)deviceListNode;
				    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEID);	
				    		
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){
				    		String[] uri=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_PROFILEURI);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					uri[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }
				    			 
				    			//System.out.println(" DeviceProfileUri ##################"+uri[i]);
				    			
				    		}		    		
			    		return uri;
			    		}
			    		else 
			    		   return null;
			    	}
			    }}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}	
	
	
	
	public String[] parseDeviceServiceActionUriList(String xml){
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_INDEX).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_ENTRY).item(0);
			    	
				deviceListNodeEntry=doc.getElementsByTagName(CONST_ROOT).item(0);
			    if(null!=deviceListNodeEntry && deviceListNodeEntry.getNodeType()==Node.ELEMENT_NODE){
			    	Element rootElement=(Element)deviceListNodeEntry;
			    	Node deviceListNode=rootElement.getElementsByTagName(CONST_DEVICE_LIST).item(0);			    	
			    	 if(deviceListNode!=null){
				    		Element deviceListElement=(Element)deviceListNode;
				    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEID);	
				    		
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){
				    		String[] uri=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_DeviceServiceActionURI);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					uri[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }
				    			 
				    			//System.out.println("DeviceServiceActionURI ##################"+uri[i]);
				    			
				    		}		    		
			    		return uri;
			    		}
			    		else 
			    		   return null;
			    	}
			    }}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	
	
	
	
	//PersonalInfo
	public static final String CONST_HOTELPROFILE="hotelemp-profile";
	public static final String CONST_DISPLAYNAME="display-name";	
	public static final String CONST_MANAGER="manager";
	public static final String CONST_URIPINFO="uri";	
	public static final String CONST_IMAGE="image";
	public static final String CONST_IMAGEURL="image_url";	
	public static final String CONST_HOTELADD="hoteladdress";
	public static final String CONST_COUNTRY="country";	
	public static final String CONST_GENDER="gender";
	
	public Iot parseDisplayName(String xml){		
		Iot PersonalInfoUserBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_HOTELPROFILE).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;
			PersonalInfoUserBean.setDisplayname(Utils.getChildTagValue(CONST_DISPLAYNAME,hotelElement));			  
		}
		return PersonalInfoUserBean;
	}	
	
	public Iot parseUri(String xml){		
		Iot PersonalInfoUserBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_HOTELPROFILE).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_MANAGER).item(0);
			Element uriElement=(Element)managerNode;
			PersonalInfoUserBean.setUri(Utils.getChildTagValue(CONST_URIPINFO,uriElement));			  
		}
		return PersonalInfoUserBean;
	}	
	
	
	public Iot parseImageUrl(String xml){		
		Iot PersonalInfoUserBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_HOTELPROFILE).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node imageNode=hotelElement.getElementsByTagName(CONST_IMAGE).item(0);
			Element imageElement=(Element)imageNode;
			PersonalInfoUserBean.setImageurl(Utils.getChildTagValue(CONST_IMAGEURL,imageElement));			  
		}
		return PersonalInfoUserBean;
	}	
	
	
	public Iot parseGender(String xml){		
		Iot PersonalInfoUserBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_HOTELPROFILE).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;
			PersonalInfoUserBean.setGender(Utils.getChildTagValue(CONST_GENDER,hotelElement));			  
		}
		return PersonalInfoUserBean;
	}

	
	public Iot parseCountry(String xml){		
		Iot PersonalInfoUserBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_HOTELPROFILE).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node hotelAddNode=hotelElement.getElementsByTagName(CONST_HOTELADD).item(0);
			Element contryElement=(Element)hotelAddNode;
			PersonalInfoUserBean.setCountry(Utils.getChildTagValue(CONST_COUNTRY,contryElement));			  
		}
		return PersonalInfoUserBean;
	}
	
	
	
	
	//DeviceServiceAction
	public static final String CONST_SCPD="scpd";
	public static final String CONST_DEVICE="device";
	public static final String CONST_DEVICEIDDSA="id";	
	public static final String CONST_PRODUCTID="productId";	
	public static final String CONST_SERVICETYPE="serviceType";
	public Iot parseId(String xml){		
		Iot saBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_SCPD).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;	
			Node templateNode=deviceElement.getElementsByTagName(CONST_DEVICE).item(0);
			Element deviceIdElement=(Element)templateNode;
			saBean.setId(Utils.getChildTagValue(CONST_DEVICEIDDSA,deviceIdElement));			   

		}			 
		return saBean;
	}
	
	public Iot parseProdectId(String xml){		
		Iot saBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element categoryElement = null;	
		Node categoryNode = doc.getElementsByTagName(CONST_SCPD).item(0);
		if(categoryNode.getNodeType() == Node.ELEMENT_NODE) {
			categoryElement = (Element) categoryNode;
			saBean.setProductid(Utils.getChildTagValue(CONST_PRODUCTID,categoryElement));			  
		}
		return saBean;
	}
	
	
	public Iot parseServiceType(String xml){		
		Iot saBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node devicetypedNode = doc.getElementsByTagName(CONST_SCPD).item(0);
		if(devicetypedNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) devicetypedNode;
			saBean.setServicetype(Utils.getChildTagValue(CONST_SERVICETYPE,deviceElement));			  
		}
		return saBean;
	}	
	
	
	//DeviceProfile
	public static final String CONST_DEVICEP="device";	
	public static final String CONST_DEVICEIDP="deviceid";	
	public static final String CONST_CATEGORY="category";	
	public static final String CONST_DEVICETYPE="deviceType";
	//public static final String CONST_MODELDESC="modelDescription";
	public static final String CONST_MODELDESC="protocol";
	public static final String CONST_UDN="UDN";
	public Iot parseDeviceId(String xml){	
		//System.out.println("IotDomain.parseDeviceId()"+xml);
		Iot deviceProfileBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceIdNode = doc.getElementsByTagName(CONST_DEVICEP).item(0);
		if(deviceIdNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceIdNode;
			deviceProfileBean.setDeviceid(Utils.getChildTagValue(CONST_DEVICEIDP,deviceElement));			  
		}
		return deviceProfileBean;
	}
	
	public Iot parseCategory(String xml){
		//System.out.println("IotDomain.parseCategory()"+xml);
		Iot deviceProfileBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element categoryElement = null;	
		Node categoryNode = doc.getElementsByTagName(CONST_DEVICEP).item(0);
		if(categoryNode.getNodeType() == Node.ELEMENT_NODE) {
			categoryElement = (Element) categoryNode;
			deviceProfileBean.setCategory(Utils.getChildTagValue(CONST_CATEGORY,categoryElement));			  
		}
		return deviceProfileBean;
	}
	
	
	public Iot parseDeviceType(String xml){	
		//System.out.println("IotDomain.parseDeviceType()"+xml);
		Iot deviceProfileBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node devicetypedNode = doc.getElementsByTagName(CONST_DEVICEP).item(0);
		if(devicetypedNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) devicetypedNode;
			deviceProfileBean.setDevicetype(Utils.getChildTagValue(CONST_DEVICETYPE,deviceElement));			  
		}
		return deviceProfileBean;
	}
	
	public Iot parseModelDesc(String xml){	
		//System.out.println("IotDomain.parseModelDesc()"+xml);
		Iot deviceProfileBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element modelElement = null;	
		Node modelDsceNode = doc.getElementsByTagName(CONST_DEVICEP).item(0);
		if(modelDsceNode.getNodeType() == Node.ELEMENT_NODE) {
			modelElement = (Element) modelDsceNode;
			deviceProfileBean.setModeldesc(Utils.getChildTagValue(CONST_MODELDESC,modelElement));			  
		}
		return deviceProfileBean;
	}
	
	
	
	public Iot parseUdn(String xml){
		//System.out.println("IotDomain.parseUdn()"+xml);
		Iot deviceProfileBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element modelElement = null;	
		Node udnNode = doc.getElementsByTagName(CONST_DEVICEP).item(0);
		if(udnNode.getNodeType() == Node.ELEMENT_NODE) {
			modelElement = (Element) udnNode;
			deviceProfileBean.setUdn(Utils.getChildTagValue(CONST_UDN,modelElement));			  
		}
		return deviceProfileBean;
	}
	
	
	public static final String CONST_LAYOUTGRP="layoutGrp";
	public static final String CONST_L1="l1";
	public static final String CONST_L2="l2";
	public Iot parseL1(String xml){		
		Iot deviceProfileBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element modelElement = null;	
		Node udnNode = doc.getElementsByTagName(CONST_DEVICEP).item(0);
		if(udnNode.getNodeType() == Node.ELEMENT_NODE) {
			modelElement = (Element) udnNode;
			Node lGNode=modelElement.getElementsByTagName(CONST_LAYOUTGRP).item(0);
			Element l1Element=(Element)lGNode;
			deviceProfileBean.setL1(Utils.getChildTagValue(CONST_L1,l1Element));		
		}
		return deviceProfileBean;
	}	
	
	public Iot parseL2(String xml){		
		Iot deviceProfileBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element modelElement = null;	
		Node udnNode = doc.getElementsByTagName(CONST_DEVICEP).item(0);
		if(udnNode.getNodeType() == Node.ELEMENT_NODE) {
			modelElement = (Element) udnNode;
			Node lGNode = modelElement.getElementsByTagName(CONST_LAYOUTGRP).item(0);
			Element l2Element=(Element)lGNode;
			deviceProfileBean.setL2(Utils.getChildTagValue(CONST_L2,l2Element));			  
		}
		return deviceProfileBean;
	}
	
	
	public static final String CONST_DEVICEs="device";
	public static final String CONST_LAYOUT_GRP="layoutGrp";
	
	
	//DeviceListParser
	private static final String CONST_ROOTD="device-lists";
	private static final String CONST_DEVICE_LISTS="device-list";
	private static final String CONST_DEVICEIDs="deviceid";	
	public String[] parseDeviceList(String xml){
		//System.out.println("IotDomain.parseDeviceList()"+xml);
		Iot dl = new Iot();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);
				Node rootNode=doc.getElementsByTagName(CONST_ROOTD).item(0);
			    if(null!=rootNode && rootNode.getNodeType()==Node.ELEMENT_NODE){
			    	Element rootElement=(Element)rootNode;
			    	Node deviceListNode=rootElement.getElementsByTagName(CONST_DEVICE_LISTS).item(0);
			    	if(deviceListNode!=null){
			    		Element deviceListElement=(Element)deviceListNode;
			    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEIDs);
			    		String[] deviceIds=new String[deviceIdNodeList.getLength()];
			    		for(int i=0;i<deviceIdNodeList.getLength();i++){
			    			Node deviceIdNode=deviceIdNodeList.item(i);
			    			Element deviceIdElement=(Element)deviceIdNode;
			    			deviceIds[i]=deviceIdElement.getAttribute("uri");
			    			dl.setDeviceids(deviceIds[i]);
			    			//System.out.println("Device List ############# ::"+dl.getDeviceids());
			    		}
			    		return deviceIds;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	
	
	
	//CssoUrl
	public static final String CONST_SCPDCSSO="scpd";
	public static final String CONST_CONTROLURL="controlUrl";	
	public static final String CONST_PUBLIC="public";
	public static final String CONST_PRIVATE="private";
	public Iot parsePublic(String xml){	
		//System.out.println("IotDomain.parsePublic()"+xml);
		Iot CssoBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_SCPDCSSO).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_CONTROLURL).item(0);
			Element uriElement=(Element)managerNode;
			CssoBean.setPub(Utils.getChildTagValue(CONST_PUBLIC,uriElement));			  
		}
		return CssoBean;
	}	
	
	
	public Iot parsePrivate(String xml){		
		//System.out.println("IotDomain.parsePrivate()"+xml);
		Iot CssoBean = new Iot();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_SCPDCSSO).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_CONTROLURL).item(0);
			Element uriElement=(Element)managerNode;
			CssoBean.setPriv(Utils.getChildTagValue(CONST_PRIVATE,uriElement));			  
		}
		return CssoBean;
	}	

	
	
}
