package publicmw.parse;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;


import publicmw.pojo.User;
import publicmw.utils.Utils;

public class customer {

	public static final String CONST_USEROPINFO="userOpInfo";
	public static final String CONST_CUSTID="custId";
	public static final String CONST_ACTIVATIONCODE="activationCode";
	
	
	
	public User parseLoginRquest(String xml){		
		User loginBean = new User();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_USEROPINFO).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;
			//loginBean.setCustId(Utils.getChildTagValue(CONST_CUSTID,deviceElement));
			loginBean.setUserId(Utils.getChildTagValue(CONST_CUSTID,deviceElement));
		}	
		return loginBean;
	}	
	
	
	public static final String CONST_USERTYPE="userType";
	
	public User parseUserType(String xml){		
		User loginBean = new User();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_USEROPINFO).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;			
			loginBean.setUserType(Utils.getChildTagValue(CONST_USERTYPE,deviceElement));
		}	
		return loginBean;
	}
	

public User parseActivationCode(String xml){		
	User loginBean = new User();
	Document doc = Utils.getDocument(xml);	
	Element deviceElement = null;	
	Node deviceNode = doc.getElementsByTagName(CONST_USEROPINFO).item(0);
	if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
		deviceElement = (Element) deviceNode;		
		loginBean.setActivationcode(Utils.getChildTagValue(CONST_ACTIVATIONCODE,deviceElement));
	}	
	return loginBean;
}
}

