package publicmw.parse;

import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

public class CloudServerInfo {
	
	private String csdpId;
	private String productType;
	private String accessType;
	private String parentId;
	private String activationCode;
	private String status;
	
	public String getCsdpId() {
		return csdpId;
	}
	public void setCsdpId(String csdpId) {
		this.csdpId = csdpId;
	}
	public String getProductType() {
		return productType;
	}
	public void setProductType(String productType) {
		this.productType = productType;
	}
	public String getAccessType() {
		return accessType;
	}
	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
	public String getParentId() {
		return parentId;
	}
	public void setParentId(String parentId) {
		this.parentId = parentId;
	}
	public String getActivationCode() {
		return activationCode;
	}
	public void setActivationCode(String activationCode) {
		this.activationCode = activationCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
											// Code for parsing Customer CSDP Info
	
	private static final String CONST_ROOT="cloudserverinfo";
	private static final String CONST_ID="id";
	private static final String CONST_PRODUCT_TYPE="productType";
	private static final String CONST_ACCESS_TYPE="accessType";
	private static final String CONST_PARENT_ID="parentId";
	private static final String CONST_ACTIVATION_CODE="activationCode";
	private static final String CONST_STATUS="status";
	
	
	
	public static CloudServerInfo parse(String xml){	
		try{
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			Document doc = db.parse(is);
			Node rootNode=doc.getElementsByTagName(CONST_ROOT).item(0);
			if(null!=rootNode && rootNode.getNodeType()==Node.ELEMENT_NODE){
				Element rootElement=(Element)rootNode;
				Node idNode=rootElement.getElementsByTagName(CONST_ID).item(0);
				Node ptypeNode=rootElement.getElementsByTagName(CONST_PRODUCT_TYPE).item(0);
				Node atypeNode=rootElement.getElementsByTagName(CONST_ACCESS_TYPE).item(0);
				Node parentIdNode=rootElement.getElementsByTagName(CONST_PARENT_ID).item(0);
				Node acodeNode=rootElement.getElementsByTagName(CONST_ACTIVATION_CODE).item(0);
				Node statusNode=rootElement.getElementsByTagName(CONST_STATUS).item(0);
				CloudServerInfo info=new CloudServerInfo();
				info.setCsdpId(idNode.getTextContent());
				info.setProductType(ptypeNode.getTextContent());
				info.setAccessType(atypeNode.getTextContent());
				info.setParentId(parentIdNode.getTextContent());
				info.setActivationCode(acodeNode.getTextContent());
				info.setStatus(statusNode.getTextContent());
				System.out.println("Parent ============>"+info.getParentId());
				return info;
			}else
				return null;
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}

	
														// Code to parse CSC List of CSDP
	
	private static final String CONST_CSC_LIST_ROOT="cscList";
	private static final String CONST_CSC="csc";
	private static final String CONST_CSC_ID="id";
	private static final String CONST_CSC_ACCESS_TYPE="access";
	private static final String CONST_CSC_ACT_CODE="activationCode";
	private static final String CONST_CSC_STATUS="status";
	
	public static ArrayList<CloudServerInfo> parseCscList(String xml){
		
		try{
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			Document doc = db.parse(is);
			Node rootNode=doc.getElementsByTagName(CONST_CSC_LIST_ROOT).item(0);
			if(null!=rootNode && rootNode.getNodeType()==Node.ELEMENT_NODE){
				Element rootElement=(Element)rootNode;
				NodeList cscNodeList=rootElement.getElementsByTagName(CONST_CSC);
				ArrayList<CloudServerInfo> cscList=new ArrayList<CloudServerInfo>();
				if(null!=cscNodeList){
					
					for(int i=0;i<cscNodeList.getLength();i++){
						Node cscNode=cscNodeList.item(i);
						Element cscElement=(Element)cscNode;
						Node idNode=cscElement.getElementsByTagName(CONST_CSC_ID).item(0);
						Node accessNode=cscElement.getElementsByTagName(CONST_CSC_ACCESS_TYPE).item(0);
						Node acodeNode=cscElement.getElementsByTagName(CONST_CSC_ACT_CODE).item(0);
						Node statusNode=cscElement.getElementsByTagName(CONST_CSC_STATUS).item(0);
						CloudServerInfo info=new CloudServerInfo();
						info.setCsdpId(idNode.getTextContent());
						info.setProductType("CSC");
						info.setAccessType(accessNode.getTextContent());
						info.setActivationCode(acodeNode.getTextContent());
						info.setStatus(statusNode.getTextContent());
						info.setParentId("CurrentCsdp");
						cscList.add(info);
					}
					return cscList;
				}else
					return cscList; 
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return null;
	}
	
													// Code to parse CSDP Elements
	
	private static final String CONST_ELEMENT_ROOT="element-list";
	private static final String CONST_ELEMENT="element";
	
	public static ArrayList<String> parseCsdpElements(String xml){
		try{
			DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			Document doc = db.parse(is);
			Node rootNode=doc.getElementsByTagName(CONST_ELEMENT_ROOT).item(0);
			if(null!= rootNode && rootNode.getNodeType()==Node.ELEMENT_NODE){
				ArrayList<String> elementsList=new ArrayList<String>();
				Element rootElement=(Element)rootNode;
				NodeList elementNodeList=rootElement.getElementsByTagName(CONST_ELEMENT);
				if(null!=elementNodeList){
					for(int i=0;i<elementNodeList.getLength();i++){
						Node elementNode=elementNodeList.item(i);
						elementsList.add(elementNode.getTextContent());
					}
				}
				return elementsList;
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
}
