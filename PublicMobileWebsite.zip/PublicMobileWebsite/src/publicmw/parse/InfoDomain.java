package publicmw.parse;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import publicmw.pojo.AppInfo;
import publicmw.pojo.Info;
import publicmw.utils.Utils;

public class InfoDomain {

	public static final String CONST_ROOT="ibook:infobook";
	public static final String CONST_IBOOKUSER="ibook:user";
	public static final String CONST_IBOOKSERVICES="ibook:services";
	public static final String CONST_IBOOKINTERNAL="ibook:internal";
	public static final String CONST_IBOOKSEVICE="ibook:service";
	
	public static final String CONST_SERVICEID="N1:serviceId"; 
	public static final String CONST_SERVICETYPE="N1:serviceType";
	public static final String CONST_SERVICEURL="N1:serviceUrl";
	
	public static final String CONST_SELFURL="N1:selfUrl";
	public static final String CONST_IBOOKURL="N1:ibookUrl";
	public static final String CONST_CSSOURL="N1:cssoUrl";	
	
	public static final String CONST_ROOT2="hotelemp-profile";
	public static final String CONST_DISPLAYNAME="display-name";
	
	public static final String CONST_MANAGER="manager";
	public static final String CONST_URI="uri";
	
	public static final String CONST_IMAGE="image";
	public static final String CONST_IMAGEURL="image_url";
	
	public static final String CONST_GENDER="gender";
	
	public static final String CONST_HOTELADD="hoteladdress";
	public static final String CONST_COUNTRY="country";
	
	
	public static final String CONST_ROOT3="app-lists";
	public static final String CONST_LIST="list";
	public static final String CONST_ENTRY="entry";
	
	
	public static final String CONST_ROOT4="scpd";
	public static final String CONST_CONTROLURL="controlUrl";
	public static final String CONST_PUBLICURL="public";
	public static final String CONST_PRIVATEURL="private";
	
	
	public Info parseSelfUrl(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_IBOOKUSER).item(0);
			Element uriElement=(Element)managerNode;
			infoBean.setSelfurl(Utils.getChildTagValue(CONST_SELFURL,uriElement));			  
		}
		return infoBean;
	}
	
	
	public Info parseIbookUrl(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_IBOOKUSER).item(0);
			Element ibookElement=(Element)managerNode;
			infoBean.setIbookurl(Utils.getChildTagValue(CONST_IBOOKURL,ibookElement));			  
		}
		return infoBean;
	}
	
	
	public Info parseCssoUrl(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_IBOOKUSER).item(0);
			Element ibookElement=(Element)managerNode;
			infoBean.setCssourl(Utils.getChildTagValue(CONST_CSSOURL,ibookElement));
			//System.out.println("CSSO =========================>"+infoBean.getCssourl());
		}
		return infoBean;
	}
	
	
	
	public String[] parseAppList(String xml){
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);
				Node rootNode=doc.getElementsByTagName(CONST_ROOT3).item(0);
			    if(null!=rootNode && rootNode.getNodeType()==Node.ELEMENT_NODE){
			    	Element rootElement=(Element)rootNode;
			    	Node deviceListNode=rootElement.getElementsByTagName(CONST_LIST).item(0);
			    	if(deviceListNode!=null){
			    		Element deviceListElement=(Element)deviceListNode;
			    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_ENTRY);
			    		String[] apps=new String[deviceIdNodeList.getLength()];
			    		for(int i=0;i<deviceIdNodeList.getLength();i++){
			    			Node deviceIdNode=deviceIdNodeList.item(i);
			    			Element deviceIdElement=(Element)deviceIdNode;
			    			apps[i]=deviceIdElement.getAttribute("uri");
			    			//System.out.println("APP List ############# ::"+deviceIds[i]);
			    		}
			    		return apps;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
	}
	
	
	
	public List<AppInfo> parseAppLists(String xml){			
		List<AppInfo> appInfoList = new ArrayList<AppInfo>();
		AppInfo appInfo = null;
	try{
		    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
			InputSource is = new InputSource();
			is.setCharacterStream(new StringReader(xml));
			Document doc = db.parse(is);
			
			Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
			 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){
				 Element rootElementIndex=(Element)rootNodeIndex;
				 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IBOOKSERVICES).item(0);
		    	
			deviceListNodeEntry=doc.getElementsByTagName(CONST_IBOOKINTERNAL).item(0);
		    if(null!=deviceListNodeEntry && deviceListNodeEntry.getNodeType()==Node.ELEMENT_NODE){
		    	Element rootElement=(Element)deviceListNodeEntry;		    			    	
		    	 if(rootElement!=null){
			    		Element deviceListElement=(Element)rootElement;
			    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_IBOOKSEVICE);					    		
			    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){			    		
			    		for(int i=0;i<deviceIdNodeList.getLength();i++){	
			    			appInfo = new AppInfo();			    			
			       			Node deviceIdNode=deviceIdNodeList.item(i);			    			
			       			Element deviceIdElement=(Element)deviceIdNode;		       			
			    			 NodeList devplist = deviceIdElement.getElementsByTagName(CONST_SERVICEID);
			    			 if(null != devplist && devplist.getLength()>0)
			    			 {
			    				Element delement = (Element)devplist.item(0);
			    				if(null != delement)
			    				{
			    					NodeList textFNList = delement.getChildNodes();			    					
			    					appInfo.setAppId(textFNList.item(0).getNodeValue());
			    					//System.out.println("------------getAppId---------------------"+appInfo.getAppId());
			    					
			    				}
			    			 }    			 
			    						    			 
			    			 NodeList devSlist = deviceIdElement.getElementsByTagName(CONST_SERVICETYPE);
			    			 if(null != devSlist && devSlist.getLength()>0)
			    			 {
			    				Element delement = (Element)devSlist.item(0);
			    				if(null != delement)
			    				{
			    					NodeList textFNList = delement.getChildNodes();			    					
			    					appInfo.setServiceType(textFNList.item(0).getNodeValue());
			    					//System.out.println("-----------------------------getServiceType---------------"+appInfo.getServiceType());
			    				}
			    			 }
			    			 
			    			
			    			 appInfoList.add(appInfo);
			    		}		    		
		    		return appInfoList;
		    		}
		    		else 
		    		   return null;
		    	}
		    }}
	}catch(Exception e){
		e.printStackTrace();
	}
	return null;
}	
	
	
	public String[] parseIbookServiceId(String xml){
		 Info infoBean = new Info();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IBOOKSERVICES).item(0);
			    	
				deviceListNodeEntry=doc.getElementsByTagName(CONST_IBOOKINTERNAL).item(0);
			    if(null!=deviceListNodeEntry && deviceListNodeEntry.getNodeType()==Node.ELEMENT_NODE){	    	
			    	
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_IBOOKSEVICE);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] uri=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_SERVICEID);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					uri[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			infoBean.setServiceid(uri[i]);				    			 
				    			//System.out.println("Service Id ================>"+infoBean.getServiceid());					    							    			
				    		}		    		
			    		return uri;
			    		}
			    		else 
			    		   return null;
			    	}
			    }}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	public String[] parseIbookServiceType(String xml){
		 Info infoBean = new Info();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IBOOKSERVICES).item(0);
			    	
				deviceListNodeEntry=doc.getElementsByTagName(CONST_IBOOKINTERNAL).item(0);
			    if(null!=deviceListNodeEntry && deviceListNodeEntry.getNodeType()==Node.ELEMENT_NODE){	    	
			    	
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_IBOOKSEVICE);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] uri=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_SERVICETYPE);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					uri[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			infoBean.setServicetype(uri[i]);				    			 
				    			//System.out.println("Service Type  ================>"+infoBean.getServicetype());					    							    			
				    		}		    		
			    		return uri;
			    		}
			    		else 
			    		   return null;
			    	}
			    }}
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	public Info parseDisplayName(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT2).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;
			infoBean.setDisplayname(Utils.getChildTagValue(CONST_DISPLAYNAME,hotelElement));			  
		}
		return infoBean;	
		
	}
	
	
	public Info parsePublicUrl(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT4).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_CONTROLURL).item(0);
			Element uriElement=(Element)managerNode;
			infoBean.setPub(Utils.getChildTagValue(CONST_PUBLICURL,uriElement));			  
		}
		return infoBean;
	}
	
	
	public Info parsePrivteUrl(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT4).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_CONTROLURL).item(0);
			Element uriElement=(Element)managerNode;
			infoBean.setPri(Utils.getChildTagValue(CONST_PRIVATEURL,uriElement));			  
		}
		return infoBean;
	}
	
	public Info parseUri(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT2).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_MANAGER).item(0);
			Element uriElement=(Element)managerNode;
			infoBean.setUri(Utils.getChildTagValue(CONST_URI,uriElement));			  
		}
		return infoBean;
	}
	
	
	public Info parseImageUrl(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT2).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_IMAGE).item(0);
			Element imageElement=(Element)managerNode;
			infoBean.setImageurl(Utils.getChildTagValue(CONST_IMAGEURL,imageElement));			  
		}
		return infoBean;
	}
	
	public Info parseGender(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element genderElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT2).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			genderElement = (Element) hotelProfileNode;
			infoBean.setGender(Utils.getChildTagValue(CONST_GENDER,genderElement));		  
		}
		return infoBean;
	}
	
	public Info parseCountry(String xml){		
		Info infoBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element hotelElement = null;	
		Node hotelProfileNode = doc.getElementsByTagName(CONST_ROOT2).item(0);
		if(hotelProfileNode.getNodeType() == Node.ELEMENT_NODE) {
			hotelElement = (Element) hotelProfileNode;	
			Node managerNode=hotelElement.getElementsByTagName(CONST_HOTELADD).item(0);
			Element countryElement=(Element)managerNode;
			infoBean.setCountry(Utils.getChildTagValue(CONST_COUNTRY,countryElement));			  
		}
		return infoBean;
	}
	
	//Added On 29.07.16
	public static final String CONST_USEROPINFO="userOpInfo";
	public static final String CONST_INFO="info";
	public Info parseMasterIndexInfo(String xml){		
		Info domainBean = new Info();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_USEROPINFO).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;			
			domainBean.setInfo(Utils.getChildTagValue(CONST_INFO,deviceElement));
		} 
		return domainBean;
	}
	
}
