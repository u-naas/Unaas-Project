package publicmw.parse;

import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import publicmw.pojo.Temp;

import publicmw.utils.Utils;

public class Template {
	//Template Info
	public static final String CONST_TEMPLATELIST="templateList";
	public static final String CONST_TEMPLATE="template";
	public static final String CONST_TEMPLATEID="templateId";
	
	
	public Temp parseTemplateInfo(String xml){		
		Temp dInfoBean = new Temp();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;	
		Node deviceNode = doc.getElementsByTagName(CONST_TEMPLATELIST).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {
			deviceElement = (Element) deviceNode;	
			Node templateNode=deviceElement.getElementsByTagName(CONST_TEMPLATE).item(0);
			Element deviceIdElement=(Element)templateNode;
			dInfoBean.setTemplateId(Utils.getChildTagValue(CONST_TEMPLATEID,deviceIdElement));			   

		}			 

		return dInfoBean;
	}
	
	
}
