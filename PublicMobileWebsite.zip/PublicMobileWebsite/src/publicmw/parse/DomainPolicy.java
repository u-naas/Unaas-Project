package publicmw.parse;

import java.io.StringReader;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.xml.sax.InputSource;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

public class DomainPolicy {
  private static final String CONST_ROOT="policy-server";
  private static final String CONST_USER="user";
  private static final String CONST_URI="uri";
  private static final String CONST_DISPLAYNAME="display-name";
  private static final String CONST_IOT="iot";
  private static final String CONST_LINK="link";
  private static final String CONST_INFO="info";
  private static final String CONST_COM="com";
  private static final String CONST_ENT="ent";
  
  
  public static String iotLink=null;
  public static String infoLink=null;
  public static String comLink=null;
  public static String entLink=null;
  public static String uri=null;
  public static String displayName=null;
  
  
  public static void parse(String policyXML){
	  iotLink=null;
	  infoLink=null;
	  comLink=null;
	  entLink=null;
	  uri=null;
	  displayName=null;
	  System.out.println("Parsing Policy Document");
	  try{
			 DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(policyXML));
				Document doc = db.parse(is);
				Node rootNode=doc.getElementsByTagName(CONST_ROOT).item(0);
				if(null!=rootNode && rootNode.getNodeType()==Node.ELEMENT_NODE){
					Element rootElement=(Element)rootNode;
					Node userNode=rootElement.getElementsByTagName(CONST_USER).item(0);
					parseUserNode(userNode);
					Node iotNode=rootElement.getElementsByTagName(CONST_IOT).item(0);
					parseLinkNode(iotNode,"iot");
					Node infoNode=rootElement.getElementsByTagName(CONST_INFO).item(0);
					parseLinkNode(infoNode,"info");
					Node comNode=rootElement.getElementsByTagName(CONST_COM).item(0);
					parseLinkNode(comNode,"com");
					Node entNode=rootElement.getElementsByTagName(CONST_ENT).item(0);
					parseLinkNode(entNode,"ent");
				}
	  }
	  catch(Exception e){
		  System.out.println("Error while parsing Policy Document");
		  e.printStackTrace();
		  
	  }
  }




private static void parseLinkNode(Node iotNode, String string) {
	System.out.println("Parsing Link Node for :"+string);
	try{
	if(null!=iotNode && iotNode.getNodeType()==Node.ELEMENT_NODE){
		Element iotElement=(Element)iotNode;
		Node linkNode=iotElement.getElementsByTagName(CONST_LINK).item(0);
		if(string.equalsIgnoreCase("iot"))
			DomainPolicy.iotLink=linkNode.getTextContent();
		else if(string.equalsIgnoreCase("info"))
			DomainPolicy.infoLink=linkNode.getTextContent();
		else if(string.equalsIgnoreCase("com"))
			DomainPolicy.comLink=linkNode.getTextContent();
		else
			DomainPolicy.entLink=linkNode.getTextContent();
	}
	}
	catch(Exception e){
		System.out.println("Error while parsing link node for "+string);
		e.printStackTrace();
		
	}
	
}




private static void parseUserNode(Node userNode) {
	System.out.println("Parsing User Node in Policy Document");
	try{
		if(null!=userNode && userNode.getNodeType()==Node.ELEMENT_NODE){
			Element userElement=(Element)userNode;
			Node uriNode=userElement.getElementsByTagName(CONST_URI).item(0);
		    DomainPolicy.uri=uriNode.getTextContent();
			Node displayNameNode=userElement.getElementsByTagName(CONST_DISPLAYNAME).item(0);
			DomainPolicy.displayName=displayNameNode.getTextContent();
		}
	}catch(Exception e){
		e.printStackTrace();
	}
	
}
  
	
}
