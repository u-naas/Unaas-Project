package publicmw.parse;

import java.io.StringReader;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import publicmw.pojo.Replace;
import publicmw.utils.Utils;

public class ReplaceFile {

	public static final String CONST_ROOT="enableDomain";
	public static final String CONST_IOT="iot";
	public static final String CONST_DEVICEIDS="deviceIds";
	public static final String CONST_DEVICEPROFILES="deviceProfiles";	
	public static final String CONST_DEVICESERVICEACTIONS="deviceServiceActions";

	public static final String CONST_DISPLAYNAMEIOT="displaynameIot";
	public static final String CONST_URIIOT="uriIot";
	public static final String CONST_IMAGEURLIOT="imageurlIot";	
	public static final String CONST_GENDERIOT="genderIot";
	public static final String CONST_CONTRYIOT="contryIot";
	public static final String CONST_PUBLICURLIOT="publicIot";	
	public static final String CONST_PRIVATEURLIOT="privateIot";
	public static final String CONST_DEVICEIDIOT="deviceIdIot";	
	public static final String CONST_DEVICENAMEIOT="devicenameIot";	
	public static final String CONST_CATEGORYIOT="categoryIot";	
	public static final String CONST_DEVICETYPEIOT="devicetypeIot";	
	public static final String CONST_MODELDESCRIPTIONIOT="modeldescriptionIot";
	public static final String CONST_UDNIOT="UDN";	
	
	public static final String CONST_IDIOT="idIot";	
	public static final String CONST_PRODUCTIDIOT="productidIot";	
	public static final String CONST_SERVICETYPEIOT="servicetypeIot";
	
	public static final String CONST_INFO="info";	  
	public static final String CONST_APPIDS="appIds";
	public static final String CONST_APPSEVICEIDS="appServiceIds";
	public static final String CONST_APPSERVICETYPES="appServiceTypes";
	
	
	public static final String CONST_DISPLAYNAMEINFO="displaynameInfo";
	public static final String CONST_URIINFO="uriInfo";
	public static final String CONST_IMAGEURLINFO="imageurlInfo";
	public static final String CONST_GENDERINFO="genderInfo";
	public static final String CONST_COUNTRYINFO="countryInfo";
	public static final String CONST_APPIDINFO="appidInfo";    
	
	public static final String CONST_PUBLICURLINFO="publicurlInfo";
	public static final String CONST_PRIVATEURLINFO="privateurlInfo";
	public static final String CONST_SERVICEIDINFO="serviceidInfo";
	public static final String CONST_SERVICETYPEINFO="servicetypeInfo";
	


	public Replace parseForIot(String xml){		
		Replace replaceBean = new Replace();
		Document doc = Utils.getDocument(xml);	
		Element displayiotElement = null;	
		Node displayIotNode = doc.getElementsByTagName(CONST_ROOT).item(0);
		if(displayIotNode.getNodeType() == Node.ELEMENT_NODE) {
			displayiotElement = (Element) displayIotNode;	
			Node iotNode=displayiotElement.getElementsByTagName(CONST_IOT).item(0);
			Element dniotElement=(Element)iotNode;
			replaceBean.setDisplaynameIot(Utils.getChildTagValue(CONST_DISPLAYNAMEIOT,dniotElement));
			replaceBean.setUriIot(Utils.getChildTagValue(CONST_URIIOT,dniotElement));	
			replaceBean.setImageurlIot(Utils.getChildTagValue(CONST_IMAGEURLIOT,dniotElement));	
			replaceBean.setGenderIot(Utils.getChildTagValue(CONST_GENDERIOT,dniotElement));	
			replaceBean.setContryIot(Utils.getChildTagValue(CONST_CONTRYIOT,dniotElement));	
			replaceBean.setPublicIot(Utils.getChildTagValue(CONST_PUBLICURLIOT,dniotElement));	
			replaceBean.setPrivateIot(Utils.getChildTagValue(CONST_PRIVATEURLIOT,dniotElement));
		
		}
		return replaceBean;
	}
	
	
	
	public Replace parseForInfo(String xml){		
		Replace replaceBean = new Replace();
		Document doc = Utils.getDocument(xml);	
		Element displayiotElement = null;	
		Node displayIotNode = doc.getElementsByTagName(CONST_ROOT).item(0);
		if(displayIotNode.getNodeType() == Node.ELEMENT_NODE) {
			displayiotElement = (Element) displayIotNode;	
			Node iotNode=displayiotElement.getElementsByTagName(CONST_INFO).item(0);
			Element dniotElement=(Element)iotNode;
			replaceBean.setDisplaynameInfo(Utils.getChildTagValue(CONST_DISPLAYNAMEINFO,dniotElement));
			replaceBean.setUriInfo(Utils.getChildTagValue(CONST_URIINFO,dniotElement));	
			replaceBean.setImageurlInfo(Utils.getChildTagValue(CONST_IMAGEURLINFO,dniotElement));	
			replaceBean.setGenderInfo(Utils.getChildTagValue(CONST_GENDERINFO,dniotElement));	
			replaceBean.setCountryInfo(Utils.getChildTagValue(CONST_COUNTRYINFO,dniotElement));	
			replaceBean.setPublicurlInfo(Utils.getChildTagValue(CONST_PUBLICURLINFO,dniotElement));	
			replaceBean.setPrivateurlInfo(Utils.getChildTagValue(CONST_PRIVATEURLINFO,dniotElement));
		
		}
		return replaceBean;
	}


	public String[] parseDeviceList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IOT).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEIDS);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] deviceIds=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_DEVICEIDIOT);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					deviceIds[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setDeviceIdIot(deviceIds[i]);				    			 
				    			//System.out.println("DeviceIds ####################### "+replaceBean.getDeviceIdIot());					    							    			
				    		}		    		
			    		return deviceIds;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	
	
	public String[] parseAppList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_INFO).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_APPIDS);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] appIds=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_APPIDINFO);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					appIds[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setAppidInfo(appIds[i]);			    								    							    			
				    		}		    		
			    		return appIds;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	public String[] parsedevicenameList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IOT).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEPROFILES);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] deviceNames=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_DEVICENAMEIOT);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					deviceNames[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setDevicenameIot(deviceNames[i]);				    								    							    			
				    		}		    		
			    		return deviceNames;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	public String[] parsecategorysList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IOT).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEPROFILES);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] categoryIot=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_CATEGORYIOT);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					categoryIot[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setCategoryIot(categoryIot[i]);				    								    							    			
				    		}		    		
			    		return categoryIot;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}	
	
	public String[] parsedevicetypeList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IOT).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEPROFILES);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] deviceTypeIot=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_DEVICETYPEIOT);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					deviceTypeIot[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setDevicetypeIot(deviceTypeIot[i]);				    								    							    			
				    		}		    		
			    		return deviceTypeIot;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	public String[] parsemodeldescriptionList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IOT).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEPROFILES);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] modelDescIot=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_MODELDESCRIPTIONIOT);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					modelDescIot[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setModeldescriptionIot(modelDescIot[i]);				    								    							    			
				    		}		    		
			    		return modelDescIot;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}	
	
	
	public String[] parseUdnList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IOT).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICEPROFILES);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] udnIot=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_UDNIOT);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					udnIot[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setUdn(udnIot[i]);				    								    							    			
				    		}		    		
			    		return udnIot;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	
	public String[] parseproductidList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IOT).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICESERVICEACTIONS);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] productIot=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_PRODUCTIDIOT);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					productIot[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setProductidIot(productIot[i]);				    								    							    			
				    		}		    		
			    		return productIot;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	
	
	public String[] parseServiceidList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_INFO).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_APPSEVICEIDS);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] serviceIdInfo=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_SERVICEIDINFO);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					serviceIdInfo[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setServiceidInfo(serviceIdInfo[i]);				    								    							    			
				    		}		    		
			    		return serviceIdInfo;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	
	public String[] parseservicetypeList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_IOT).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_DEVICESERVICEACTIONS);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] serviceTypeIot=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_SERVICETYPEIOT);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					serviceTypeIot[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setServicetypeIot(serviceTypeIot[i]);				    								    							    			
				    		}		    		
			    		return serviceTypeIot;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
	
	
	public String[] parseappServiceTypesList(String xml){
		 Replace replaceBean = new Replace();
		try{
			    DocumentBuilder db= DocumentBuilderFactory.newInstance().newDocumentBuilder();		
				InputSource is = new InputSource();
				is.setCharacterStream(new StringReader(xml));
				Document doc = db.parse(is);		
				
				Node rootNodeIndex=doc.getElementsByTagName(CONST_ROOT).item(0);
				 if(null!=rootNodeIndex && rootNodeIndex.getNodeType()==Node.ELEMENT_NODE){					 
					 Element rootElementIndex=(Element)rootNodeIndex;
					 Node deviceListNodeEntry=rootElementIndex.getElementsByTagName(CONST_INFO).item(0);
					 
			    	Element deviceListElement=(Element)deviceListNodeEntry;
		    		NodeList deviceIdNodeList=deviceListElement.getElementsByTagName(CONST_APPSERVICETYPES);		    		
			    	 if(deviceIdNodeList!=null){				    		 
				    		if(null!=deviceIdNodeList && deviceIdNodeList.getLength()!=0){				    			 
				    		String[] serviceTypeInfo=new String[deviceIdNodeList.getLength()];
				    		for(int i=0;i<deviceIdNodeList.getLength();i++){				    			 
				       			Node deviceIdNode=deviceIdNodeList.item(i);
				    			
				       			Element deviceIdElement=(Element)deviceIdNode;				    			 
				    			 NodeList devlist = deviceIdElement.getElementsByTagName(CONST_SERVICETYPEINFO);
				    			 if(null != devlist && devlist.getLength()>0)
				    			 {				    				 
				    				Element delement = (Element)devlist.item(0);
				    				if(null != delement)
				    				{
				    					NodeList textFNList = delement.getChildNodes();
				    					serviceTypeInfo[i] = textFNList.item(0).getNodeValue();
				    				}
				    			 }				    			 
				    			 replaceBean.setServicetypeInfo(serviceTypeInfo[i]);				    								    							    			
				    		}		    		
			    		return serviceTypeInfo;
			    		}
			    		else 
			    		   return null;
			    	}
			    }
		}catch(Exception e){
			e.printStackTrace();
		}
		return null;
			
		
	}
	
}