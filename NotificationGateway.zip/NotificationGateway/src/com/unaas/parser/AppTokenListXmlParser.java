package com.unaas.parser;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.unaas.bean.*;
import com.unaas.parser.Utils;

public class AppTokenListXmlParser {


	
	public static final String CONST_APP_LIST 				= "app-list";
	public static final String CONST_APP 					= "app";
	public static final String CONST_TOKEN 					= "token";
	public static final String CONST_APP_NAME 				= "appName";
	public static final String CONST_APP_TYPE 				= "appType";
	public static final String CONST_TOKEN_VAL 				= "token-val";
	
	public AppListBean parseAppTokenListXml(String appTokenListXml)
	{
		System.out.println("appTokenListXml::\n"+appTokenListXml);
		AppListBean applistBean = new AppListBean();		
		
		Document doc = Utils.getDocument(appTokenListXml);		
		System.out.println("Document created!");
		
		Node applistnode = doc.getElementsByTagName(CONST_APP_LIST).item(0);
		if(null!=applistnode && applistnode.getNodeType() == Node.ELEMENT_NODE)
		{
			Node[] noOfAppListChild = Utils.getChildNodes(applistnode);
			if(null != noOfAppListChild && noOfAppListChild.length > 0)
			{
				System.out.println("Size of noOfAppListChild::"+noOfAppListChild.length);
				for(int index = 0; index < noOfAppListChild.length; index++)
				{
					System.out.println("\nNode :: "+noOfAppListChild[index].getNodeName()+"\n attribute::"+((Element)noOfAppListChild[index]).getAttribute(CONST_APP_NAME));//("appName"));
					AppBean app = this.appParser(noOfAppListChild[index]);
					//applistBean.appList.add(app);
					applistBean.applist.put(((Element)noOfAppListChild[index]).getAttribute("appName"), app);
				}
			}
		}	
		return applistBean;
	}	
	
	public AppBean appParser(Node appNode)
	{
		System.out.println(" Inside  appParser");
		AppBean appBean = new AppBean();
		Element element = null;
		
		if(null!=appNode && appNode.getNodeType() == Node.ELEMENT_NODE)
		{
			element = (Element)appNode;
		}

		Node[] noOfTokenList = Utils.getChildNodes(element);
		System.out.println("noOfTokenList::"+noOfTokenList.length);
		if(noOfTokenList.length > 0)
		{
			for(int index = 0; index< noOfTokenList.length; index++ )
			{
				TokenBean token = this.tokenParser(noOfTokenList[index]);
				//appBean.tokenList.add(token);
				appBean.tokenList.put(token.getTokenType(), token);
			}
		}	
		return appBean;
	}
	
	public TokenBean tokenParser(Node tokenNode)
	{
		System.out.println(" Inside  tokenParser");
		TokenBean tokenBean = new TokenBean();
		Element tokenele = null;
		
		if(null!=tokenNode && tokenNode.getNodeType() == Node.ELEMENT_NODE)
		{
			tokenele = (Element)tokenNode;
		}
				
		tokenBean.setAppName(Utils.getChildTagValue(CONST_APP_NAME, tokenele));
		System.out.println("app::"+tokenBean.getAppName());
		
		tokenBean.setTokenType(Utils.getChildTagValue(CONST_APP_TYPE, tokenele));
		System.out.println("app type::"+tokenBean.getTokenType());
		
		tokenBean.setToken_val(Utils.getChildTagValue(CONST_TOKEN_VAL, tokenele));
		System.out.println("Toke Val::"+tokenBean.getToken_val());
		return tokenBean;
	}
	
	
	public static void main(String[] args) {
		
		String appTokenListXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
									"<app-list>"+	
									    "<app appName=\"FACEBOOK\">"+
									        "<token>"+
									            "<appName>FACEBOOK</appName>"+
									            "<appType>ACCESS_TOKEN</appType>"+
									            "<token-val>AAADeA0qrbjEBANZCZBDOZBGpCpkkdSSuW2bcmN2xZBzVjsy5BAh5G4jP17dxXNZAogfE6iGyBjkywGicfOcjmqmJ6WBZCaMKRJZBkQhwxV7NwZDZD</token-val>"+
									        "</token>"+							        
									        "<token>"+
									            "<appName>Facebook</appName>"+
									            "<appType>APP_ID</appType>"+
									            "<token-val>244105719017009</token-val>"+
									        "</token>"+
									        "<token>"+
									            "<appName>Facebook</appName>"+
									            "<appType>APP_SECRET</appType>"+
									            "<token-val>cb7d27bec789c185ef3325929730ef66</token-val>"+
									        "</token>"+
									    "</app>"+
									    "<app appName=\"SMS_GSM_MODEM_GATEWAY\">"+
									        "<token>"+
									            "<appName>SMS_GSM_MODEM_GATEWAY</appName>"+
									            "<appType>IP</appType>"+
									            "<token-val>hgw.unaas.dnsget.org</token-val>"+
									        "</token>"+
									        "<token>"+
									            "<appName>SMS_GSM_MODEM_GATEWAY</appName>"+
									            "<appType>PORT</appType>"+
									            "<token-val>56786</token-val>"+
									        "</token>"+
									    "</app>"+	    
									"</app-list>";
		
	
		
		
		String appTokenListXml2 = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"+
					"<app-list>"+
					"<app appName=\"FACEBOOK\">"+
					"<token>"+
					"<appName>FACEBOOK</appName>"+
					"<appType>ACCESS_TOKEN</appType>"+
					"<token-val>EAAC9w1uXbfcBAKNiMW3wCLLEKSZASgcryQKRulteQGzrjPprgNUCyEwALXBSTcjoQTaz1sUYCtDzE7aM6HYaB5qgMBkGbQE9Lbpzf1nmqcZCxmV3gqSXSGdtctkwnFOPCeJDRiYRYPrJY6lEZAPxt40GeMFfNsBHwmERgPvshvOj7DZB5OwNYB702WS39t8OQ0MAvKY8EgZDZD</token-val>"+
					"</token>"+
					"<token>"+
					"<appName>Facebook</appName>"+
					"<appType>APP_ID</appType>"+
					"<token-val>208646752923127</token-val>"+
					"</token>"+
					"<token>"+
					"<appName>Facebook</appName>"+
					"<appType>APP_SECRET</appType>"+
					"<token-val>93ebe939dce8c5e392bfb22c790806c0</token-val>"+
					"</token>"+
					"</app>"+
					"<app appName=\"TWITTER\">"+
					"<token>"+
					"<appName>TWITTER</appName>"+
					"<appType>ACCESS_TOKEN</appType>"+
					"<token-val>806557296205537280-sdX15gCVGrcAvCCgS5K1e4qkALZfnkv</token-val>"+
					"</token>"+
					"<token>"+
					"<appName>TWITTER</appName>"+
					"<appType>ACCESS_TOKENSECRET</appType>"+
					"<token-val>YLIEgqHsyTqTFHbeFjyPC2G4sOqz5h3eHtiNSWJwOkLUp</token-val>"+
					"</token>"+
					"<token>"+
					"<appName>TWITTER</appName>"+
					"<appType>CONSUMERKEY</appType>"+
					"<token-val>BKOC8rSzfY7HSfXom8MJTjgh1</token-val>"+
					"</token>"+
					"<token>"+
					"<appName>TWITTER</appName>"+
					"<appType>CONSUMERKEY_SECRET</appType>"+
					"<token-val>ctrD9j4yhuM3hZlpWknuwNOGm2J9qZ9290aSIO4LbPhSeRwEiL</token-val>"+
					"</token>"+
					"</app>"+
					"</app-list>";
					
		AppTokenListXmlParser par = new AppTokenListXmlParser();
		par.parseAppTokenListXml(appTokenListXml2);
	}
}
