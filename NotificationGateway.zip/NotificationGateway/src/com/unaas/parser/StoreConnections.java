package com.unaas.parser;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Hashtable;
import java.sql.Statement;
import java.sql.ResultSet;

import com.unaas.interfaces.Settings;

public class StoreConnections {
private static Hashtable<String,Connection> m_ConnTable = new Hashtable<String,Connection>();
private static Hashtable<String,Connection> DBCreate_Delete = new Hashtable<String,Connection>();
	
	public static Connection getConn()
	{
		Connection c = m_ConnTable.get("root");
		try{
			if(null == c){				
					
					Class.forName("com.mysql.jdbc.Driver");					
					 c = DriverManager.getConnection("jdbc:mysql://"+Settings.MYSQLCONNECTION_DOMAIN+"/mysql?autoReconnect=true",Settings.MYSQL_USERNAME,Settings.MYSQL_PASSWORD);
					m_ConnTable.put("root", c);
					return c;
			}else if(c.isValid(3) && !c.isClosed())	{
				System.out.println("check jdbc connection in services==="+c.isValid(3));
				return c;
				
			}else{
				m_ConnTable.remove("root");				
				
				Class.forName("com.mysql.jdbc.Driver");
				c = DriverManager.getConnection("jdbc:mysql://"+Settings.MYSQLCONNECTION_DOMAIN+"/mysql?autoReconnect=true",Settings.MYSQL_USERNAME,Settings.MYSQL_PASSWORD);
				m_ConnTable.put("root", c);
				return c;
			}
	  }catch(SQLException se){
		se.printStackTrace();		
	  }catch(Exception e){
		e.printStackTrace();		
	  }
		return null;
	}

	
	public static Connection getConn1()
	{
		Connection c = m_ConnTable.get("root");
		try{
			if(null == c){				
					System.out.println("StoreConnections.getConn1()");
					Class.forName("com.mysql.jdbc.Driver");					
					 c = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql?autoReconnect=true","root","root");
					m_ConnTable.put("root", c);
					return c;
			}else if(c.isValid(3) && !c.isClosed())	{
				System.out.println("check jdbc connection in services==="+c.isValid(3));
				return c;
				
			}else{
				m_ConnTable.remove("root");				
				
				Class.forName("com.mysql.jdbc.Driver");
				c = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql?autoReconnect=true","root","root");
				m_ConnTable.put("root", c);
				return c;
			}
	  }catch(SQLException se){
		se.printStackTrace();		
	  }catch(Exception e){
		e.printStackTrace();		
	  }
		return null;
	}
	
	
	public static Connection getConn(String custId){
		Connection c;
		try{
			 c = m_ConnTable.get(custId);
		if(c==null){
			String dbName ="NOTIFICATION_DB";
			Class.forName("com.mysql.jdbc.Driver");
			c = DriverManager.getConnection("jdbc:mysql://"+Settings.MYSQLCONNECTION_DOMAIN+"/"+dbName+"?autoReconnect=true",Settings.MYSQL_USERNAME,Settings.MYSQL_PASSWORD);
			m_ConnTable.put(custId, c);
			return c;
		}else{
			try{
			Statement s=c.createStatement();
			ResultSet rs=s.executeQuery("SELECT 1");
			rs.next();
			rs.close();
			rs=null;
			s.close();
			s=null;
			return c;
			}catch(Exception e){
				m_ConnTable.remove(custId);				
				String dbName ="NOTIFICATION_DB";
				Class.forName("com.mysql.jdbc.Driver");
				c = DriverManager.getConnection("jdbc:mysql://"+Settings.MYSQLCONNECTION_DOMAIN+"/"+dbName+"?autoReconnect=true",Settings.MYSQL_USERNAME,Settings.MYSQL_PASSWORD);
				m_ConnTable.put(custId, c);
				return c;
			}
		}
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
	}
		
		public static Connection getConnForDBCreate_Delete()
		{
			Connection c = DBCreate_Delete.get("root");
			try{
				if(null == c){				
						
						Class.forName("com.mysql.jdbc.Driver");					
						 c = DriverManager.getConnection("jdbc:mysql://"+Settings.MYSQLCONNECTION_DOMAIN+"/mysql?autoReconnect=true",Settings.MYSQL_USERNAME,Settings.MYSQL_PASSWORD);
						 DBCreate_Delete.put("root", c);
						return c;
				}else if(c.isValid(3))	{
					System.out.println("check jdbc connection in services For DBCreate_Delete==="+c.isValid(3));
					return c;				
				}else{
					DBCreate_Delete.remove("root");				
					Class.forName("com.mysql.jdbc.Driver");
					c = DriverManager.getConnection("jdbc:mysql://"+Settings.MYSQLCONNECTION_DOMAIN+"/mysql?autoReconnect=true",Settings.MYSQL_USERNAME,Settings.MYSQL_PASSWORD);
					DBCreate_Delete.put("root", c);
					return c;
				}
		  }catch(SQLException se){
			se.printStackTrace();		
		  }catch(Exception e){
			e.printStackTrace();		
		  }
			return null;
		}//getConn()

	}
	