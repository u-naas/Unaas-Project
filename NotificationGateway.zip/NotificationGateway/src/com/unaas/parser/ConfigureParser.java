package com.unaas.parser;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.unaas.bean.*;
import com.unaas.parser.Utils;

public class ConfigureParser {

	public static final String CONST_SMS="sms";
	public static final String CONST_TO="to";
	public static final String CONST_FROM="from";


	public SmsBean parseSms(String xml){	
		System.out.println("===inside parseSms==");
		SmsBean SInfoBean = new SmsBean();
		Document doc = Utils.getDocument(xml);	
		Element deviceElement = null;
		System.out.println("line1=====");

		//getting access token information
		Node deviceNode = doc.getElementsByTagName(CONST_SMS).item(0);
		if(deviceNode.getNodeType() == Node.ELEMENT_NODE) {

			System.out.println("=====");	
			deviceElement = (Element) deviceNode;
			SInfoBean.setTos(Utils.getChildTagValue(CONST_TO,deviceElement));
			SInfoBean.setFroms(Utils.getChildTagValue(CONST_FROM,deviceElement));

		}			 
		System.out.println("End of Parsing");
		return SInfoBean;
	}




}
