
package com.unaas.daos;

import java.util.Date;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import com.unaas.interfaces.Settings;


public class EmailManager {


	public String send(String subject, String content, String toAddr){

		final String username = Settings.DEFAULT_EMAIL_USER_ID;
		final String password = Settings.DEFAULT_EMAIL_USER_PASSWD;
 
		Properties props = new Properties();
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.host", Settings.DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_HOST);
		props.put("mail.smtp.port", Settings.DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_PORT); 
		Session session = Session.getInstance(props,
		  new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		  });
 
		try {
 
			Message message = new MimeMessage(session);
			message.setHeader("Content-Type","text/plain; charset=UTF-8");
			message.setFrom((new InternetAddress(Settings.DEFAULT_EMAIL)));
			message.setRecipients(Message.RecipientType.TO,
				InternetAddress.parse(toAddr));
			message.setSubject(subject);
			message.setText(content);
 
			Transport.send(message);
 
			System.out.println("Email Sent to:" + toAddr + " Subject:" + subject + "\nContent:" + content);
			return "200";
		} catch (MessagingException e) {
			e.printStackTrace();
			return "500";
		}				
	}
	
	
	public String sendMail(String subject, String msgText, String toAddr)
	{
		
		
		final String from     = Settings.DEFAULT_EMAIL_USER_ID;
		final String Password = Settings.DEFAULT_EMAIL_USER_PASSWD;
		
		boolean sessionDebug=false;
		
	    Properties props = System.getProperties();
	    props.put("mail.smtp.host", Settings.DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_HOST);
	    props.put("mail.smtp.auth","true");
	    props.put("mail.debug","false");

	    Session session = Session.getDefaultInstance(props, new javax.mail.Authenticator(){
	    	protected PasswordAuthentication getPasswordAuthentication(){
	    		return new PasswordAuthentication(from, Password);
	    	}
	    });
	    
	    session.setDebug(sessionDebug);
	    try {
	        Message msg = new MimeMessage(session);
		    msg.setFrom(new InternetAddress(from));
		    msg.setHeader("Content-Type","text/plain; charset=UTF-8");
		    
		    InternetAddress[] address = {new InternetAddress(toAddr)};
		    msg.setRecipients(Message.RecipientType.TO, address);
		    msg.setSubject(subject);
		    msg.setSentDate(new Date());
		    msg.setText(msgText);
		    Transport.send(msg);
		    System.out.println("==message sent successfully==");
		    return "200";
	    }
	    catch (MessagingException mex) {
	    	mex.printStackTrace();
	    	return "500";
	    }
		
		
		
	}
	
	public static void main(String[] args) {
		EmailManager em = new EmailManager();
		em.sendMail("Hello", "Hello Test123", "avikesh@u-naas.com");
		
	}

}
