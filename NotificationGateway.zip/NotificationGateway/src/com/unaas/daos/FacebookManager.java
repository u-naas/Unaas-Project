package com.unaas.daos;



import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.types.FacebookType;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.unaas.interfaces.Settings;


public class FacebookManager {
	

	
		private final FacebookClient facebookClient;
		private EmailManager em_manger = null;
		
		public FacebookManager(String accessToken) {
			    facebookClient = new DefaultFacebookClient(accessToken);
			  }
		
		public FacebookManager()
		{
			facebookClient = new DefaultFacebookClient(Settings.FACEBOOK_ACCESS_TOKEN);

		}
	
	
		
		public String send(String content, String recipientId, boolean isWallPost,String accesstoken){
			if(true == isWallPost){
				System.out.println("Inside true..");
				try {
					String msgType = recipientId + "/feed";    
					FacebookClient facebookClient = new DefaultFacebookClient(accesstoken);//(m_Mgr.m_Config.m_nmFacebookAccessToken);
					FacebookType publishMessageResponse = facebookClient.publish(
							msgType, FacebookType.class,
							Parameter.with("message", content));
					
					System.out.println("Facebook Published message ID: "
							+ publishMessageResponse.getId());
					return "200";
				} catch (Exception e) {
					e.printStackTrace();
					return "500";
				}
			}else{
				
				//Send Email to the Facebook Recipient
				
				String fbMsgReceipient = recipientId + "@facebook.com";
				
				//m_NotifyMgr.doEmailNotification("u-naas [Alert]", content, fbMsgReceipient);
				
				em_manger = new EmailManager();
				
				//em_manger.send("u-naas [Alert]", content, fbMsgReceipient);
				
				em_manger.sendMail("U-Naas [Alert]", content, fbMsgReceipient);
				System.out.println("Facebook Sent message to receipent: " + recipientId);
				return "200";
			}
		} 
		  
		public static int counter = 1;
		public void execute(JobExecutionContext arg0) throws JobExecutionException
		{
			System.out.println("Inside FBTokenUpdator Job to renew Facebook Token in every 60 days..");
			renewFacebooktoken();
			System.out.println("Facebook token updated on : "+new Date() +" and is counter = "+counter);
			counter++;        
			System.out.println("========================");
		}
		
		private static final int renewFacebooktoken()
		{
			Client c 				= Client.create();
			WebResource resource 	= c.resource("https://graph.facebook.com/oauth/access_token?client_id="+Settings.FACEBOOK_APP_ID+
										"&client_secret="+Settings.FACEBOOK_APP_SECRET+
										"&grant_type=fb_exchange_token" +
										"&fb_exchange_token="+Settings.FACEBOOK_ACCESS_TOKEN);
		
			ClientResponse cresp	= resource.get(ClientResponse.class);
			System.out.println("Status : "+cresp.getStatus());
			if(200 == cresp.getStatus())
			{
				String resp = cresp.getEntity(String.class);		
				System.out.println("response from Facebook Server :\n"+resp);
			
				String token = resp.substring(resp.indexOf("access_token=")+13, resp.lastIndexOf("&expires")).trim();
				System.out.println("Updated Facebook access token :\n"+token);
				Settings.FACEBOOK_ACCESS_TOKEN = token;
			}
			return cresp.getStatus();
		}
		
		public static void main(String[] args) {
		
			System.out.println(renewFacebooktoken());		
		}
		  
		
}
