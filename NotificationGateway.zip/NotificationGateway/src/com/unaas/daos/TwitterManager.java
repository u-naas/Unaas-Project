package com.unaas.daos;

import java.net.URLEncoder;

import oauth.signpost.OAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

import twitter4j.DirectMessage;
import twitter4j.Twitter;
import twitter4j.TwitterFactory;
import twitter4j.conf.ConfigurationBuilder;
import twitter4j.Status;
import twitter4j.auth.AccessToken;

import com.unaas.interfaces.Settings;


public class TwitterManager {	
	  
	  
	  static String consumerKeyStr 			= "v4H26s3zRjhTSdu5AzouUTBq2";
	  static String consumerSecretStr 		= "pF6pRDE17QrkWusSPfQRDDy7Epklz5h1BpLj0BYCcs9StaTHjP";
	  static String accessTokenStr 			= "729941902296948736-5EaG3oxL07KaEhEFHmM4RnSEVaMrnSY";
	  static String accessTokenSecretStr	= "QK4mWQs7AjfmWAyMcExgXKhJCKnm7cfWyTdntX7JW9wpz";
	  
	public String send(String content, String recipientId,String accesstokenTw,String accesstokensecret,String consumerkey,String consumerkeysecret){
		try {
			ConfigurationBuilder cb = new ConfigurationBuilder();
			
			cb.setOAuthAccessToken/*(accessTokenStr);*/(accesstokenTw);
			cb.setOAuthAccessTokenSecret/*(accessTokenSecretStr);*/(accesstokensecret);
			cb.setOAuthConsumerKey/*(consumerKeyStr);*/(consumerkey);
			cb.setOAuthConsumerSecret/*(consumerSecretStr);*/(consumerkeysecret);			
		
			
			Twitter twitter = new TwitterFactory(cb.build()).getInstance();
			DirectMessage message = twitter.sendDirectMessage(recipientId, content);
			System.out.println("Twitter Msg Sent: " + message.getText() + " to @" + message.getRecipientScreenName());
			twitter4j.Status status = twitter.updateStatus(content);
			System.out.println("Twit Sataus::"+status.getText());//need to check
			return status.getText();
		} catch (Exception e) {
			e.printStackTrace();
			return "500";
		}
	}
	
	public String updateStatusByRest(String msg)
	 { 
		 try {
			 	msg = URLEncoder.encode(msg,"UTF-8");
			 	System.out.println("after encoding msg is : "+msg);
			 	OAuthConsumer oAuthConsumer = new CommonsHttpOAuthConsumer(consumerKeyStr, consumerSecretStr);
				oAuthConsumer.setTokenWithSecret(accessTokenStr, accessTokenSecretStr);
				 
			    HttpPost httpPost = new HttpPost("http://api.twitter.com/1.1/statuses/update.json?status="+msg);
			 
			    oAuthConsumer.sign(httpPost);
			 
			    HttpClient httpClient = new DefaultHttpClient();
			    HttpResponse httpResponse = httpClient.execute(httpPost);
			 
			    int statusCode = httpResponse.getStatusLine().getStatusCode();
			    System.out.println(statusCode + ':'+ httpResponse.getStatusLine().getReasonPhrase());
			    System.out.println(IOUtils.toString(httpResponse.getEntity().getContent()));
			    return String.valueOf(statusCode);
		} catch (Exception e) {
			e.printStackTrace();
			return "500";
		}	
	 }
	
	public String updateStatusByTwitterAPI(String msg)
	{ 
	 	 try {		 	
	 		 	Twitter twitter = new TwitterFactory().getInstance();
	 		 	 
			    twitter.setOAuthConsumer(consumerKeyStr, consumerSecretStr);
			    AccessToken accessToken = new AccessToken(accessTokenStr, accessTokenSecretStr);		 
			    twitter.setOAuthAccessToken(accessToken);		 
			    Status status = twitter.updateStatus(msg);
			 
			    System.out.println("Successfully updated the status in Twitter. "+status.getText());
	 		    return status.getText();
	 	} catch (Exception e) {
	 		e.printStackTrace();
	 		return "500";
	 	}	
	}
	
	public static void main(String[] args) {
		TwitterManager tm = new TwitterManager();
		
		tm.updateStatusByRest("HelloTest");
	}
}

