package com.unaas.bean;

import java.io.Serializable;
import java.util.HashMap;

public class AppBean implements Serializable {
	public HashMap<String, TokenBean> tokenList = new HashMap<String, TokenBean>();
}
