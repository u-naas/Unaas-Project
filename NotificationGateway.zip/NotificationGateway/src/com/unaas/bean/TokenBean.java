package com.unaas.bean;

import java.io.Serializable;

public class TokenBean implements Serializable {


	

	public String getAppName() {
		return appName;
	}
	public void setAppName(String appName) {
		this.appName = appName;
	}
	public String getTokenType() {
		return tokenType;
	}
	public void setTokenType(String tokenType) {
		this.tokenType = tokenType;
	}
	public String getToken_val() {
		return token_val;
	}
	public void setToken_val(String token_val) {
		this.token_val = token_val;
	}
	
	private String appName;
	private String tokenType;
	private String token_val;
}
