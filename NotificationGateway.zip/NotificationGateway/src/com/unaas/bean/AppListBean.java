package com.unaas.bean;

import java.io.Serializable;
import java.util.HashMap;

public class AppListBean implements Serializable{
	
	public HashMap<String, AppBean> applist = new HashMap<String, AppBean>();
}
