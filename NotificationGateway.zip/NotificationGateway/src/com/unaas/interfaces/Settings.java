package com.unaas.interfaces;

import java.util.Properties;





public class Settings {	

	public static final boolean cloudserver_agent_thread		        = false; 
	public static String NotificationGateway_IP							= null;
	public static String NotificationGateway_PORT						= null;		
	public static String NotificationGateway_Service_LOCATION			= null;


	public static String SMS_RECORD_SERVER_IP 			= null;
	public static String SMS_RECORD_SERVER_PORT			= null;
	public static String SMS_RECORD_SERVER_DOMAIN		= null;

	/*-----------File Server And FTP is not in use---------------*/

	public static String FILE_SERVER_DOMAIN				= null;
	public static String FILE_SERVER_SERVICE			= null;
	public static String SERVER_ROOT_DIR				= null;
	public static String FTP_SERVER_IP 					= null;
	public static String FTP_SERVER_PORT				= null;		



	/*---------------XDMS related-------------------*/

	public static String HSS_AUID 						= "hss-userprofile";
	public static String USER_POLICY_AUID				= "policy-settings";
	public static String AUTH_AUID						= "auth-details";
	public static String DEVICE_LIST_AUID				= "device-list";
	public static String DEVICE_SERVICES_MASTER_AUID	= "devicepolicy-details";
	public static String DEVICE_SERVICEACTIONS_AUID		= "scpd_deviceservice";
	public static String USER_SERVICES_MASTER_AUID 		= "usrpolicy-details";
	public static String USER_SERVICEACTIONS_AUID		= "scpd_usrservice";
	public static String USER_LIST_AUID					= "resource-lists";

	public static String NotificationGateway_DOMAIN		= null;
	public static String GATEWAY_PUBLICDOMAIN			= null;


	public static String XDMS1_LOCATION					= null;
	public static String XDMS2_LOCATION					= null;


	public static int CONNECTION_TIMEOUT				= 360000;
	public static int READ_TIMEOUT						= 360000;


	public static String DB_POSTFIX="NOTIFICATION_DB";	
	public static String DB_DIALECT		= "org.hibernate.dialect.MySQLDialect";
	public static String DRIVER 		= "com.mysql.jdbc.Driver";
	public static String DB_ADDRESS;
	public static String MYSQLCONNECTION_DOMAIN;
	public static String MYSQL_USERNAME;	
	public static String MYSQL_PASSWORD;

	public static String DB_NAME="mysql";




	/*---------------Notification Service-------------------*/

	//EMAIL

	public static String 	DEFAULT_EMAIL							= "";
	public static String 	DEFAULT_EMAIL_USER_ID					= "avikesh@u-naas.com";
	public static String 	DEFAULT_EMAIL_USER_PASSWD				= "u-naasf55";
	public static String 	DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_HOST	= "u-naas.com";//"smtpout.asia.secureserver.net";
	public static int 		DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_PORT	= 465;//25;

	//SMS

	public static String 	DEFAULT_SMS_GSM_MODEM_GATEWAY_IP		= "192.168.1.205";
	public static int 		DEFAULT_SMS_GSM_MODEM_GATEWAY_PORT		= 56786;

	//TWITTER

	public static String 	TWITTER_OAUTH_ACCESS_TOKEN				= null;
	public static String 	TWITTER_OAUTH_ACCESS_TOKENSECRET		= null;
	public static String 	TWITTER_OAUTH_CONSUMERKEY				= null;
	public static String 	TWITTER_OAUTH_CONSUMERKEY_SECRET		= null;

	//FACEBOOK

	public static String 	FACEBOOK_APP_ID							= null;
	public static String 	FACEBOOK_APP_SECRET						= null;
	public static String 	FACEBOOK_ACCESS_TOKEN					= null;



	/*-------------------------For ICG Registration--------------------------*/

	public static String 	CLOUDSERVER_IP									= "192.168.1.28";
	public static String 	CLOUDSERVER_PORT								= "7576";
	public static String 	REGISTRATION_TIME_INTERVAL				= "180";

	/*---------------------------For CLOUDSERVER Agent------------------------------*/

	public static String 	REGISTRATION_TIME_INTERVAL_FOR_CCCP		= "180";
	public static String 	CCCP_AGENT_IP							= "192.168.1.151";
	public static String 	CCCP_AGENT_PORT							= "8080";
	public static String 	CCCP_AGENT_DOMIAN						= "http://"+CCCP_AGENT_IP+":"+CCCP_AGENT_PORT;
	public 	static String 	web_content_path						= null;



	static{			
		System.out.println("==1st time readproperties file==");    	
		try{
			Properties prop = new Properties();		   			  
			prop.load(Thread.currentThread().getContextClassLoader().getResourceAsStream("config.properties"));	


			Settings.NotificationGateway_IP					= prop.getProperty("NotificationGateway_IP");		  		
			Settings.NotificationGateway_PORT				= prop.getProperty("NotificationGateway_PORT");	 		



			//FOR Notification get Settings

			//reset		 		
			Settings.NotificationGateway_Service_LOCATION   = "http://"+Settings.NotificationGateway_IP+":"+Settings.NotificationGateway_PORT+"/";			 		
			Settings.NotificationGateway_DOMAIN								= Settings.NotificationGateway_IP+":"+Settings.NotificationGateway_PORT;		 		
			Settings.SMS_RECORD_SERVER_DOMAIN				= "http://"+Settings.SMS_RECORD_SERVER_IP+":"+Settings.SMS_RECORD_SERVER_PORT;
			Settings.CCCP_AGENT_DOMIAN 						= "http://"+Settings.CCCP_AGENT_IP+":"+Settings.CCCP_AGENT_PORT;

			System.out.println("----After Reset values----");
			System.out.println("NotificationGateway DOMAIN::"+Settings.NotificationGateway_DOMAIN);
			System.out.println("NotificationGateway Service Url::"+Settings.NotificationGateway_Service_LOCATION);		


		}
		catch(Exception e){
			e.printStackTrace();
			System.out.println("Fatal Error :Unabled to Read properties  file is present=="+e.getMessage());				   
		}finally
		{

		}

	}

	//static end



	/*------------------------To Registration of ICG with CLOUDSERVER------------------------------------*/
	static {						

	}


}
