package com.unaas.interfaces;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Properties;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;




@WebServlet("/SetSettings")
public class SetSettings extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletContext context; 
	public static String path = null;

	// @see HttpServlet#HttpServlet()

	public SetSettings() {
		super();       
	}

	public void init(ServletConfig config) throws ServletException {

		try{
			System.out.println("Inside init of SetSettings servlet");   			
			context = config.getServletContext();
			path = config.getServletContext().getRealPath("/");

			Properties prop = new Properties();
			prop.load(new FileInputStream(context.getRealPath("/WEB-INF/classes/config.properties")));


			Settings.MYSQLCONNECTION_DOMAIN 		= prop.getProperty("MySQL-Server_IPAdd")+":"+prop.getProperty("MySQL-Server_port");	  	   
			Settings.DB_ADDRESS						= "jdbc:mysql://"+Settings.MYSQLCONNECTION_DOMAIN+"/";

			Settings.MYSQL_USERNAME					= prop.getProperty("mysql-settings_user-name");
			Settings.MYSQL_PASSWORD					= prop.getProperty("mysql-settings_password");

			System.out.println("folderpath : "+path);
		}
			catch (Exception e) {			
				e.printStackTrace();
			}

		}

		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			

		}

		// @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		}
	}
