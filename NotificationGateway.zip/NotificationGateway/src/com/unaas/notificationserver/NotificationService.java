package com.unaas.notificationserver;


import java.io.DataOutputStream;
import java.net.URL;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

import java.net.HttpURLConnection;

import sun.misc.BASE64Encoder;

import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;
import com.sun.jersey.core.util.MultivaluedMapImpl;
import com.unaas.bean.AppBean;
import com.unaas.bean.AppListBean;
import com.unaas.bean.SmsBean;
import com.unaas.daos.EmailManager;
import com.unaas.daos.FacebookManager;
import com.unaas.daos.TwitterManager;
import com.unaas.interfaces.Settings;
import com.unaas.parser.AppTokenListXmlParser;
import com.unaas.parser.ConfigureParser;

@Path("/notificationGateway")

public class NotificationService {

	EmailManager 	em_manager 	= null;
	FacebookManager fb_manager	= null;
	TwitterManager  twt_manager	= null;

	String 			resp		= null;

	public NotificationService()
	{

	}


	/*-------------------------------Hello Method-----------------------------------------*/
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String hello(){
		return "Welcome To Notification Gateway";
	}

	/*@POST
	@Path("/initConfigForNotification")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response initConfigForNotification(String appTokenListXml)
	{
		System.out.println("Inside the initConfigForNotification =============>");

		AppTokenListXmlParser atlxp = new AppTokenListXmlParser();
		AppListBean appList = atlxp.parseAppTokenListXml(appTokenListXml);	

		String resp = InitNotificationConfig(appList);
		System.out.println("response from intConfigForNotification::"+resp);
		return Response.ok(resp).build();
	}*/

	@Path("/sendEMail/{subject}/{toAddr}")
	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response sendEMail(@PathParam("subject") String subject, @PathParam("toAddr") String toAddr, String content)
	{
		System.out.println("Inside NotificationService of sendEMail()");
		System.out.println("\nSubject::"+subject+
				"\n toAddr::"+toAddr+
				"\n content::"+content);

		em_manager = new EmailManager();
		resp = em_manager.sendMail(subject, content, toAddr);

		return Response.ok(resp).build();
	}
	
	
	@Path("/sendTwitTotwitter/{recipientId}/{accesstokenTw}/{accesstokensecret}/{consumerkey}/{consumerkeysecret}")
	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response sendTwitTotwitter(@PathParam("recipientId") String recipientId,  @PathParam("accesstokenTw") String accesstokenTw, @PathParam("accesstokensecret") String accesstokensecret, @PathParam("consumerkey") String consumerkey, @PathParam("consumerkeysecret") String consumerkeysecret, String content)
	{
		System.out.println("Inside NotificationService of sendTwitTotwitter()");
		System.out.println("\n recipientId::"+recipientId+						
				"\n content::"+content);

		twt_manager = new TwitterManager();
		resp = twt_manager.send(content, recipientId,accesstokenTw,accesstokensecret,consumerkey,consumerkeysecret);

		return Response.ok(resp).build();
	}


	@Path("/sendPostToFB/{recipientId}/{isWallPost}/{accesstoken}")
	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public Response sendPostToFB(@PathParam("recipientId") String recipientId, @PathParam("isWallPost") boolean isWallPost,@PathParam("accesstoken") String accesstoken, String content)
	{
		System.out.println("Inside NotificationService of sendPostToFB()");
		System.out.println("\n recipientId::"+recipientId+							
				"\n isWallPost::"+isWallPost+
				"\n content::"+content);

		fb_manager = new FacebookManager();
		resp = fb_manager.send(content, recipientId, isWallPost,accesstoken);

		return Response.ok(resp).build();
	}

	/*private static final String InitNotificationConfig(AppListBean appListBean)
	{
		System.out.println("Inside InitNotificationConfig");

		AppBean email 	=  appListBean.applist.get("EMAIL");
		AppBean fb 		=  appListBean.applist.get("FACEBOOK");
		AppBean sms 	=  appListBean.applist.get("SMS_GSM_MODEM_GATEWAY");
		AppBean twitter =  appListBean.applist.get("TWITTER");

		
			//EMAIL
			Settings.DEFAULT_EMAIL							= email.tokenList.get("DEFAULT").getToken_val();
			Settings.DEFAULT_EMAIL_USER_ID						= email.tokenList.get("USER_ID").getToken_val();
			Settings.DEFAULT_EMAIL_USER_PASSWD					= email.tokenList.get("USER_PASSWD").getToken_val();
			Settings.DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_HOST	= email.tokenList.get("OUTGOING_MAIL_SERVER_HOST").getToken_val();
			Settings.DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_PORT	= Integer.parseInt(email.tokenList.get("OUTGOING_MAIL_SERVER_PORT").getToken_val());			
		
		
			//FACEBOOK
			Settings.FACEBOOK_APP_ID							= fb.tokenList.get("APP_ID").getToken_val();
			Settings.FACEBOOK_APP_SECRET						= fb.tokenList.get("APP_SECRET").getToken_val();
			Settings.FACEBOOK_ACCESS_TOKEN						= fb.tokenList.get("ACCESS_TOKEN").getToken_val();
		


		
			//SMS
			Settings.DEFAULT_SMS_GSM_MODEM_GATEWAY_IP			= sms.tokenList.get("IP").getToken_val();
			Settings.DEFAULT_SMS_GSM_MODEM_GATEWAY_PORT			= Integer.parseInt(sms.tokenList.get("PORT").getToken_val());	
	

	
			//TWITTER
			Settings.TWITTER_OAUTH_ACCESS_TOKEN					= twitter.tokenList.get("ACCESS_TOKEN").getToken_val();
			Settings.TWITTER_OAUTH_ACCESS_TOKENSECRET			= twitter.tokenList.get("ACCESS_TOKENSECRET").getToken_val();
			Settings.TWITTER_OAUTH_CONSUMERKEY					= twitter.tokenList.get("CONSUMERKEY").getToken_val();
			Settings.TWITTER_OAUTH_CONSUMERKEY_SECRET			= twitter.tokenList.get("CONSUMERKEY_SECRET").getToken_val();
		

		System.out.println("------------------Notification Variables after loading property------------"+
				"\n DEFAULT_EMAIL::"+Settings.DEFAULT_EMAIL+
				"\n DEFAULT_EMAIL_USER_ID::"+Settings.DEFAULT_EMAIL_USER_ID+
				"\n DEFAULT_EMAIL_USER_PASSWD::"+Settings.DEFAULT_EMAIL_USER_PASSWD+
				"\n DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_HOST::"+Settings.DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_HOST+
				"\n DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_PORT::"+Settings.DEFAULT_EMAIL_OUTGOING_MAIL_SERVER_PORT+
				"\n\n DEFAULT_SMS_GSM_MODEM_GATEWAY_IP::"+Settings.DEFAULT_SMS_GSM_MODEM_GATEWAY_IP+
				"\n DEFAULT_SMS_GSM_MODEM_GATEWAY_PORT::"+Settings.DEFAULT_SMS_GSM_MODEM_GATEWAY_PORT+
				"\n\n TWITTER_OAUTH_ACCESS_TOKEN::"+Settings.TWITTER_OAUTH_ACCESS_TOKEN+
				"\n TWITTER_OAUTH_ACCESS_TOKENSECRET::"+Settings.TWITTER_OAUTH_ACCESS_TOKENSECRET+
				"\n TWITTER_OAUTH_CONSUMERKEY::"+Settings.TWITTER_OAUTH_CONSUMERKEY+
				"\n TWITTER_OAUTH_CONSUMERKEY_SECRET::"+Settings.TWITTER_OAUTH_CONSUMERKEY_SECRET+				
				"\n\n FACEBOOK_APP_ID::"+Settings.FACEBOOK_APP_ID+
				"\n FACEBOOK_APP_SECRET::"+Settings.FACEBOOK_APP_SECRET+
				"\n FACEBOOK_ACCESS_TOKEN::"+Settings.FACEBOOK_ACCESS_TOKEN
				);	

		//start corn job to renew Facebook access token after 2 months..

		try {
			new FBCronSchedule();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "200";
	}	*/
	
	
	@POST
	@Path("/sendSMS/{sid}/{accessToken}/{to}/{from}")
	@Produces(MediaType.TEXT_PLAIN)	
	@Consumes(MediaType.TEXT_PLAIN)
	public Response sendsms(@PathParam("sid") String sid,@PathParam("accessToken") String accessToken,@PathParam("to") String to,@PathParam("from") String from,String message)
	{
		try {
		System.out.println("NotificationService.sendSMS()");
		System.out.println("message ############# "+message);
		System.out.println("Account sid ########## "+sid);
		System.out.println("AccessToken ########## "+accessToken);
		System.out.println("MESSAGE  ############# "+message);		
		
		String name =sid;
		String password =accessToken;
		String credentials = name + ":" + password;	
		
		// making form data 
		MultivaluedMap formData = new MultivaluedMapImpl();
		formData.add("Body", message);
		formData.add("To", to);
		formData.add("From", from);
		System.out.println("twillomsg Body ======= >"+formData);
		
		// making authorization header
		String auth = new BASE64Encoder().encode(credentials.getBytes()).replaceAll("\\s+","");		
		System.out.println("Base64 encoded auth string: " +auth);
		
		Client c=Client.create();		
		WebResource resource=c.resource("https://api.twilio.com/2010-04-01/Accounts/"+sid+"/Messages");		
		ClientResponse response=resource.type(MediaType.APPLICATION_FORM_URLENCODED).header("Authorization" ,"Basic " +auth).post(ClientResponse.class,formData);
		int status = response.getStatus();
		System.out.println("response =============== "+status);
		
		}catch (Exception e) {
			e.printStackTrace();
		}
		

		return Response.ok().build();
	}



	public static void main(String[] args) {
		/*String xml = 	"subject=Hello world" +
		"toaddr=avikesh@u-naas.com" +						
		"content=hello test";

		String sub = xml.substring(xml.indexOf("subject=")+8, xml.indexOf("toaddr=")).trim();
		String toaddr = xml.substring(xml.indexOf("toaddr=")+7, xml.indexOf("content=")).trim();
		String msg = xml.substring(xml.indexOf("content=")+8).trim();

		System.out.println(sub);
		System.out.println(toaddr);
		System.out.println(msg);*/

		String massageTxt = "HI";
		String to = "56768";
		String xml ="";
		xml="Body : "+massageTxt+","
				+"To :" +to+","
				+"From : +13474721574";
		System.out.println(""+xml);		
	}


}
